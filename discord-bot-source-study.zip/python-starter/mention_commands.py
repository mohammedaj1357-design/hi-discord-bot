"""Developer-only slash commands for managing protected mention users."""

from __future__ import annotations

import logging

import discord
from discord import app_commands


logger = logging.getLogger(__name__)


def setup_mention_protection_commands(bot, protection, developer_id: int):
    """Register the /anti command once on the bot's application-command tree."""
    existing = getattr(bot, "_mention_protection_command", None)
    if existing is not None:
        return existing

    @bot.tree.command(name="anti", description="إدارة حماية المنشن")
    @app_commands.guild_only()
    @app_commands.describe(
        action="اختر العملية",
        user="العضو المطلوب",
    )
    @app_commands.choices(
        action=[
            app_commands.Choice(name="إضافة محمي", value="add"),
            app_commands.Choice(name="إزالة محمي", value="remove"),
            app_commands.Choice(name="قائمة المحميين", value="list"),
            app_commands.Choice(name="مسح تحذيرات عضو", value="clear_warns"),
        ]
    )
    async def anti(
        interaction: discord.Interaction,
        action: app_commands.Choice[str],
        user: discord.Member | None = None,
    ) -> None:
        if interaction.user.id != developer_id:
            await interaction.response.send_message(
                "هذا الأمر خاص بمطور البوت فقط.",
                ephemeral=True,
            )
            return

        if action.value == "list":
            protected = protection.list_protected()
            lines = [f"• <@{user_id}> (`{user_id}`)" for user_id in protected[:35]]
            if len(protected) > 35:
                lines.append(f"… وهناك {len(protected) - 35} عضو آخر.")
            await interaction.response.send_message(
                "🛡️ المحميون في جميع السيرفرات:\n"
                + ("\n".join(lines) if lines else "لا يوجد محميون."),
                ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none(),
            )
            return

        if user is None:
            await interaction.response.send_message(
                "حدد العضو المطلوب لهذا الإجراء.",
                ephemeral=True,
            )
            return

        if action.value == "add":
            try:
                added = protection.add_protected(user.id)
            except OSError:
                logger.exception("Could not save the protected user list.")
                response = "تعذر حفظ قائمة المحميين؛ لم يتغير الإعداد."
            else:
                response = (
                    f"أُضيف {discord.utils.escape_markdown(user.display_name)} "
                    "إلى قائمة المحميين."
                    if added
                    else "هذا العضو محمي بالفعل."
                )
        elif action.value == "remove":
            if user.id == developer_id:
                response = "لا يمكن إزالة حماية المطور الأساسي."
            else:
                try:
                    removed = protection.remove_protected(user.id)
                except OSError:
                    logger.exception("Could not save the protected user list.")
                    response = "تعذر حفظ قائمة المحميين؛ لم يتغير الإعداد."
                else:
                    response = (
                        f"أُزيل {discord.utils.escape_markdown(user.display_name)} "
                        "من قائمة المحميين."
                        if removed
                        else "هذا العضو غير موجود في قائمة المحميين."
                    )
        elif action.value == "clear_warns":
            try:
                count = protection.clear_warnings(user.id, interaction.guild_id)
            except OSError:
                logger.exception("Could not save the cleared mention warnings.")
                response = "تعذر حفظ مسح التحذيرات."
            else:
                response = (
                    f"مُسحت {count} تحذيرات لهذا العضو في هذا السيرفر."
                    if count
                    else "لا توجد تحذيرات نشطة لهذا العضو."
                )
        else:
            response = "الإجراء غير معروف."

        await interaction.response.send_message(
            response,
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    bot._mention_protection_command = anti
    return anti