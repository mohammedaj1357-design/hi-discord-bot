# Python Starter

This folder contains a Discord bot that answers Arabic messages, using Groq,
Gemini, and OpenRouter as fallback providers.

## Run it

From the project root:

```bash
python3 python-starter/bot.py
```

## Required setup

1. Create a bot in the Discord Developer Portal.
2. Enable **Message Content Intent** under the bot settings.
3. Add these values to Replit Secrets:
   - `DISCORD_TOKEN`
   - `GROQ_API_KEY`
   - `GROQ_API_KEY_2` (optional; a second Groq key for rotation)
   - `GEMINI_API_KEY` (optional; fallback after Groq)
   - `OPENROUTER_API_KEY` (optional; enables the fallback provider)
   - `DATABASE_URL` must be available to the bot in development and production
     (the managed PostgreSQL database provides it).
4. Invite the bot to your server with the required permissions.

`GEMINI_API_KEY` is also needed for image analysis; without it, text replies
continue to work but image questions will receive a setup message.
Image questions accept up to four PNG, JPG, or WebP attachments totaling 8 MB.
The bot sends image bytes to Gemini for analysis and does not save them locally.

The bot tries `GROQ_API_KEY`, then `GROQ_API_KEY_2`, then Gemini, then
OpenRouter with DeepSeek Chat. Gemini uses `gemini-3.8-flash` by default; set
`GEMINI_MODEL` to choose a different Gemini model. Groq keys have independent
rate-limit cooldowns. Gemini and OpenRouter are optional for startup, but each
requires its corresponding key to be enabled as a fallback.

The bot responds when it is mentioned and in direct messages. It also exposes a
small health endpoint at `/` on the `PORT` environment variable (8008 by
default), which can be used by an uptime monitor.

## Per-server reply name and avatar

Discord keeps a bot account's actual avatar the same across all servers. The
bot can instead send its server chat replies through a webhook, which allows
each server to show its own name and image. This changes chat replies only;
slash-command responses still use the bot account.

By default, replies use the server's name and icon. Server administrators can
run `/set` or `/setting` to change the reply image (upload a PNG/JPG/GIF up to
8 MB or provide a public HTTPS image URL), change the reply name, view the
current settings, or select server identity, bot identity, or Webhook for image
replies only. In image-only mode, text replies use the bot account and image
analysis replies use the server identity. Switching modes preserves custom
settings; resetting to server defaults requires confirmation and saves a local
backup first.

The bot needs **Manage Webhooks** in each channel where it responds while the
server identity is enabled. It creates and reuses a webhook only when replying
in that channel. Replies mention only the person who asked; other users, roles,
and `@everyone` remain blocked. Normal replies use a Discord reply and still
mention only the asker. Webhook replies appear as normal channel messages rather
than Discord reply-thread messages. Settings and uploaded images are stored under
`python-starter/data`; like other local bot data, they are not guaranteed to
survive a VM replacement or redeployment.

## Add packages

## Virtual economy and games

`!command` includes economy and casino categories. `!الالعاب` lists land and
building commands; `!كازينو` lists the virtual-credit games and their syntax.
All currency is fictional: there are no deposits, purchases with real money,
cash withdrawals, or prizes with monetary value.

New players start with 5,000 credits. A plot costs 1,000, and a kiosk (`kosh`)
costs 500. Start with `!شراء`, `!بناء 1 kosh`, then `!جمع`. `!بنك` shows
holdings and income, and `!بنك 2` shows the next page of plots. Income accrues
based on elapsed time, including downtime, and upgrades stop at level 5.

The economy, games, lottery, reward cooldowns, player blocks, and admin audit
log share a PostgreSQL game-state record. Every settlement locks the record
until commit: concurrent commands, including those from separate processes,
use the latest balance, and errors roll back the entire mutation. If the
database is unavailable, the bot fails instead of switching to a local file.
Production and development databases are separate; republishing or replacing
the VM keeps **production** balances in the production database. Do not select
the Publish option that overwrites production data with development data.
Corrupt state raises an error rather than silently erasing players.


### Migrating existing local balances

1. Stop **all** copies of the old bot so its JSON stops changing. Keep a
   private copy of `python-starter/data/game_data.json` (or a `backup_*.json`
   full-state export) outside the VM. Local files are ignored by git and are
   **not** automatically copied into a new deployment.
2. Ensure the `discord_game_state` table exists in the destination database.
   Its committed schema is in `lib/db/src/schema/discord-game-state.ts`.
   On Publish, Replit applies the development schema to production. Development
   and production data do **not** sync automatically.
3. In the target environment, with its own `DATABASE_URL` and Python
   requirements installed, import the saved source **before** players use the
   new bot:

   ```bash
   python3 python-starter/migrate_game_data.py --source /private/path/game_data.json
   ```

   For production, save the **old production VM's** original JSON before it is
   replaced and use the **production** database connection for the import.
   Both the artifact production command and the direct `.replit` VM deployment
   command require an existing state record. On first publication the bot refuses to start while the
   database has no game-state record. The API can still run, and the bot
   supervisor retries; import the source while the bot is locked. After a
   successful import the next retry starts the bot. To intentionally start
   with no old players instead, run
   `python3 python-starter/migrate_game_data.py --fresh` against an empty
   production database. This explicitly initializes a new game and refuses
   when the local legacy JSON exists; do not choose it if old production
   progress still needs importing.
   Never import the workspace's development JSON into production unless it
   truly is the authoritative production state. If the old file is already
   lost, recover it from an independent backup; Publish cannot reconstruct it.
4. Compare the reported player count and SHA-256 against the saved source.
   Verify balances, land, tickets, and cooldowns before resuming commands.
   Import inserts only when the state row is absent; it refuses to overwrite
   an active game. Re-running it fails without changing data. When a legacy
   file exists and the database is empty, bot startup refuses until import.
   Even when the file is missing on a fresh VM, the production bot stays
   locked until the import has created the database record.

For a fresh production game, explicit initialization is needed. Keep only one bot
process using a given Discord token, even though settlements are safe across
database clients.

## Optional profile learning

Learning is off by default for every Discord user. A member must run
`!تعلم_تشغيل` (`!learn_on`) to opt in; only then are their ordinary text
messages analyzed across the servers where the bot is present for profile
details, interests, recurring topics, and aggregate message/question counts.
`!تعلم` explains the data collected before opt-in. Raw message text is never
written to the learning file. `!تعلم_ايقاف` (`!learn_off`) stops future analysis,
`!معلوماتي` (`!myinfo`) sends that member's saved profile by DM,
`!نسيان <كلمة>` removes matching entries, and `!مسح_معلوماتي`
deletes the profile and turns learning off. `!احصائيات_التعلم` is developer-only
and shows aggregate counts, not member profiles. No command exposes another
member's profile. Profile data is local to the bot filesystem and is not
guaranteed to survive redeployment or VM replacement.

In server text channels, messages from regular members that mention a protected
user are deleted and replaced with a warning that disappears after five
seconds. The developer is protected by default; only the developer can manage
the global protected list with `/anti` (`add`, `remove`, `list`, `clear_warns`).
Server administrators and protected users are exempt from moderation. Warnings
are stored per member and server; three consecutive protected mentions trigger
a 10-minute Discord timeout, and any non-violating message from that member
resets the streak. Streaks also expire after 24 hours, and a successful timeout
clears them. The developer receives a DM with the member, server, channel, and
protected-user IDs, but not the original message text. The bot needs
**Manage Messages**, **Moderate Members**, and the `applications.commands`
scope. Direct messages are not affected.

In server text channels, a separate language filter deletes messages containing
configured insults or profanity and posts a warning that disappears after five
seconds. The developer and server administrators are exempt. Neutral animal
names, identity terms, and context-dependent words are excluded to reduce false
positives. This filter does not issue timeouts; the bot needs **Manage Messages**
to remove matching messages. The configured developer can manage the global list
with the private slash commands `/filter add`, `/filter remove`, `/filter list`,
and `/filter history`. Inside a server, `/filter server-add`,
`/filter server-remove`, `/filter server-list`, and `/filter server-history`
manage overrides for that server only. The private `/filter server-overrides`
command classifies every saved local addition and exclusion for the current
server against the current global list. It distinguishes rules that affect the
effective list now from retained rules that currently overlap the global list or
have no matching global term. This is a private, read-only summary; viewing it
does not change global or server-specific settings. `/filter server-compare`
privately compares the effective
additions and exclusions for two bot-connected servers selected from autocomplete;
it does not change filter settings. `/filter server-reset` previews every saved
addition and exclusion for the current server, then asks the developer to confirm.
Before clearing them, the bot writes a private local backup and sends the same
JSON file by direct message to the developer who confirmed the reset. If either
the local backup, private message delivery, or settings save fails, the settings
are left unchanged. If the saved overrides change after the preview, the
confirmation is rejected and a fresh preview is required. Reset history records
the developer, timestamp, cleared terms, and backup filename. Server lists
start with the current global list; a server removal does not affect other
servers, and a server addition is not applied elsewhere. Entries may be single
words or phrases of up to five words and are matched as whole words or phrases.
Global changes are stored in
`python-starter/data/blocked_terms.json`; server-specific changes are stored
separately in `python-starter/data/blocked_terms_by_guild.json`. Local reset
backups are private files under
`python-starter/data/blocked_terms_by_guild_backups/`. The developer DM is the
off-VM recovery copy: it remains available after a clean bot restart or VM
replacement as long as the Discord message and its attachment are retained.
Keep that message private, and download the attachment to trusted storage before
deleting the VM if you need recovery independent of Discord.

### Recover server-specific filter overrides

1. From the developer account, open the bot's direct messages and download the
   JSON attachment for the server ID being recovered. The file contains
   `guild_id`, `created_at`, and the complete saved `state` from before reset.
2. Stop the bot. Make a separate copy of the current
   `python-starter/data/blocked_terms_by_guild.json` before editing it.
3. In that data file, set `guilds[<guild_id>]` to the attachment's `state`.
   Preserve the other servers' entries. If the file does not exist, create it
   with the top-level shape `{"guilds": {"<guild_id>": <state>}}`.
4. Save valid UTF-8 JSON and restart the bot. Confirm the restored additions and
   exclusions with `/filter server-overrides` in that server.

The attachment is a recovery export, not a bot-hosted archive. Do not post it in
a server channel or make it public; it contains the server's filter terms and
change history.

## Continuous production hosting

Use a **single-instance Reserved VM**, not Autoscale. The API artifact's
production command runs `production.py`, which starts both the API and bot,
restarts exited processes after five seconds, and stops children on shutdown.
Its production build installs Python dependencies into `python-starter/vendor`.
Set `DISCORD_TOKEN` and `GROQ_API_KEY` in publishing secrets and ensure
the managed production database provides `DATABASE_URL`. Add
`GROQ_API_KEY_2`, `GEMINI_API_KEY`, and `OPENROUTER_API_KEY` there too if you
want those fallback providers in production.

Publishing is a separate user action; workspace workflows are not production.
After publishing and confirming "Bot online" in production logs, stop the
workspace's Python Discord Bot workflow to avoid duplicate replies from two
copies using the same token.

Channel settings in `data/channels.json` survive process restarts on the same
filesystem, but are not guaranteed to survive redeployment or VM replacement.
Back them up before redeploying; use durable storage for long-term settings.

Add third-party packages to `requirements.txt`, then install them with:

```bash
python3 -m pip install -r python-starter/requirements.txt
```

### Backup and recovery

Developer `!backup` and automatic pre-reset/pre-grant backups export a
point-in-time full-state JSON under `python-starter/data/backup/`. Destructive
commands only proceed if backup succeeds. Exports are **local**, not durable
across VM replacement: promptly move important copies to a secure location
outside the deployment. Restrict access because exports include player state
and audit records. To recover, stop the bot, select the last verified export,
and import it into a **new, empty** game-state database; verify counts and
balances before resuming. The import command never overwrites existing state:
do not delete a populated production record to force an import. Alternatively,
use Replit's database rollback/recovery process and verify the result before
bringing the bot online. Restoring an older snapshot may lose newer changes.

Player challenges require the target's explicit acceptance; neither player
is charged on refusal or timeout. Only the configured developer can draw the
lottery (`!يانصيب_سحب`). Other protected bot commands retain their permissions.

Developer-only game maintenance commands are listed under `!command` and in
`!adminmenu`: balance grants/adjustments, land and hourly income grants,
blocking players from game commands, statistics, backups, resets, audit logs,
and an announcement to each server. `!resetall`, `!resetuser`, `!clearlogs`,
`!givemoney`, and `!broadcast` require the developer to confirm using a
button; cancellation or timeout changes nothing. Resets and other balance
mutations first create a private local full-state JSON backup in
`python-starter/data/backup/`. Backups are local database exports, not
independently durable until moved outside the VM.
The bot does not run these commands automatically.

General commands include `!about`, `!ping`, `!uptime`, and `!memory`.
Developer bot controls include `!status`, `!say`, `!welcometest`,
`!resetcool`, `!restart`, and `!shutdown`. The restart and shutdown buttons
require developer confirmation; shutdown stops the Python Discord Bot workflow
and must be started again from Replit. `!welcometest` is only a preview because
no automatic welcome system is configured. Message/history-clearing commands
(`!clear`, `!reload`, and `!reset`) are intentionally not registered because
the developer declined local archives of message and AI conversation text.
