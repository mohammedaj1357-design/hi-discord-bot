import sys
from pathlib import Path
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from game_store import validate_state


class LevelStateSchemaTests(unittest.TestCase):
    def test_levels_defaults_to_an_empty_object(self):
        state = validate_state({}, "test")
        self.assertEqual(state["levels"], {})
        self.assertEqual(state["level_announcement_settings"], {})

    def test_non_object_levels_state_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "levels must be an object"):
            validate_state({"levels": []}, "test")

    def test_invalid_level_announcement_settings_are_rejected(self):
        with self.assertRaisesRegex(ValueError, "level_announcement_settings"):
            validate_state({"level_announcement_settings": []}, "test")
        with self.assertRaisesRegex(ValueError, "unknown level announcement mode"):
            validate_state(
                {"level_announcement_settings": {"10": {"mode": "unknown"}}},
                "test",
            )
        with self.assertRaisesRegex(ValueError, "unknown level announcement mode"):
            validate_state(
                {"level_announcement_settings": {"10": {"mode": []}}},
                "test",
            )
        with self.assertRaisesRegex(ValueError, "requires a channel ID"):
            validate_state(
                {"level_announcement_settings": {"10": {"mode": "channel"}}},
                "test",
            )
        with self.assertRaisesRegex(ValueError, "level custom message"):
            validate_state(
                {
                    "level_announcement_settings": {
                        "10": {"custom_message": "   "}
                    }
                },
                "test",
            )


if __name__ == "__main__":
    unittest.main()