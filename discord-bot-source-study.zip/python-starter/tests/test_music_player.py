import asyncio
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import discord
from discord.ext import commands

from music_player import (
    MAX_QUEUE_SIZE,
    MusicError,
    MusicManager,
    Track,
    canonical_youtube_url,
    setup_music_commands,
)


class YouTubeUrlTests(unittest.TestCase):
    def test_accepts_youtube_video_url_shapes(self):
        self.assertEqual(
            canonical_youtube_url("https://youtu.be/abcdefghijk"),
            "https://www.youtube.com/watch?v=abcdefghijk",
        )
        self.assertEqual(
            canonical_youtube_url(
                "https://music.youtube.com/watch?v=abcdefghijk"
            ),
            "https://www.youtube.com/watch?v=abcdefghijk",
        )
        self.assertEqual(
            canonical_youtube_url(
                "https://www.youtube.com/shorts/abcdefghijk"
            ),
            "https://www.youtube.com/watch?v=abcdefghijk",
        )

    def test_rejects_non_youtube_urls_and_playlists(self):
        for url in (
            "https://example.com/watch?v=abcdefghijk",
            "https://youtube.com/watch?v=abcdefghijk&list=PL123",
            "https://youtube.com:not-a-port/watch?v=abcdefghijk",
            "file:///etc/passwd",
            "https://user@example.com/",
        ):
            with self.subTest(url=url), self.assertRaises(MusicError):
                canonical_youtube_url(url)


class MusicManagerTests(unittest.TestCase):
    def setUp(self):
        self.bot = SimpleNamespace()
        self.manager = MusicManager(self.bot)
        self.track_a = Track(
            "abcdefghijk",
            "First Song",
            "https://www.youtube.com/watch?v=abcdefghijk",
            180,
            "Member",
        )
        self.track_b = Track(
            "lmnopqrstuv",
            "Second Song",
            "https://www.youtube.com/watch?v=lmnopqrstuv",
            200,
            "Member",
        )

    def test_setup_registers_commands_and_is_idempotent(self):
        bot = commands.Bot(command_prefix="!", intents=discord.Intents.none())
        manager = MusicManager(bot)

        setup_music_commands(bot, manager)
        command_count = len(bot.commands)
        setup_music_commands(bot, manager)

        self.assertEqual(len(bot.commands), command_count)
        for name in ("play", "queue", "nowplaying", "pause", "resume", "skip", "stop", "volume"):
            self.assertIsNotNone(bot.get_command(name))
        self.assertIsNotNone(bot.get_command("music_help"))

    def test_queue_loop_requeues_finished_track(self):
        async def run():
            state = self.manager.state_for(1)
            state.current = self.track_a
            state.queue.append(self.track_b)
            state.loop_mode = "queue"
            self.manager._start_next = AsyncMock()
            self.manager._render_panel = AsyncMock()

            await self.manager._track_finished(1, state.generation, failed=False)

            self.assertIsNone(state.current)
            self.assertEqual(list(state.queue), [self.track_b, self.track_a])
            self.manager._start_next.assert_awaited_once_with(1)

        asyncio.run(run())

    def test_queued_track_starts_ffmpeg_and_advances_after_audio_finishes(self):
        class FakeSource:
            def cleanup(self):
                pass

        class FakeVolume:
            def __init__(self, source, volume):
                self.source = source
                self.volume = volume

        class FakeVoiceClient:
            channel = SimpleNamespace(id=99)

            def __init__(self):
                self.playing = False
                self.paused = False
                self.after = None
                self.source = None

            def is_connected(self):
                return True

            def is_playing(self):
                return self.playing

            def is_paused(self):
                return self.paused

            def play(self, source, *, after):
                self.source = source
                self.after = after
                self.playing = True

        async def run():
            voice_client = FakeVoiceClient()
            state = self.manager.state_for(1)
            state.voice_client = voice_client
            state.queue.append(self.track_a)
            self.manager._render_panel = AsyncMock()

            with (
                patch(
                    "music_player._resolve_audio_url_sync",
                    return_value="https://audio.example/stream",
                ),
                patch(
                    "music_player.discord.FFmpegPCMAudio",
                    return_value=FakeSource(),
                ) as ffmpeg,
                patch(
                    "music_player.discord.PCMVolumeTransformer",
                    side_effect=lambda source, volume: FakeVolume(source, volume),
                ),
            ):
                await self.manager._start_next(1)

                ffmpeg.assert_called_once()
                self.assertEqual(voice_client.source.volume, 1)
                self.assertIs(state.current, self.track_a)
                self.assertTrue(state.starting is False)
                self.assertTrue(voice_client.playing)

                voice_client.playing = False
                voice_client.after(None)
                await asyncio.sleep(0.01)

            self.assertIsNone(state.current)
            self.assertEqual(list(state.history), [self.track_a])

        asyncio.run(run())

    def test_stop_invalidates_an_inflight_audio_resolution(self):
        async def run():
            voice_client = SimpleNamespace(
                is_connected=lambda: True,
                is_playing=lambda: False,
                is_paused=lambda: False,
                disconnect=AsyncMock(),
            )
            state = self.manager.state_for(1)
            state.voice_client = voice_client
            state.current = self.track_a
            state.queue.append(self.track_b)
            self.manager._render_panel = AsyncMock()

            message = await self.manager.stop(1)

            self.assertIn("مسح قائمة الانتظار", message)
            self.assertGreater(state.generation, 0)
            self.assertIsNone(state.current)
            self.assertFalse(state.queue)
            self.assertIsNone(state.voice_client)
            voice_client.disconnect.assert_awaited_once_with(force=True)

        asyncio.run(run())

    def test_youtube_search_is_used_for_plain_text_queries(self):
        fake_info = {
            "id": "abcdefghijk",
            "title": "A song",
            "duration": 120,
        }
        class FakeYoutubeDL:
            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

            def extract_info(self, query, download):
                self.query = query
                self.download = download
                return fake_info

        fake_youtube_dl = FakeYoutubeDL()
        with patch(
            "music_player.yt_dlp.YoutubeDL", return_value=fake_youtube_dl
        ) as ydl:
            track = asyncio.run(
                self.manager.find_track("a song", requester="Member")
            )

        ydl.assert_called_once()
        self.assertEqual(fake_youtube_dl.query, "ytsearch1:a song")
        self.assertFalse(fake_youtube_dl.download)
        self.assertEqual(track.video_id, "abcdefghijk")
        self.assertEqual(track.url, "https://www.youtube.com/watch?v=abcdefghijk")
        self.assertEqual(track.duration_text, "2:00")

    def test_queue_limit_is_bounded(self):
        async def run():
            state = self.manager.state_for(1)
            state.queue.extend([self.track_a] * MAX_QUEUE_SIZE)
            with self.assertRaises(MusicError):
                await self.manager.enqueue(
                    SimpleNamespace(id=1),
                    voice_channel=None,
                    text_channel=None,
                    track=self.track_b,
                )

        asyncio.run(run())


if __name__ == "__main__":
    unittest.main()