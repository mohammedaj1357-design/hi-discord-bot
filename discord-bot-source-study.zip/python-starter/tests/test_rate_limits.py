"""Tests for provider cooldown parsing and user-facing rate-limit messages."""

import base64
import os
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from rate_limits import rate_limit_message, retry_after_seconds


class RetryHintTests(unittest.TestCase):
    def test_retry_after_header_is_read_as_seconds(self):
        self.assertEqual(retry_after_seconds({"Retry-After": "42"}), 42)

    def test_groq_reset_headers_parse_compound_durations(self):
        self.assertEqual(
            retry_after_seconds({
                "x-ratelimit-reset-requests": "1m",
                "x-ratelimit-reset-tokens": "1m 12s",
            }),
            72,
        )

    def test_provider_error_message_can_supply_retry_time(self):
        self.assertEqual(
            retry_after_seconds({}, "Rate limit. Please try again in 2m30s."),
            150,
        )

    def test_rate_limit_messages_have_a_fallback_and_human_wait(self):
        self.assertIn("30 ثانية", rate_limit_message(30))
        self.assertIn("حوالي 2 دقيقة", rate_limit_message(61))
        self.assertIn("بعد قليل", rate_limit_message(None))


class BotRateLimitTests(unittest.IsolatedAsyncioTestCase):
    @classmethod
    def setUpClass(cls):
        with patch.dict(
            os.environ,
            {
                "DISCORD_TOKEN": "test-discord-token",
                "GROQ_API_KEY": "test-groq-key",
                "GROQ_API_KEY_2": "test-groq-key-2",
                "GEMINI_API_KEY": "test-gemini-key",
                "OPENROUTER_API_KEY": "",
            },
        ):
            import bot as bot_module
        cls.bot_module = bot_module

    def setUp(self):
        bot_module = self.bot_module
        self.old_state = {
            "http_session": bot_module.http_session,
            "groq_key_rate_limits": bot_module.groq_key_rate_limits.copy(),
            "gemini_rate_limit_until": bot_module.gemini_rate_limit_until,
            "openrouter_rate_limit_until": bot_module.openrouter_rate_limit_until,
            "conversations": bot_module.conversations,
            "GROQ_API_KEYS": bot_module.GROQ_API_KEYS,
            "GEMINI_API_KEY": bot_module.GEMINI_API_KEY,
            "GEMINI_MODEL": bot_module.GEMINI_MODEL,
            "OPENROUTER_API_KEY": bot_module.OPENROUTER_API_KEY,
        }
        self.session = FakeSession()
        bot_module.http_session = self.session
        bot_module.groq_key_rate_limits = {}
        bot_module.gemini_rate_limit_until = 0
        bot_module.openrouter_rate_limit_until = 0
        bot_module.conversations = {}
        bot_module.GROQ_API_KEYS = ("test-groq-key", "test-groq-key-2")
        bot_module.GEMINI_API_KEY = "test-gemini-key"
        bot_module.GEMINI_MODEL = "gemini-3.8-flash"
        bot_module.OPENROUTER_API_KEY = "test-openrouter-key"
        self.addCleanup(self.restore_bot_state)

    def restore_bot_state(self):
        for name, value in self.old_state.items():
            setattr(self.bot_module, name, value)

    async def test_groq_429_rotates_to_second_key_and_skips_cooled_key(self):
        self.bot_module.GEMINI_API_KEY = None
        self.session.responses = [
            (429, {"error": {"message": "rate limit"}}, {"Retry-After": "30"}),
            (200, {"choices": [{"message": {"content": "second key answer"}}]}, {}),
            (200, {"choices": [{"message": {"content": "next answer"}}]}, {}),
        ]

        first = await self.bot_module.get_groq_reply(555, "first question")
        self.assertEqual(first, "second key answer")
        self.assertIn("api.groq.com", self.session.calls[0]["url"])
        self.assertEqual(
            self.session.calls[0]["headers"]["Authorization"],
            "Bearer test-groq-key",
        )
        self.assertEqual(
            self.session.calls[1]["headers"]["Authorization"],
            "Bearer test-groq-key-2",
        )
        self.assertGreater(self.bot_module.groq_key_rate_limits[0], 0)

        second = await self.bot_module.get_groq_reply(555, "second question")
        self.assertEqual(second, "next answer")
        self.assertEqual(len(self.session.calls), 3)
        self.assertEqual(
            self.session.calls[2]["headers"]["Authorization"],
            "Bearer test-groq-key-2",
        )
        self.assertEqual(
            [message["role"] for message in self.bot_module.conversations[555]],
            ["user", "assistant", "user", "assistant"],
        )

    async def test_all_groq_keys_rate_limited_fall_back_to_gemini(self):
        self.bot_module.conversations[559] = [
            {"role": "user", "content": "Earlier question"},
            {"role": "assistant", "content": "Earlier answer"},
        ]
        self.session.responses = [
            (429, {"error": {"message": "rate limit"}}, {"Retry-After": "30"}),
            (429, {"error": {"message": "rate limit"}}, {"Retry-After": "40"}),
            (
                200,
                {
                    "candidates": [
                        {"content": {"parts": [{"text": "Gemini answer"}]}}
                    ]
                },
                {},
            ),
        ]

        reply = await self.bot_module.get_groq_reply(559, "hello Gemini")

        self.assertEqual(reply, "Gemini answer")
        gemini_request = self.session.calls[2]
        self.assertEqual(
            gemini_request["url"],
            "https://generativelanguage.googleapis.com/v1beta/models/"
            "gemini-3.8-flash:generateContent",
        )
        self.assertEqual(
            gemini_request["headers"]["x-goog-api-key"],
            "test-gemini-key",
        )
        self.assertNotIn("key=", gemini_request["url"])
        self.assertIn(
            "hello Gemini",
            gemini_request["json"]["contents"][-1]["parts"][0]["text"],
        )
        self.assertIn(
            "systemInstruction",
            gemini_request["json"],
        )
        self.assertEqual(
            [item["role"] for item in gemini_request["json"]["contents"]],
            ["user", "model", "user"],
        )

    async def test_gemini_failure_uses_openrouter_fallback(self):
        self.session.responses = [
            (503, {"error": {"code": "unavailable"}}, {}),
            (503, {"error": {"code": "unavailable"}}, {}),
            (503, {"error": {"code": "unavailable"}}, {}),
            (200, {"choices": [{"message": {"content": "router answer"}}]}, {}),
        ]

        reply = await self.bot_module.get_groq_reply(560, "question")

        self.assertEqual(reply, "router answer")
        self.assertIn("gemini-3.8-flash:generateContent", self.session.calls[2]["url"])
        self.assertIn("openrouter.ai", self.session.calls[3]["url"])

    async def test_network_error_uses_openrouter(self):
        self.bot_module.GROQ_API_KEYS = ("test-groq-key",)
        self.bot_module.GEMINI_API_KEY = None
        self.session.responses = [
            self.bot_module.aiohttp.ClientConnectionError("offline"),
            (200, {"choices": [{"message": {"content": "backup reply"}}]}, {}),
        ]

        reply = await self.bot_module.get_groq_reply(556, "question")

        self.assertEqual(reply, "backup reply")
        self.assertEqual(len(self.session.calls), 2)
        self.assertIn("openrouter.ai", self.session.calls[1]["url"])

    async def test_invalid_request_does_not_trigger_fallback(self):
        self.bot_module.GROQ_API_KEYS = ("test-groq-key",)
        self.bot_module.GEMINI_API_KEY = None
        self.session.responses = [
            (400, {"error": {"code": "invalid_request"}}, {}),
        ]

        reply = await self.bot_module.get_groq_reply(557, "question")

        self.assertIn("تعذر إكمال الطلب", reply)
        self.assertEqual(len(self.session.calls), 1)
        self.assertEqual(self.bot_module.conversations[557], [])

    async def test_openrouter_rate_limit_is_cooled_down(self):
        self.bot_module.GROQ_API_KEYS = ("test-groq-key",)
        self.bot_module.GEMINI_API_KEY = None
        self.session.responses = [
            (503, {"error": {"code": "unavailable"}}, {}),
            (429, {"error": {"message": "rate limit"}}, {"Retry-After": "25"}),
            (503, {"error": {"code": "unavailable"}}, {}),
        ]

        first = await self.bot_module.get_groq_reply(558, "question")
        self.assertIn("25 ثانية", first)
        self.assertGreater(self.bot_module.openrouter_rate_limit_until, 0)

        second = await self.bot_module.get_groq_reply(558, "another question")
        self.assertIn("ثانية", second)
        self.assertEqual(len(self.session.calls), 3)
        self.assertIn("api.groq.com", self.session.calls[2]["url"])

    async def test_mentioned_image_uses_one_image_reply_path(self):
        bot_module = self.bot_module

        class FakeTyping:
            async def __aenter__(self):
                return self

            async def __aexit__(self, *args):
                return False

        class FakeAttachment:
            filename = "photo.png"
            content_type = "image/png"
            size = 5

            async def read(self):
                return b"image"

        class FakeBot:
            user = SimpleNamespace(
                id=909,
                mentioned_in=lambda message: True,
            )

            async def get_context(self, message):
                return SimpleNamespace(prefix=None)

        message = SimpleNamespace(
            id=987654321,
            author=SimpleNamespace(id=555, bot=False),
            channel=SimpleNamespace(
                id=222,
                guild=SimpleNamespace(id=111),
                typing=lambda: FakeTyping(),
            ),
            guild=SimpleNamespace(id=111),
            content="<@909> What is in this picture?",
            attachments=[FakeAttachment()],
        )
        bot_module.processed_message_ids.discard(message.id)

        with (
            patch.object(bot_module, "bot", FakeBot()),
            patch.object(
                bot_module.mention_protection,
                "handle",
                new=AsyncMock(return_value=False),
            ),
            patch.object(
                bot_module,
                "handle_profanity",
                new=AsyncMock(return_value=False),
            ),
            patch.object(bot_module.channel_settings, "allows", return_value=True),
            patch.object(bot_module.learning_store, "analyze_message"),
            patch.object(
                bot_module,
                "get_gemini_image_reply",
                new=AsyncMock(return_value="A cat."),
            ) as image_reply,
            patch.object(
                bot_module.server_persona_manager,
                "reply",
                new=AsyncMock(),
            ) as send_reply,
        ):
            await bot_module.on_message(message)

        image_reply.assert_awaited_once_with(
            "What is in this picture?",
            [("image/png", b"image")],
        )
        send_reply.assert_awaited_once_with(
            message,
            "A cat.",
            force_webhook=True,
        )
        bot_module.processed_message_ids.discard(message.id)
        if message.id in bot_module.processed_message_order:
            bot_module.processed_message_order.remove(message.id)

    async def test_gemini_image_request_sends_inline_data_and_returns_analysis(self):
        self.session.responses = [
            (
                200,
                {"candidates": [{"content": {"parts": [{"text": "قطة على كرسي"}]}}]},
                {},
            )
        ]

        reply = await self.bot_module.get_gemini_image_reply(
            "ماذا يظهر في الصورة؟",
            [("image/png", b"test-image-bytes")],
        )

        self.assertEqual(reply, "قطة على كرسي")
        request = self.session.calls[0]
        self.assertIn("gemini-3.8-flash:generateContent", request["url"])
        self.assertEqual(
            request["headers"]["x-goog-api-key"],
            "test-gemini-key",
        )
        parts = request["json"]["contents"][0]["parts"]
        self.assertEqual(parts[0]["text"], "ماذا يظهر في الصورة؟")
        inline_data = parts[1]["inline_data"]
        self.assertEqual(inline_data["mime_type"], "image/png")
        self.assertEqual(
            base64.b64decode(inline_data["data"]),
            b"test-image-bytes",
        )

    async def test_gemini_image_rate_limit_sets_cooldown(self):
        self.session.responses = [
            (429, {"error": {"message": "rate limit"}}, {"Retry-After": "25"})
        ]

        reply = await self.bot_module.get_gemini_image_reply(
            "اشرح الصورة",
            [("image/jpeg", b"image")],
        )

        self.assertIn("25 ثانية", reply)
        self.assertGreater(self.bot_module.gemini_rate_limit_until, 0)


class FakeResponse:
    def __init__(self, status, data, headers):
        self.status = status
        self.data = data
        self.headers = headers

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        return False

    async def json(self):
        return self.data


class FakeSession:
    closed = False

    def __init__(self):
        self.calls = []
        self.responses = []

    def post(self, url, **kwargs):
        self.calls.append({"url": url, **kwargs})
        response = self.responses.pop(0)
        if isinstance(response, BaseException):
            raise response
        status, data, headers = response
        return FakeResponse(status, data, headers)


if __name__ == "__main__":
    unittest.main()