"""Tests for the developer-only /anti application command."""

import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import discord
from discord.ext import commands

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mention_commands import setup_mention_protection_commands
from mention_protection import MentionProtection


DEVELOPER_ID = 42


class MentionCommandTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        data_dir = Path(self.temp_dir.name)
        self.protection = MentionProtection(
            DEVELOPER_ID,
            protected_users_path=data_dir / "protected.json",
            warnings_path=data_dir / "warnings.json",
        )
        self.bot = commands.Bot(
            command_prefix="!",
            intents=discord.Intents.none(),
        )
        self.command = setup_mention_protection_commands(
            self.bot,
            self.protection,
            DEVELOPER_ID,
        )

    def tearDown(self):
        self.temp_dir.cleanup()

    def interaction(self, user_id=DEVELOPER_ID, guild_id=10):
        return SimpleNamespace(
            user=SimpleNamespace(id=user_id),
            guild_id=guild_id,
            response=SimpleNamespace(send_message=AsyncMock()),
        )

    async def invoke(self, interaction, value, user=None):
        choice = discord.app_commands.Choice(name=value, value=value)
        await self.command.callback(interaction, choice, user)

    async def test_command_registers_once(self):
        self.assertIs(self.bot.tree.get_command("anti"), self.command)
        self.assertIs(
            setup_mention_protection_commands(
                self.bot,
                self.protection,
                DEVELOPER_ID,
            ),
            self.command,
        )

    async def test_non_developer_cannot_manage_protected_users(self):
        interaction = self.interaction(user_id=100)
        member = SimpleNamespace(id=200, display_name="Target")

        await self.invoke(interaction, "add", member)

        self.assertNotIn(200, self.protection.protected_users)
        interaction.response.send_message.assert_awaited_once()
        self.assertTrue(
            interaction.response.send_message.call_args.kwargs["ephemeral"]
        )

    async def test_add_remove_and_keep_developer_protection(self):
        interaction = self.interaction()
        member = SimpleNamespace(id=200, display_name="Target")

        await self.invoke(interaction, "add", member)
        self.assertIn(200, self.protection.protected_users)
        self.assertIn(
            "أُضيف",
            interaction.response.send_message.call_args.args[0],
        )

        interaction = self.interaction()
        await self.invoke(interaction, "remove", member)
        self.assertNotIn(200, self.protection.protected_users)

        interaction = self.interaction()
        developer = SimpleNamespace(id=DEVELOPER_ID, display_name="Developer")
        await self.invoke(interaction, "remove", developer)
        self.assertIn(DEVELOPER_ID, self.protection.protected_users)
        self.assertIn(
            "لا يمكن إزالة",
            interaction.response.send_message.call_args.args[0],
        )

    async def test_list_is_private_and_does_not_notify_protected_users(self):
        self.protection.add_protected(200)
        interaction = self.interaction()

        await self.invoke(interaction, "list")

        response = interaction.response.send_message.call_args
        self.assertTrue(response.kwargs["ephemeral"])
        self.assertIn("200", response.args[0])
        self.assertFalse(response.kwargs["allowed_mentions"].users)

    async def test_clear_warnings_only_clears_the_current_guild(self):
        self.protection.add_warning(200, 10, "mention")
        self.protection.add_warning(200, 11, "mention")
        interaction = self.interaction(guild_id=10)
        member = SimpleNamespace(id=200, display_name="Target")

        await self.invoke(interaction, "clear_warns", member)

        self.assertEqual(self.protection.get_warnings(200, 10), 0)
        self.assertEqual(self.protection.get_warnings(200, 11), 1)
        self.assertIn(
            "1 تحذيرات",
            interaction.response.send_message.call_args.args[0],
        )

    async def test_actions_requiring_member_report_missing_user(self):
        interaction = self.interaction()

        await self.invoke(interaction, "add")

        self.assertIn(
            "حدد العضو",
            interaction.response.send_message.call_args.args[0],
        )


if __name__ == "__main__":
    unittest.main()