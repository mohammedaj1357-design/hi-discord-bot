"""Tests for public status and developer bot-control commands."""

import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import discord
from discord.ext import commands

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from admin_engine import AdminEngine
from bot_control_commands import StopBotView, setup_bot_control_commands
from game_store import GameStore


class BotControlTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        self.store = GameStore(root / "game.json")
        self.engine = AdminEngine(self.store)
        self.bot = commands.Bot(command_prefix="!", intents=discord.Intents.default())
        self.developer_id = 42
        self.conversations = {8: [{"role": "user", "content": "private text"}]}
        setup_bot_control_commands(
            self.bot,
            developer_id=self.developer_id,
            conversations=self.conversations,
            game_store=self.store,
            admin_engine=self.engine,
            process_started_at=0,
            shutdown_marker=root / "shutdown.request",
        )
        self.marker = root / "shutdown.request"

    async def asyncTearDown(self):
        await self.bot.close()

    async def test_expected_commands_and_developer_checks(self):
        names = (
            "about", "ping", "uptime", "memory", "status", "say", "welcometest",
            "resetcool", "restart", "shutdown",
        )
        self.assertEqual(set(names), {name for name in names if self.bot.get_command(name)})
        self.assertIsNone(self.bot.get_command("clear"))
        self.assertIsNone(self.bot.get_command("reload"))
        self.assertIsNone(self.bot.get_command("reset"))
        for name in ("status", "say", "welcometest", "resetcool", "restart", "shutdown"):
            command = self.bot.get_command(name)
            self.assertTrue(command.extras["developer_control"])
            ctx = SimpleNamespace(author=SimpleNamespace(id=99))
            self.assertFalse(await command.checks[0](ctx))
            ctx.author.id = self.developer_id
            self.assertTrue(await command.checks[0](ctx))

    async def test_memory_reports_only_message_count_not_transcript(self):
        ctx = SimpleNamespace(author=SimpleNamespace(id=8), reply=AsyncMock())
        await self.bot.get_command("memory").callback(ctx)
        output = ctx.reply.call_args.args[0]
        self.assertIn("1", output)
        self.assertNotIn("private text", output)

    async def test_resetcool_requires_confirmation_and_creates_backup(self):
        with self.store.transaction() as data:
            data["cooldowns"] = {"daily:1": 100, "invest:2": 200}
        ctx = SimpleNamespace(send=AsyncMock(return_value=SimpleNamespace()))
        await self.bot.get_command("resetcool").callback(ctx)
        self.assertEqual(len(self.store.snapshot()["cooldowns"]), 2)
        view = ctx.send.call_args.kwargs["view"]

        class Response:
            async def edit_message(self, **kwargs):
                self.edited = kwargs

        interaction = SimpleNamespace(
            user=SimpleNamespace(id=self.developer_id), response=Response()
        )
        await view.children[0].callback(interaction)
        self.assertEqual(self.store.snapshot()["cooldowns"], {})
        self.assertEqual(self.store.snapshot()["admin_logs"][-1]["action"], "reset_cooldowns")
        backups = list((self.marker.parent / "backup").glob("backup_*.json"))
        self.assertEqual(len(backups), 1)
        self.assertEqual(interaction.response.edited["view"], view)

    async def test_restart_and_shutdown_confirmations_are_developer_only(self):
        bot = SimpleNamespace(close=AsyncMock())
        outsider = SimpleNamespace(
            user=SimpleNamespace(id=7), response=SimpleNamespace(send_message=AsyncMock())
        )
        shutdown = StopBotView(
            bot, self.developer_id, shutdown=True, shutdown_marker=self.marker
        )
        self.assertFalse(await shutdown.interaction_check(outsider))
        self.assertFalse(self.marker.exists())
        self.assertFalse(bot.close.await_count)

        class Response:
            async def edit_message(self, **kwargs):
                self.edited = kwargs

        authorized = SimpleNamespace(
            user=SimpleNamespace(id=self.developer_id), response=Response()
        )
        await shutdown.children[0].callback(authorized)
        self.assertTrue(self.marker.exists())
        bot.close.assert_awaited_once()
        bot.close.reset_mock()
        self.marker.unlink()  # The workflow supervisor consumes this on shutdown.

        restart = StopBotView(
            bot, self.developer_id, shutdown=False, shutdown_marker=self.marker
        )
        await restart.children[0].callback(authorized)
        self.assertEqual(bot.close.await_count, 1)
        # Restart must not leave a stale marker that suppresses the supervisor.
        self.assertFalse(self.marker.exists())


if __name__ == "__main__":
    unittest.main()