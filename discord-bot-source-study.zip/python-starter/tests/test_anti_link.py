"""Tests for per-guild anti-link moderation."""

import sys
import tempfile
import unittest
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import discord
from discord.ext import commands

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from anti_link import (  # noqa: E402
    AntiLinkModeration,
    AntiLinkStore,
    contains_link,
    setup_anti_link_commands,
)


class AntiLinkStoreTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name) / "anti_link.json"
        self.store = AntiLinkStore(self.path)

    def test_defaults_disabled_with_one_hour_timeout(self):
        settings = self.store.get(123)
        self.assertFalse(settings["enabled"])
        self.assertEqual(settings["timeout_minutes"], 60)
        self.assertEqual(settings["allowed_channels"], [])
        self.assertEqual(settings["exempt_roles"], [])

    def test_settings_are_per_guild_and_persist_across_reloads(self):
        self.store.set_enabled(123, True)
        self.store.set_timeout(123, 30)
        self.assertTrue(self.store.add_allowed_channel(123, 456))
        self.assertTrue(self.store.add_exempt_role(123, 789))
        self.assertFalse(self.store.add_allowed_channel(123, 456))

        restored = AntiLinkStore(self.path)

        self.assertEqual(
            restored.get(123),
            {
                "enabled": True,
                "timeout_minutes": 30,
                "allowed_channels": [456],
                "exempt_roles": [789],
            },
        )
        self.assertFalse(restored.get(124)["enabled"])

    def test_invalid_timeout_and_ids_are_rejected(self):
        for minutes in (-1, 10_081, True):
            with self.subTest(minutes=minutes), self.assertRaises(ValueError):
                self.store.set_timeout(123, minutes)
        with self.assertRaises(ValueError):
            self.store.add_allowed_channel(123, 0)


class AntiLinkModerationTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.store = AntiLinkStore(Path(self.directory.name) / "anti_link.json")
        self.moderation = AntiLinkModeration(self.store, developer_id=999)

    def make_message(
        self,
        *,
        content="https://example.com/path",
        author_id=7,
        is_bot=False,
        administrator=False,
        manage_messages=False,
        role_ids=(),
        channel_id=20,
        parent_id=None,
        in_guild=True,
    ):
        author = SimpleNamespace(
            id=author_id,
            bot=is_bot,
            guild_permissions=SimpleNamespace(
                administrator=administrator,
                manage_messages=manage_messages,
            ),
            roles=[SimpleNamespace(id=role_id) for role_id in role_ids],
            timeout=AsyncMock(),
        )
        channel = SimpleNamespace(
            id=channel_id,
            parent_id=parent_id,
            send=AsyncMock(),
        )
        message = SimpleNamespace(
            guild=SimpleNamespace(id=10) if in_guild else None,
            author=author,
            channel=channel,
            content=content,
            delete=AsyncMock(),
        )
        return message

    async def test_enabled_link_deletes_times_out_and_sends_non_ping_warning(self):
        self.store.set_enabled(10, True)
        message = self.make_message()

        handled = await self.moderation.handle(message)

        self.assertTrue(handled)
        message.delete.assert_awaited_once()
        message.author.timeout.assert_awaited_once_with(
            timedelta(minutes=60),
            reason="Anti-Link rule: links are not allowed in this server",
        )
        warning, = message.channel.send.await_args.args
        self.assertIn("60 دقيقة", warning)
        self.assertEqual(
            message.channel.send.await_args.kwargs["allowed_mentions"].to_dict()["parse"],
            [],
        )
        self.assertEqual(message.channel.send.await_args.kwargs["delete_after"], 10)

    async def test_zero_timeout_only_deletes_message(self):
        self.store.set_enabled(10, True)
        self.store.set_timeout(10, 0)
        message = self.make_message()

        self.assertTrue(await self.moderation.handle(message))

        message.delete.assert_awaited_once()
        message.author.timeout.assert_not_awaited()
        self.assertIn("حذف الرسالة فقط", message.channel.send.await_args.args[0])

    async def test_default_disabled_and_exemptions_do_not_moderate(self):
        self.store.set_enabled(10, True)
        self.store.add_allowed_channel(10, 20)
        self.store.add_exempt_role(10, 88)
        cases = [
            self.make_message(),  # allowed channel
            self.make_message(channel_id=21, role_ids=(88,)),
            self.make_message(channel_id=21, administrator=True),
            self.make_message(channel_id=21, manage_messages=True),
            self.make_message(channel_id=21, author_id=999),
            self.make_message(channel_id=21, is_bot=True),
            self.make_message(channel_id=21, in_guild=False),
            self.make_message(channel_id=21, content="hello, no URL here"),
        ]
        for message in cases:
            with self.subTest(message=message):
                self.assertFalse(await self.moderation.handle(message))
                message.delete.assert_not_awaited()
                message.author.timeout.assert_not_awaited()

    async def test_allowed_parent_channel_exempts_thread(self):
        self.store.set_enabled(10, True)
        self.store.add_allowed_channel(10, 19)
        message = self.make_message(channel_id=20, parent_id=19)

        self.assertFalse(await self.moderation.handle(message))
        message.delete.assert_not_awaited()

    async def test_contains_link_handles_domains_and_avoids_email_addresses(self):
        self.assertTrue(contains_link("join at discord.gg/abc123"))
        self.assertTrue(contains_link("visit example.org/resources"))
        self.assertTrue(contains_link("https://example.com"))
        self.assertFalse(contains_link("email me at user@example.com"))
        self.assertFalse(contains_link("plain conversation"))

    def test_admin_slash_command_group_registers_expected_operations(self):
        bot = commands.Bot(command_prefix="!", intents=discord.Intents.none())
        group = setup_anti_link_commands(bot, self.store)
        self.assertEqual(
            {command.name for command in group.commands},
            {
                "enable",
                "disable",
                "set_timeout",
                "allow_channel",
                "remove_channel",
                "exempt_role",
                "remove_role",
                "show",
            },
        )


if __name__ == "__main__":
    unittest.main()