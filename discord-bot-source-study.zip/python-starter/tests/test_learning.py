"""Tests for opt-in profile learning and user-controlled data deletion."""

import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import discord
from discord.ext import commands

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from learning import LearningStore, setup_learning_commands


class LearningStoreTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name) / "nested" / "learning.json"
        self.store = LearningStore(self.path)

    def test_learning_is_off_until_explicit_opt_in(self):
        self.assertFalse(self.store.analyze_message(12, "اسمي محمد وأحب البرمجة"))
        self.assertFalse(self.path.exists())
        self.assertIsNone(self.store.get_profile(12))

    def test_opted_in_learning_extracts_data_without_saving_raw_text(self):
        self.assertTrue(self.store.enable(12))
        message = "اسمي محمد وعمري 20 سنة. أنا من مسقط وأحب البرمجة، كيف أبدأ؟"
        self.assertTrue(self.store.analyze_message(12, message))

        profile = self.store.get_profile(12)
        self.assertEqual(profile["facts"]["name"], "محمد")
        self.assertEqual(profile["facts"]["age"], "20")
        self.assertEqual(profile["facts"]["city"], "مسقط")
        self.assertTrue(profile["facts"]["hobbies"])
        self.assertEqual(profile["message_count"], 1)
        self.assertEqual(profile["questions_asked"], 1)

        saved = self.path.read_text(encoding="utf-8")
        self.assertNotIn(message, saved)
        self.assertIn("محمد", saved)
        self.assertEqual(LearningStore(self.path).get_profile(12), profile)

    def test_disable_stops_analysis_and_clear_deletes_everything(self):
        self.store.enable(12)
        self.store.analyze_message(12, "أحب القراءة والبرمجة")
        self.assertTrue(self.store.disable(12))
        before = self.store.get_profile(12)
        self.assertFalse(self.store.analyze_message(12, "اسمي شخص جديد"))
        self.assertEqual(self.store.get_profile(12), before)
        self.assertEqual(self.store.get_smart_context(12), "")
        self.assertTrue(self.store.clear_user(12))
        self.assertIsNone(self.store.get_profile(12))
        self.assertFalse(self.path.read_text(encoding="utf-8").find('"12"') >= 0)

    def test_forget_removes_matching_profile_fields(self):
        self.store.enable(12)
        self.store.analyze_message(12, "اسمي محمد وعمري 20 وأحب البرمجة")
        self.assertGreaterEqual(self.store.forget(12, "العمر"), 1)
        self.assertEqual(self.store.get_profile(12)["facts"]["age"], "")
        self.assertGreaterEqual(self.store.forget(12, "البرمجة"), 1)
        self.assertNotIn("البرمجة", self.store.get_profile(12)["interests"])

    def test_corrupt_file_is_not_silently_replaced(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text("{broken", encoding="utf-8")
        with self.assertRaises(json.JSONDecodeError):
            LearningStore(self.path)
        self.assertEqual(self.path.read_text(encoding="utf-8"), "{broken")


class LearningCommandTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.store = LearningStore(Path(self.directory.name) / "learning.json")
        self.bot = commands.Bot(command_prefix="!", intents=discord.Intents.default())
        self.developer_id = 42
        setup_learning_commands(self.bot, self.store, self.developer_id)

    async def asyncTearDown(self):
        await self.bot.close()

    def make_context(self, user_id=12):
        return SimpleNamespace(
            author=SimpleNamespace(id=user_id, send=AsyncMock()),
            reply=AsyncMock(),
        )

    async def test_consent_status_and_profile_commands(self):
        self.assertFalse(self.store.is_enabled(12))
        ctx = self.make_context()
        await self.bot.get_command("تعلم").callback(ctx)
        self.assertFalse(self.store.is_enabled(12))
        self.assertIn("قبل تفعيله", ctx.reply.call_args.args[0])

        await self.bot.get_command("تعلم_تشغيل").callback(ctx)
        self.assertTrue(self.store.is_enabled(12))
        self.assertIn("بموافقتك", ctx.reply.call_args.args[0])

        self.store.analyze_message(12, "اسمي محمد وأحب البرمجة")
        await self.bot.get_command("معلوماتي").callback(ctx)
        ctx.author.send.assert_awaited_once()
        self.assertIn("محمد", ctx.author.send.call_args.kwargs["embed"].fields[0].value)

        await self.bot.get_command("تعلم_ايقاف").callback(ctx)
        self.assertFalse(self.store.is_enabled(12))
        self.assertIsNone(self.bot.get_command("اعرف"))

    async def test_clear_command_deletes_only_the_calling_users_profile(self):
        self.store.enable(12)
        self.store.enable(13)
        self.store.analyze_message(12, "اسمي محمد")
        self.store.analyze_message(13, "اسمي علي")
        ctx = self.make_context(12)
        await self.bot.get_command("مسح_معلوماتي").callback(ctx)
        self.assertIsNone(self.store.get_profile(12))
        self.assertEqual(self.store.get_profile(13)["facts"]["name"], "علي")

    async def test_aggregate_stats_are_developer_only(self):
        self.store.enable(12)
        self.store.analyze_message(12, "اسمي محمد وأحب البرمجة، كيف أبدأ؟")
        command = self.bot.get_command("احصائيات_التعلم")
        self.assertTrue(command.extras["developer_control"])
        self.assertFalse(await command.checks[0](SimpleNamespace(
            author=SimpleNamespace(id=99)
        )))
        self.assertTrue(await command.checks[0](SimpleNamespace(
            author=SimpleNamespace(id=self.developer_id)
        )))

        ctx = SimpleNamespace(
            author=SimpleNamespace(id=self.developer_id),
            send=AsyncMock(),
        )
        await command.callback(ctx)
        embed = ctx.send.call_args.kwargs["embed"]
        self.assertIn("لا تعرض معلومات أي عضو", embed.description)
        self.assertIsNone(self.bot.get_command("اعرف"))


if __name__ == "__main__":
    unittest.main()