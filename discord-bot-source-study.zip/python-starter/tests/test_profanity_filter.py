"""Tests for automatic prohibited-language moderation."""

import json
import shutil
import sys
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import discord
from discord.ext import commands

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from profanity_filter import (
    GuildProfanityTermStore,
    ProfanityTermError,
    ProfanityTermStore,
    WARNING_SECONDS,
    contains_bad_word,
    handle_profanity,
    setup_profanity_commands,
)


DEVELOPER_ID = 42


class ProfanityFilterTests(unittest.IsolatedAsyncioTestCase):
    def make_message(
        self,
        *,
        content="You are an idiot!",
        author_id=7,
        administrator=False,
        guild=True,
        guild_id=10,
        bot=False,
    ):
        return SimpleNamespace(
            content=content,
            guild=SimpleNamespace(id=guild_id) if guild else None,
            channel=SimpleNamespace(id=20, send=AsyncMock()),
            author=SimpleNamespace(
                id=author_id,
                bot=bot,
                mention=f"<@{author_id}>",
                guild_permissions=SimpleNamespace(administrator=administrator),
            ),
            delete=AsyncMock(),
        )

    def test_matches_punctuation_case_and_arabic_diacritics(self):
        self.assertEqual(contains_bad_word("You are an IDIOT!"), "idiot")
        self.assertEqual(contains_bad_word("أنت غَبِيٌّ."), "غبي")
        self.assertEqual(contains_bad_word("هذا الشخص الغبي"), "غبي")
        self.assertEqual(contains_bad_word("لعنة عليك"), "لعنة عليك")

    def test_uses_word_boundaries_and_excludes_ambiguous_or_identity_terms(self):
        self.assertIsNone(contains_bad_word("stupidity is a noun"))
        self.assertIsNone(contains_bad_word("الكلب حيوان أليف"))
        self.assertIsNone(contains_bad_word("أنا جاي غداً"))
        self.assertIsNone(contains_bad_word("يهودي وعبدالله"))
        self.assertIsNone(contains_bad_word(None))

    async def test_deletes_matching_message_and_sends_temporary_non_ping_warning(self):
        message = self.make_message(content="انت غبي")

        handled = await handle_profanity(message, DEVELOPER_ID)

        self.assertTrue(handled)
        message.delete.assert_awaited_once()
        message.channel.send.assert_awaited_once()
        warning, kwargs = message.channel.send.call_args
        self.assertIn(message.author.mention, warning[0])
        self.assertEqual(kwargs["delete_after"], WARNING_SECONDS)
        self.assertFalse(kwargs["allowed_mentions"].users)
        self.assertNotIn("غبي", warning[0])

    async def test_developer_administrators_bots_and_direct_messages_are_exempt(self):
        messages = (
            self.make_message(author_id=DEVELOPER_ID),
            self.make_message(administrator=True),
            self.make_message(bot=True),
            self.make_message(guild=False),
        )

        for message in messages:
            self.assertFalse(await handle_profanity(message, DEVELOPER_ID))
            message.delete.assert_not_awaited()
            message.channel.send.assert_not_awaited()

    async def test_nonmatching_message_is_not_moderated(self):
        message = self.make_message(content="A normal message")

        self.assertFalse(await handle_profanity(message, DEVELOPER_ID))
        message.delete.assert_not_awaited()
        message.channel.send.assert_not_awaited()

    async def test_missing_manage_messages_stops_processing_without_claiming_deletion(self):
        message = self.make_message(content="you are stupid")
        message.delete.side_effect = discord.Forbidden(
            SimpleNamespace(status=403, reason="Forbidden", headers={}),
            "missing Manage Messages",
        )

        with self.assertLogs("profanity_filter", level="WARNING"):
            handled = await handle_profanity(message, DEVELOPER_ID)

        self.assertTrue(handled)
        message.channel.send.assert_not_awaited()

    async def test_guild_specific_terms_are_used_for_message_moderation(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            global_store = ProfanityTermStore(
                Path(temp_dir) / "blocked_terms.json",
                base_terms=("idiot",),
            )
            guild_store = GuildProfanityTermStore(
                Path(temp_dir) / "blocked_terms_by_guild.json"
            )
            guild_store.add(
                10,
                "rude phrase",
                DEVELOPER_ID,
                global_store.list_terms(),
            )
            guild_store.remove(
                10,
                "idiot",
                DEVELOPER_ID,
                global_store.list_terms(),
            )
            messages = (
                self.make_message(
                    content="That is a rude phrase!",
                    guild_id=10,
                ),
                self.make_message(
                    content="That is a rude phrase!",
                    guild_id=20,
                ),
                self.make_message(
                    content="You are an idiot",
                    guild_id=10,
                ),
            )

            outcomes = []
            for message in messages:
                terms = guild_store.list_terms(
                    message.guild.id,
                    global_store.list_terms(),
                )
                outcomes.append(await handle_profanity(message, DEVELOPER_ID, terms))

            self.assertEqual(outcomes, [True, False, False])
            messages[0].delete.assert_awaited_once()
            messages[1].delete.assert_not_awaited()
            messages[2].delete.assert_not_awaited()


class ProfanityTermStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.path = Path(self.temp_dir.name) / "blocked_terms.json"
        self.base_terms = ("idiot", "bad phrase", "stupid")
        self.store = ProfanityTermStore(self.path, base_terms=self.base_terms)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_changes_persist_and_builtin_terms_can_be_removed(self):
        self.store.add("Rude phrase", DEVELOPER_ID)
        self.store.remove("idiot", DEVELOPER_ID)

        reopened = ProfanityTermStore(self.path, base_terms=self.base_terms)

        self.assertEqual(reopened.list_terms(), ["bad phrase", "stupid", "rude phrase"])
        self.assertIsNone(contains_bad_word("idiot!", reopened.list_terms()))
        self.assertEqual(
            contains_bad_word("That is a rude, phrase!", reopened.list_terms()),
            "rude phrase",
        )
        self.assertIsNone(
            contains_bad_word("That is a rudely phrase!", reopened.list_terms())
        )
        history = reopened.list_history()
        self.assertEqual(
            [(entry["action"], entry["term"]) for entry in history],
            [("add", "rude phrase"), ("remove", "idiot")],
        )
        self.assertEqual(
            [entry["developer_id"] for entry in history],
            [DEVELOPER_ID, DEVELOPER_ID],
        )
        for entry in history:
            self.assertIsNotNone(datetime.fromisoformat(entry["timestamp"]).tzinfo)
            self.assertEqual(
                set(entry),
                {"developer_id", "timestamp", "action", "term"},
            )

    def test_existing_term_files_load_without_history(self):
        self.path.write_text(
            json.dumps({"added": ["rude phrase"], "removed": ["idiot"]}),
            encoding="utf-8",
        )

        reopened = ProfanityTermStore(self.path, base_terms=self.base_terms)

        self.assertEqual(reopened.list_terms(), ["bad phrase", "stupid", "rude phrase"])
        self.assertEqual(reopened.list_history(), [])

    def test_rejects_duplicate_and_invalid_terms(self):
        with self.assertRaises(ProfanityTermError):
            self.store.add("IDIOT", DEVELOPER_ID)
        with self.assertRaises(ProfanityTermError):
            self.store.add("idiot", DEVELOPER_ID)

        for invalid in ("", "x", "two\nwords", "bad!", "word 2", "a" * 81):
            with self.subTest(invalid=invalid), self.assertRaises(ProfanityTermError):
                self.store.add(invalid, DEVELOPER_ID)
        self.assertEqual(self.store.list_history(), [])

    def test_rejects_removing_missing_terms(self):
        with self.assertRaises(ProfanityTermError):
            self.store.remove("not configured", DEVELOPER_ID)
        self.assertEqual(self.store.list_history(), [])

    def test_invalid_developer_id_does_not_change_terms_or_history(self):
        with self.assertRaises(ProfanityTermError):
            self.store.add("rude phrase", 0)

        self.assertEqual(self.store.list_terms(), list(self.base_terms))
        self.assertEqual(self.store.list_history(), [])

    def test_failed_save_rolls_back_term_change_and_history(self):
        with patch.object(self.store, "_save", side_effect=OSError("disk error")):
            with self.assertRaises(OSError):
                self.store.add("rude phrase", DEVELOPER_ID)

        self.assertEqual(self.store.list_terms(), list(self.base_terms))
        self.assertEqual(self.store.list_history(), [])

    def test_approved_ambiguous_and_identity_exclusions_stay_unmatched(self):
        self.assertIsNone(contains_bad_word("الكلب حيوان أليف"))
        self.assertIsNone(contains_bad_word("أنا جاي غداً"))
        self.assertIsNone(contains_bad_word("يهودي وعبدالله"))


class GuildProfanityTermStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.path = Path(self.temp_dir.name) / "blocked_terms_by_guild.json"
        self.base_terms = ("idiot", "bad phrase")
        self.store = GuildProfanityTermStore(self.path)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_overrides_are_isolated_persisted_and_keep_global_defaults(self):
        self.store.add(10, "rude phrase", DEVELOPER_ID, self.base_terms)
        self.store.remove(10, "idiot", DEVELOPER_ID, self.base_terms)
        self.store.add(20, "another phrase", DEVELOPER_ID, self.base_terms)

        reopened = GuildProfanityTermStore(self.path)

        self.assertEqual(
            reopened.list_terms(10, self.base_terms),
            ["bad phrase", "rude phrase"],
        )
        self.assertEqual(
            reopened.list_terms(20, self.base_terms),
            ["idiot", "bad phrase", "another phrase"],
        )
        self.assertEqual(
            reopened.list_terms(30, self.base_terms),
            list(self.base_terms),
        )
        self.assertEqual(
            [(entry["action"], entry["term"]) for entry in reopened.list_history(10)],
            [("add", "rude phrase"), ("remove", "idiot")],
        )
        self.assertEqual(
            [(entry["action"], entry["term"]) for entry in reopened.list_history(20)],
            [("add", "another phrase")],
        )

    def test_lists_only_current_guild_overrides_without_changing_global_terms(self):
        self.store.add(10, "rude phrase", DEVELOPER_ID, self.base_terms)
        self.store.remove(10, "idiot", DEVELOPER_ID, self.base_terms)
        self.store.add(20, "another phrase", DEVELOPER_ID, self.base_terms)

        self.assertEqual(
            self.store.list_overrides(10, self.base_terms),
            {"added": ["rude phrase"], "removed": ["idiot"]},
        )
        self.assertEqual(
            self.store.list_overrides(20, self.base_terms),
            {"added": ["another phrase"], "removed": []},
        )
        self.assertEqual(self.base_terms, ("idiot", "bad phrase"))

    def test_classifies_saved_overrides_against_current_global_terms_read_only(self):
        original_global_terms = (
            "idiot",
            "bad phrase",
            "stupid",
            "obsolete phrase",
        )
        self.store.add(10, "rude phrase", DEVELOPER_ID, original_global_terms)
        self.store.add(10, "local phrase", DEVELOPER_ID, original_global_terms)
        self.store.remove(10, "idiot", DEVELOPER_ID, original_global_terms)
        self.store.remove(10, "stupid", DEVELOPER_ID, original_global_terms)
        self.store.remove(10, "obsolete phrase", DEVELOPER_ID, original_global_terms)
        updated_global_terms = ("bad phrase", "stupid", "RUDE phrase")
        saved_before = self.store.list_saved_overrides(10)
        effective_before = self.store.list_terms(10, updated_global_terms)

        statuses = self.store.list_override_status(10, updated_global_terms)

        self.assertEqual(
            statuses,
            {
                "added_effective": ["local phrase"],
                "added_retained": ["rude phrase"],
                "removed_effective": ["stupid"],
                "removed_retained": ["idiot", "obsolete phrase"],
            },
        )
        self.assertEqual(self.store.list_saved_overrides(10), saved_before)
        self.assertEqual(
            self.store.list_terms(10, updated_global_terms),
            effective_before,
        )

    def test_reset_backs_up_one_guild_and_records_persistent_history(self):
        self.store.add(10, "rude phrase", DEVELOPER_ID, self.base_terms)
        self.store.remove(10, "idiot", DEVELOPER_ID, self.base_terms)
        self.store.add(20, "another phrase", DEVELOPER_ID, self.base_terms)
        global_terms = list(self.base_terms)

        result = self.store.reset_guild(10, DEVELOPER_ID)

        self.assertEqual(result["added"], ["rude phrase"])
        self.assertEqual(result["removed"], ["idiot"])
        self.assertEqual(
            self.store.list_terms(10, self.base_terms),
            list(self.base_terms),
        )
        self.assertEqual(
            self.store.list_terms(20, self.base_terms),
            ["idiot", "bad phrase", "another phrase"],
        )
        self.assertEqual(list(self.base_terms), global_terms)

        backup_path = self.store.backup_dir / result["backup"]
        backup = json.loads(backup_path.read_text(encoding="utf-8"))
        self.assertEqual(backup["guild_id"], "10")
        self.assertEqual(backup["state"]["added"], ["rude phrase"])
        self.assertEqual(backup["state"]["removed"], ["idiot"])
        self.assertEqual(
            [
                (entry["action"], entry.get("term"))
                for entry in self.store.list_history(10)
            ],
            [
                ("add", "rude phrase"),
                ("remove", "idiot"),
                ("reset", None),
            ],
        )
        reset_entry = self.store.list_history(10)[-1]
        self.assertEqual(reset_entry["added"], ["rude phrase"])
        self.assertEqual(reset_entry["removed"], ["idiot"])
        self.assertEqual(reset_entry["backup"], backup_path.name)
        self.assertEqual(reset_entry["developer_id"], DEVELOPER_ID)
        self.assertIsNotNone(datetime.fromisoformat(reset_entry["timestamp"]).tzinfo)

        reopened = GuildProfanityTermStore(self.path)
        self.assertEqual(reopened.list_terms(10, self.base_terms), list(self.base_terms))
        self.assertEqual(reopened.list_history(10)[-1], reset_entry)

    def test_reset_aborts_when_backup_fails_and_rolls_back_when_save_fails(self):
        self.store.add(10, "rude phrase", DEVELOPER_ID, self.base_terms)
        self.store.remove(10, "idiot", DEVELOPER_ID, self.base_terms)
        original_history = self.store.list_history(10)

        with patch.object(
            self.store,
            "_write_backup",
            side_effect=OSError("disk error"),
        ):
            with self.assertRaises(OSError):
                self.store.reset_guild(10, DEVELOPER_ID)

        self.assertEqual(
            self.store.list_terms(10, self.base_terms),
            ["bad phrase", "rude phrase"],
        )
        self.assertEqual(self.store.list_history(10), original_history)

        with patch.object(self.store, "_save", side_effect=OSError("disk error")):
            with self.assertRaises(OSError):
                self.store.reset_guild(10, DEVELOPER_ID)

        self.assertEqual(
            self.store.list_terms(10, self.base_terms),
            ["bad phrase", "rude phrase"],
        )
        self.assertEqual(self.store.list_history(10), original_history)
        backups = list(self.store.backup_dir.glob("10_*.json"))
        self.assertEqual(len(backups), 1)
        self.assertEqual(
            json.loads(backups[0].read_text(encoding="utf-8"))["state"]["removed"],
            ["idiot"],
        )

    def test_reset_without_saved_overrides_does_not_write_history_or_backup(self):
        self.assertIsNone(self.store.reset_guild(10, DEVELOPER_ID))
        self.assertEqual(self.store.list_history(10), [])
        self.assertFalse(self.store.backup_dir.exists())

    def test_can_restore_a_global_term_removed_only_in_this_guild(self):
        self.store.remove(10, "idiot", DEVELOPER_ID, self.base_terms)
        self.store.add(10, "IDIOT", DEVELOPER_ID, self.base_terms)

        self.assertEqual(self.store.list_terms(10, self.base_terms), list(self.base_terms))
        self.assertEqual(
            [(entry["action"], entry["term"]) for entry in self.store.list_history(10)],
            [("remove", "idiot"), ("add", "idiot")],
        )

    def test_server_can_restore_a_term_removed_from_global_list(self):
        self.store.remove(10, "idiot", DEVELOPER_ID, self.base_terms)
        updated_base_terms = ("bad phrase",)

        self.store.add(10, "idiot", DEVELOPER_ID, updated_base_terms)
        reopened = GuildProfanityTermStore(self.path)

        self.assertEqual(
            reopened.list_terms(10, updated_base_terms),
            ["bad phrase", "idiot"],
        )

    def test_rejects_invalid_guild_ids_and_rolls_back_failed_save(self):
        with self.assertRaises(ProfanityTermError):
            self.store.add(0, "rude phrase", DEVELOPER_ID, self.base_terms)

        with patch.object(self.store, "_save", side_effect=OSError("disk error")):
            with self.assertRaises(OSError):
                self.store.add(10, "rude phrase", DEVELOPER_ID, self.base_terms)

        self.assertEqual(self.store.list_terms(10, self.base_terms), list(self.base_terms))
        self.assertEqual(self.store.list_history(10), [])

    def test_matching_uses_only_the_message_guilds_effective_terms(self):
        self.store.add(10, "rude phrase", DEVELOPER_ID, self.base_terms)
        self.store.remove(10, "idiot", DEVELOPER_ID, self.base_terms)

        guild_message = ProfanityFilterTests.make_message(
            self, content="That is a rude phrase!", guild_id=10
        )
        other_guild_message = ProfanityFilterTests.make_message(
            self, content="That is a rude phrase!", guild_id=20
        )
        removed_global_message = ProfanityFilterTests.make_message(
            self, content="You are an idiot", guild_id=10
        )

        terms_for_guild = self.store.list_terms(
            guild_message.guild.id, self.base_terms
        )
        terms_for_other = self.store.list_terms(
            other_guild_message.guild.id, self.base_terms
        )
        self.assertTrue(
            contains_bad_word(guild_message.content, terms_for_guild)
        )
        self.assertIsNone(
            contains_bad_word(other_guild_message.content, terms_for_other)
        )
        self.assertIsNone(
            contains_bad_word(
                removed_global_message.content,
                self.store.list_terms(10, self.base_terms),
            )
        )


class ProfanityCommandTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.store = ProfanityTermStore(
            Path(self.temp_dir.name) / "blocked_terms.json",
            base_terms=("idiot",),
        )
        self.bot = commands.Bot(
            command_prefix="!",
            intents=discord.Intents.none(),
        )
        self.group = setup_profanity_commands(
            self.bot,
            self.store,
            DEVELOPER_ID,
        )

    def tearDown(self):
        self.temp_dir.cleanup()

    def interaction(self, user_id=DEVELOPER_ID, guild_id=10):
        return SimpleNamespace(
            user=SimpleNamespace(id=user_id, send=AsyncMock()),
            guild_id=guild_id,
            response=SimpleNamespace(
                send_message=AsyncMock(),
                defer=AsyncMock(),
            ),
            followup=SimpleNamespace(send=AsyncMock()),
            edit_original_response=AsyncMock(),
        )

    async def test_only_developer_can_add_remove_and_list_terms(self):
        for command_name, args in (
            ("add", ("rude phrase",)),
            ("remove", ("idiot",)),
            ("list", ()),
            ("history", ()),
        ):
            interaction = self.interaction(user_id=99)
            command = self.group.get_command(command_name)

            await command.callback(interaction, *args)

            interaction.response.send_message.assert_awaited_once()
            self.assertTrue(
                interaction.response.send_message.call_args.kwargs["ephemeral"]
            )
        self.assertEqual(self.store.list_terms(), ["idiot"])
        self.assertEqual(self.store.list_history(), [])

    async def test_developer_can_add_remove_and_list_privately(self):
        add = self.interaction()
        await self.group.get_command("add").callback(add, "rude phrase")
        self.assertIn("أُضيفت", add.response.send_message.call_args.args[0])
        self.assertIn("rude phrase", self.store.list_terms())

        listing = self.interaction()
        await self.group.get_command("list").callback(listing)
        self.assertIn("rude phrase", listing.response.send_message.call_args.args[0])
        self.assertTrue(listing.response.send_message.call_args.kwargs["ephemeral"])

        remove = self.interaction()
        await self.group.get_command("remove").callback(remove, "rude phrase")
        self.assertNotIn("rude phrase", self.store.list_terms())

        history = self.interaction()
        await self.group.get_command("history").callback(history)
        history_text = history.response.send_message.call_args.args[0]
        self.assertIn("إضافة", history_text)
        self.assertIn("إزالة", history_text)
        self.assertIn(str(DEVELOPER_ID), history_text)
        self.assertIn("rude phrase", history_text)
        self.assertTrue(history.response.send_message.call_args.kwargs["ephemeral"])

    async def test_only_developer_can_view_change_history(self):
        self.store.add("rude phrase", DEVELOPER_ID)
        interaction = self.interaction(user_id=99)

        await self.group.get_command("history").callback(interaction)

        response = interaction.response.send_message.call_args
        self.assertIn("خاص بمطور البوت", response.args[0])
        self.assertTrue(response.kwargs["ephemeral"])
        self.assertNotIn("rude phrase", response.args[0])


class GuildProfanityCommandTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.global_store = ProfanityTermStore(
            Path(self.temp_dir.name) / "blocked_terms.json",
            base_terms=("idiot",),
        )
        self.guild_store = GuildProfanityTermStore(
            Path(self.temp_dir.name) / "blocked_terms_by_guild.json"
        )
        self.bot = commands.Bot(
            command_prefix="!",
            intents=discord.Intents.none(),
        )
        self.group = setup_profanity_commands(
            self.bot,
            self.global_store,
            DEVELOPER_ID,
            guild_store=self.guild_store,
        )

    def tearDown(self):
        self.temp_dir.cleanup()

    @staticmethod
    def interaction(user_id=DEVELOPER_ID, guild_id=10):
        return SimpleNamespace(
            user=SimpleNamespace(id=user_id, send=AsyncMock()),
            guild_id=guild_id,
            response=SimpleNamespace(
                send_message=AsyncMock(),
                edit_message=AsyncMock(),
                defer=AsyncMock(),
            ),
            followup=SimpleNamespace(send=AsyncMock()),
            original_response=AsyncMock(
                return_value=SimpleNamespace(edit=AsyncMock())
            ),
            edit_original_response=AsyncMock(),
        )

    async def test_server_commands_are_developer_only_and_scoped_to_current_guild(self):
        unauthorized = self.interaction(user_id=99)
        await self.group.get_command("server-add").callback(
            unauthorized, "rude phrase"
        )
        self.assertIn("خاص بمطور البوت", unauthorized.response.send_message.call_args.args[0])
        unauthorized_overrides = self.interaction(user_id=99)
        await self.group.get_command("server-overrides").callback(
            unauthorized_overrides
        )
        self.assertIn(
            "خاص بمطور البوت",
            unauthorized_overrides.response.send_message.call_args.args[0],
        )
        self.assertEqual(
            self.guild_store.list_terms(10, self.global_store.list_terms()),
            ["idiot"],
        )

        add = self.interaction(guild_id=10)
        await self.group.get_command("server-add").callback(add, "rude phrase")
        remove = self.interaction(guild_id=10)
        await self.group.get_command("server-remove").callback(remove, "idiot")
        listing = self.interaction(guild_id=10)
        await self.group.get_command("server-list").callback(listing)
        history = self.interaction(guild_id=10)
        await self.group.get_command("server-history").callback(history)

        self.assertIn("rude phrase", listing.response.send_message.call_args.args[0])
        self.assertNotIn("idiot", listing.response.send_message.call_args.args[0])
        self.assertIn("rude phrase", history.response.send_message.call_args.args[0])
        self.assertEqual(
            self.guild_store.list_terms(20, self.global_store.list_terms()),
            ["idiot"],
        )
        for interaction in (add, remove, listing, history):
            self.assertTrue(
                interaction.response.send_message.call_args.kwargs["ephemeral"]
            )

    async def test_server_overrides_command_is_private_and_scoped_to_current_guild(self):
        global_terms = self.global_store.list_terms()
        self.guild_store.add(10, "rude phrase", DEVELOPER_ID, global_terms)
        self.guild_store.remove(10, "idiot", DEVELOPER_ID, global_terms)
        self.guild_store.add(20, "another phrase", DEVELOPER_ID, global_terms)

        interaction = self.interaction(guild_id=10)
        await self.group.get_command("server-overrides").callback(interaction)

        response = interaction.response.send_message.call_args
        self.assertIn("rude phrase", response.args[0])
        self.assertIn("idiot", response.args[0])
        self.assertNotIn("another phrase", response.args[0])
        self.assertTrue(response.kwargs["ephemeral"])
        self.assertEqual(self.global_store.list_terms(), ["idiot"])

    async def test_server_overrides_shows_retained_and_effective_rules_without_changes(
        self,
    ):
        initial_global_terms = self.global_store.list_terms()
        self.guild_store.add(10, "rude phrase", DEVELOPER_ID, initial_global_terms)
        self.guild_store.add(10, "local phrase", DEVELOPER_ID, initial_global_terms)
        self.guild_store.remove(10, "idiot", DEVELOPER_ID, initial_global_terms)

        self.global_store.add("obsolete phrase", DEVELOPER_ID)
        self.global_store.add("active exclusion", DEVELOPER_ID)
        expanded_global_terms = self.global_store.list_terms()
        self.guild_store.remove(
            10, "obsolete phrase", DEVELOPER_ID, expanded_global_terms
        )
        self.guild_store.remove(
            10, "active exclusion", DEVELOPER_ID, expanded_global_terms
        )
        self.global_store.remove("idiot", DEVELOPER_ID)
        self.global_store.remove("obsolete phrase", DEVELOPER_ID)
        self.global_store.add("rude phrase", DEVELOPER_ID)
        saved_before = self.guild_store.list_saved_overrides(10)
        global_before = self.global_store.list_terms()

        interaction = self.interaction(guild_id=10)
        await self.group.get_command("server-overrides").callback(interaction)

        response = interaction.response.send_message.call_args
        text = response.args[0]
        self.assertIn("local phrase", text)
        self.assertIn("rude phrase", text)
        self.assertIn("active exclusion", text)
        self.assertIn("idiot", text)
        self.assertIn("obsolete phrase", text)
        self.assertIn("إضافات محلية فعالة الآن", text)
        self.assertIn("موجودة أيضاً في القائمة العامة", text)
        self.assertIn("استثناءات فعالة من القائمة العامة", text)
        self.assertIn("بلا تطابق حالي في القائمة العامة", text)
        self.assertIn("دون تغيير أي إعداد", text)
        active_additions = text.split(
            "إضافات محلية فعالة الآن", maxsplit=1
        )[1].split("إضافات محفوظة موجودة أيضاً", maxsplit=1)[0]
        retained_additions = text.split(
            "إضافات محفوظة موجودة أيضاً", maxsplit=1
        )[1].split("استثناءات فعالة من القائمة العامة", maxsplit=1)[0]
        effective_exclusions = text.split(
            "استثناءات فعالة من القائمة العامة", maxsplit=1
        )[1].split("استثناءات محفوظة بلا تطابق", maxsplit=1)[0]
        retained_exclusions = text.split(
            "استثناءات محفوظة بلا تطابق", maxsplit=1
        )[1]
        self.assertIn("local phrase", active_additions)
        self.assertNotIn("rude phrase", active_additions)
        self.assertIn("rude phrase", retained_additions)
        self.assertIn("active exclusion", effective_exclusions)
        self.assertIn("idiot", retained_exclusions)
        self.assertIn("obsolete phrase", retained_exclusions)
        self.assertTrue(response.kwargs["ephemeral"])
        self.assertEqual(self.guild_store.list_saved_overrides(10), saved_before)
        self.assertEqual(self.global_store.list_terms(), global_before)

    async def test_server_compare_privately_shows_selected_server_overrides_without_changes(
        self,
    ):
        base_terms = self.global_store.list_terms()
        self.guild_store.add(10, "rude phrase", DEVELOPER_ID, base_terms)
        self.guild_store.remove(10, "idiot", DEVELOPER_ID, base_terms)
        self.guild_store.add(20, "another phrase", DEVELOPER_ID, base_terms)
        before_global = self.global_store.list_terms()
        before_first = self.guild_store.list_saved_overrides(10)
        before_second = self.guild_store.list_saved_overrides(20)
        self.bot.get_guild = lambda guild_id: {
            10: SimpleNamespace(name="Alpha server"),
            20: SimpleNamespace(name="Beta server"),
        }.get(guild_id)

        interaction = self.interaction()
        await self.group.get_command("server-compare").callback(
            interaction,
            server_a_id=10,
            server_b_id=20,
        )

        response = interaction.response.send_message.call_args
        text = response.args[0]
        self.assertIn("Alpha server", text)
        self.assertIn("ID: 10", text)
        self.assertIn("rude phrase", text)
        self.assertIn("idiot", text)
        self.assertIn("Beta server", text)
        self.assertIn("ID: 20", text)
        self.assertIn("another phrase", text)
        self.assertIn("دون تغيير أي إعداد", text)
        self.assertTrue(response.kwargs["ephemeral"])
        self.assertEqual(self.global_store.list_terms(), before_global)
        self.assertEqual(self.guild_store.list_saved_overrides(10), before_first)
        self.assertEqual(self.guild_store.list_saved_overrides(20), before_second)

    async def test_server_compare_is_developer_only(self):
        self.bot.get_guild = lambda guild_id: SimpleNamespace(name="Private server")
        interaction = self.interaction(user_id=99)

        await self.group.get_command("server-compare").callback(
            interaction,
            server_a_id=10,
            server_b_id=20,
        )

        response = interaction.response.send_message.call_args
        self.assertIn("خاص بمطور البوت", response.args[0])
        self.assertTrue(response.kwargs["ephemeral"])
        self.assertNotIn("Private server", response.args[0])

    async def test_server_compare_rejects_same_or_unavailable_servers_privately(self):
        same = self.interaction()
        await self.group.get_command("server-compare").callback(
            same,
            server_a_id=10,
            server_b_id=10,
        )
        self.assertIn(
            "سيرفرين مختلفين",
            same.response.send_message.call_args.args[0],
        )
        self.assertTrue(
            same.response.send_message.call_args.kwargs["ephemeral"]
        )

        self.bot.get_guild = lambda guild_id: (
            SimpleNamespace(name="Alpha server") if guild_id == 10 else None
        )
        unavailable = self.interaction()
        await self.group.get_command("server-compare").callback(
            unavailable,
            server_a_id=10,
            server_b_id=20,
        )
        self.assertIn(
            "20",
            unavailable.response.send_message.call_args.args[0],
        )
        self.assertTrue(
            unavailable.response.send_message.call_args.kwargs["ephemeral"]
        )

    async def test_server_reset_previews_then_confirms_with_backup_and_audit(self):
        base_terms = self.global_store.list_terms()
        self.guild_store.add(10, "rude phrase", DEVELOPER_ID, base_terms)
        self.guild_store.remove(10, "idiot", DEVELOPER_ID, base_terms)
        self.guild_store.add(20, "another phrase", DEVELOPER_ID, base_terms)

        preview = self.interaction(guild_id=10)
        await self.group.get_command("server-reset").callback(preview)

        preview_args = preview.response.send_message.call_args
        preview_text = preview_args.args[0]
        self.assertIn("rude phrase", preview_text)
        self.assertIn("idiot", preview_text)
        self.assertIn("القائمة العامة", preview_text)
        self.assertIn("السيرفرات الأخرى", preview_text)
        self.assertTrue(preview_args.kwargs["ephemeral"])
        self.assertEqual(list(self.guild_store.backup_dir.glob("10_*.json")), [])
        view = preview_args.kwargs["view"]
        confirm_button = next(
            child for child in view.children if child.label == "تأكيد إعادة الضبط"
        )
        confirm = self.interaction(guild_id=10)
        exported_backups = []

        async def capture_export(**kwargs):
            backup_file = kwargs["file"]
            backup_file.fp.seek(0)
            exported_backups.append(backup_file.fp.read())

        confirm.user.send.side_effect = capture_export
        await confirm_button.callback(confirm)

        self.assertIn("أُعيد", confirm.edit_original_response.call_args.kwargs["content"])
        confirm.user.send.assert_awaited_once()
        self.assertIn("10", confirm.user.send.call_args.kwargs["content"])
        self.assertEqual(len(exported_backups), 1)
        self.assertEqual(
            self.guild_store.list_terms(10, base_terms),
            base_terms,
        )
        self.assertEqual(
            self.guild_store.list_terms(20, base_terms),
            ["idiot", "another phrase"],
        )
        self.assertEqual(self.global_store.list_terms(), base_terms)
        self.assertEqual(len(list(self.guild_store.backup_dir.glob("10_*.json"))), 1)
        history = self.guild_store.list_history(10)
        self.assertEqual(history[-1]["action"], "reset")
        self.assertEqual(history[-1]["added"], ["rude phrase"])
        self.assertEqual(history[-1]["removed"], ["idiot"])

        # The downloaded DM attachment can restore the prior state on a
        # replacement VM without access to the original local backup directory.
        exported_payload = json.loads(exported_backups[0])
        self.assertEqual(exported_payload["guild_id"], "10")
        self.assertEqual(exported_payload["state"]["added"], ["rude phrase"])
        shutil.rmtree(self.guild_store.backup_dir)
        replacement_path = Path(self.temp_dir.name) / "replacement_server_terms.json"
        replacement_path.write_text(
            json.dumps(
                {
                    "guilds": {
                        exported_payload["guild_id"]: exported_payload["state"]
                    }
                }
            ),
            encoding="utf-8",
        )
        replacement_store = GuildProfanityTermStore(replacement_path)
        self.assertEqual(
            replacement_store.list_saved_overrides(10),
            {"added": ["rude phrase"], "removed": ["idiot"]},
        )

        history_interaction = self.interaction(guild_id=10)
        await self.group.get_command("server-history").callback(history_interaction)
        self.assertIn(
            "إعادة ضبط",
            history_interaction.response.send_message.call_args.args[0],
        )

    async def test_server_reset_cancellation_and_non_developer_confirmation_change_nothing(
        self,
    ):
        base_terms = self.global_store.list_terms()
        self.guild_store.add(10, "rude phrase", DEVELOPER_ID, base_terms)

        preview = self.interaction(guild_id=10)
        await self.group.get_command("server-reset").callback(preview)
        view = preview.response.send_message.call_args.kwargs["view"]
        cancel_button = next(child for child in view.children if child.label == "إلغاء")
        cancel = self.interaction(guild_id=10)
        await cancel_button.callback(cancel)
        self.assertIn(
            "أُلغيت",
            cancel.response.edit_message.call_args.kwargs["content"],
        )
        self.assertEqual(
            self.guild_store.list_terms(10, base_terms),
            ["idiot", "rude phrase"],
        )
        self.assertFalse(self.guild_store.backup_dir.exists())

        second_preview = self.interaction(guild_id=10)
        await self.group.get_command("server-reset").callback(second_preview)
        second_view = second_preview.response.send_message.call_args.kwargs["view"]
        confirm_button = next(
            child
            for child in second_view.children
            if child.label == "تأكيد إعادة الضبط"
        )
        intruder = self.interaction(user_id=99, guild_id=10)
        await confirm_button.callback(intruder)
        self.assertIn(
            "مطور البوت",
            intruder.response.send_message.call_args.args[0],
        )
        self.assertEqual(
            self.guild_store.list_terms(10, base_terms),
            ["idiot", "rude phrase"],
        )
        self.assertFalse(self.guild_store.backup_dir.exists())

    async def test_server_reset_refuses_a_stale_preview(self):
        base_terms = self.global_store.list_terms()
        self.guild_store.add(10, "rude phrase", DEVELOPER_ID, base_terms)

        preview = self.interaction(guild_id=10)
        await self.group.get_command("server-reset").callback(preview)
        view = preview.response.send_message.call_args.kwargs["view"]
        self.guild_store.add(10, "new phrase", DEVELOPER_ID, base_terms)

        confirm_button = next(
            child
            for child in view.children
            if child.label == "تأكيد إعادة الضبط"
        )
        confirm = self.interaction(guild_id=10)
        await confirm_button.callback(confirm)

        self.assertIn(
            "تغيرت تعديلات هذا السيرفر منذ المعاينة",
            confirm.edit_original_response.call_args.kwargs["content"],
        )
        self.assertEqual(
            self.guild_store.list_terms(10, base_terms),
            ["idiot", "rude phrase", "new phrase"],
        )
        self.assertFalse(self.guild_store.backup_dir.exists())
        self.assertNotIn(
            "reset",
            [entry["action"] for entry in self.guild_store.list_history(10)],
        )

    async def test_server_reset_aborts_if_private_backup_delivery_fails(self):
        base_terms = self.global_store.list_terms()
        self.guild_store.add(10, "rude phrase", DEVELOPER_ID, base_terms)
        preview = self.interaction(guild_id=10)
        await self.group.get_command("server-reset").callback(preview)
        view = preview.response.send_message.call_args.kwargs["view"]
        confirm_button = next(
            child for child in view.children if child.label == "تأكيد إعادة الضبط"
        )
        confirm = self.interaction(guild_id=10)
        confirm.user.send.side_effect = discord.Forbidden(
            SimpleNamespace(status=403, reason="Forbidden", headers={}),
            "Direct messages are disabled",
        )

        with self.assertLogs("profanity_filter", level="ERROR"):
            await confirm_button.callback(confirm)

        self.assertIn(
            "لم يتغير المرشح",
            confirm.edit_original_response.call_args.kwargs["content"],
        )
        self.assertEqual(
            self.guild_store.list_saved_overrides(10),
            {"added": ["rude phrase"], "removed": []},
        )
        self.assertNotIn(
            "reset",
            [entry["action"] for entry in self.guild_store.list_history(10)],
        )

    async def test_server_reset_aborts_if_local_backup_cannot_be_saved(self):
        base_terms = self.global_store.list_terms()
        self.guild_store.add(10, "rude phrase", DEVELOPER_ID, base_terms)
        preview = self.interaction(guild_id=10)
        await self.group.get_command("server-reset").callback(preview)
        view = preview.response.send_message.call_args.kwargs["view"]
        confirm_button = next(
            child for child in view.children if child.label == "تأكيد إعادة الضبط"
        )
        confirm = self.interaction(guild_id=10)

        with (
            patch.object(
                self.guild_store,
                "_write_backup",
                side_effect=OSError("disk error"),
            ),
            self.assertLogs("profanity_filter", level="ERROR"),
        ):
            await confirm_button.callback(confirm)

        confirm.user.send.assert_not_awaited()
        self.assertIn(
            "لم يتغير المرشح",
            confirm.edit_original_response.call_args.kwargs["content"],
        )
        self.assertEqual(
            self.guild_store.list_saved_overrides(10),
            {"added": ["rude phrase"], "removed": []},
        )
        self.assertNotIn(
            "reset",
            [entry["action"] for entry in self.guild_store.list_history(10)],
        )

    async def test_server_reset_timeout_changes_nothing_and_disables_buttons(self):
        base_terms = self.global_store.list_terms()
        self.guild_store.add(10, "rude phrase", DEVELOPER_ID, base_terms)
        preview = self.interaction(guild_id=10)
        await self.group.get_command("server-reset").callback(preview)
        view = preview.response.send_message.call_args.kwargs["view"]
        view.message = SimpleNamespace(edit=AsyncMock())

        await view.on_timeout()

        self.assertTrue(view.finished)
        self.assertTrue(all(child.disabled for child in view.children))
        self.assertIn(
            "انتهت مهلة التأكيد",
            view.message.edit.call_args.kwargs["content"],
        )
        self.assertEqual(
            self.guild_store.list_terms(10, base_terms),
            ["idiot", "rude phrase"],
        )
        self.assertFalse(self.guild_store.backup_dir.exists())

    async def test_server_commands_reject_interactions_without_a_guild(self):
        interaction = self.interaction(guild_id=None)

        await self.group.get_command("server-add").callback(
            interaction, "rude phrase"
        )

        self.assertIn(
            "داخل السيرفر",
            interaction.response.send_message.call_args.args[0],
        )
        self.assertEqual(
            self.guild_store.list_terms(10, self.global_store.list_terms()),
            ["idiot"],
        )


if __name__ == "__main__":
    unittest.main()