"""Integration checks against the development database; never replace its state."""

import os
import json
import sys
import tempfile
import threading
import unittest
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from casino_engine import CasinoError, transfer
from game_store import PostgresGameStore
from migrate_game_data import import_game_data


@unittest.skipUnless(os.environ.get("DATABASE_URL"), "requires development DATABASE_URL")
class PostgresGameStoreTests(unittest.TestCase):
    def test_concurrent_transfers_cannot_spend_same_balance_twice(self):
        uid = str(uuid.uuid4().int)
        recipients = [str(uuid.uuid4().int) for _ in range(2)]
        stores = [
            PostgresGameStore(Path(tempfile.gettempdir()) / f"{uuid.uuid4()}.json",
                              os.environ["DATABASE_URL"])
            for _ in range(2)
        ]
        try:
            with stores[0].transaction() as data:
                stores[0].user(data, uid)["money"] = 1000
            barrier = threading.Barrier(2)
            results = []

            def send(store, recipient):
                barrier.wait()
                try:
                    transfer(store, uid, recipient, 800)
                    results.append("sent")
                except CasinoError:
                    results.append("insufficient")

            threads = [
                threading.Thread(target=send, args=(store, recipient))
                for store, recipient in zip(stores, recipients)
            ]
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join(timeout=15)
                self.assertFalse(thread.is_alive())
            self.assertCountEqual(results, ["sent", "insufficient"])
            state = stores[0].snapshot()
            self.assertEqual(state["users"][uid]["money"], 200)
            self.assertEqual(
                sum(state["users"][recipient]["money"] for recipient in recipients
                    if recipient in state["users"]),
                5800,
            )
            with tempfile.TemporaryDirectory() as directory:
                source = Path(directory) / "old.json"
                source.write_text(json.dumps({"users": {}}), encoding="utf-8")
                with self.assertRaisesRegex(RuntimeError, "already has game state"):
                    import_game_data(source, os.environ["DATABASE_URL"])
        finally:
            with stores[0].transaction() as data:
                for user_id in (uid, *recipients):
                    data["users"].pop(user_id, None)


if __name__ == "__main__":
    unittest.main()