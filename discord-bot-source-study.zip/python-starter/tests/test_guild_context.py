import asyncio
from datetime import datetime, timezone
from types import SimpleNamespace
import unittest
from unittest.mock import AsyncMock

import discord
from discord.ext import commands

from guild_context import build_guild_context, setup_guild_info_commands


class GuildContextTests(unittest.TestCase):
    def setUp(self):
        self.requester = SimpleNamespace(id=10)

        def channel(name, visible):
            return SimpleNamespace(
                name=name,
                type=SimpleNamespace(name="text"),
                permissions_for=lambda member: SimpleNamespace(view_channel=visible),
            )

        self.visible_channel = channel("general", True)
        self.private_channel = channel("staff-only", False)
        self.visible_voice_channel = channel("hangout", True)
        self.private_voice_channel = channel("staff-voice", False)
        self.guild = SimpleNamespace(
            id=42,
            name="Test Server",
            member_count=25,
            created_at=datetime(2020, 1, 2, tzinfo=timezone.utc),
            owner=SimpleNamespace(name="owner", display_name="Server Owner"),
            text_channels=[self.visible_channel, self.private_channel],
            voice_channels=[self.visible_voice_channel, self.private_voice_channel],
            stage_channels=[],
            roles=[
                SimpleNamespace(name="@everyone", managed=False, position=0),
                SimpleNamespace(name="Member", managed=False, position=1),
                SimpleNamespace(name="Integration", managed=True, position=9),
            ],
        )

    def test_context_contains_guild_facts_but_filters_hidden_channels(self):
        context = build_guild_context(
            self.guild,
            channel=self.visible_channel,
            requester=self.requester,
        )
        self.assertIn("Test Server", context)
        self.assertIn("25", context)
        self.assertIn("2020-01-02", context)
        self.assertIn("Server Owner", context)
        self.assertIn("#general", context)
        self.assertIn("hangout", context)
        self.assertNotIn("staff-only", context)
        self.assertNotIn("staff-voice", context)
        self.assertNotIn("Integration", context)

    def test_direct_messages_have_no_server_context(self):
        self.assertEqual(build_guild_context(None), "")

    def test_command_setup_is_idempotent(self):
        bot = commands.Bot(command_prefix="!", intents=discord.Intents.none())
        setup_guild_info_commands(bot, developer_id=99)
        first_count = len(bot.commands)
        setup_guild_info_commands(bot, developer_id=99)
        self.assertEqual(len(bot.commands), first_count)
        self.assertIsNotNone(bot.get_command("server"))
        self.assertIsNotNone(bot.get_command("whereami"))
        self.assertIsNotNone(bot.get_command("servers"))

    def test_whereami_includes_the_current_channel(self):
        bot = commands.Bot(command_prefix="!", intents=discord.Intents.none())
        setup_guild_info_commands(bot, developer_id=99)
        command = bot.get_command("whereami")
        ctx = SimpleNamespace(
            guild=SimpleNamespace(name="Test Server"),
            channel=SimpleNamespace(name="general"),
            reply=AsyncMock(),
        )

        asyncio.run(command.callback(ctx))

        response = ctx.reply.await_args.args[0]
        self.assertIn("Test Server", response)
        self.assertIn("#general", response)


if __name__ == "__main__":
    unittest.main()