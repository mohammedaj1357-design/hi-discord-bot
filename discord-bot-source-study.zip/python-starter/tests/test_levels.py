"""Tests for the persistent, guild-scoped level system."""

import asyncio
import sys
import tempfile
import unittest
from types import SimpleNamespace
from pathlib import Path
from unittest.mock import AsyncMock, Mock

import discord
from discord.ext import commands

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from game_store import GameStore
from levels import (
    LevelSystem,
    role_reward_block_reason,
    send_level_up_notice,
    setup_commands,
    title_for_level,
    xp_for_level,
)


class FixedRng:
    def randint(self, low, high):
        return low


class FakeRole:
    def __init__(self, role_id, position, *, managed=False, default=False):
        self.id = role_id
        self.position = position
        self.managed = managed
        self.default = default

    def __ge__(self, other):
        return self.position >= other.position

    def is_default(self):
        return self.default


class LevelSystemTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name) / "game.json"
        self.store = GameStore(self.path)
        self.system = LevelSystem(self.store, rng=FixedRng())

    def test_message_awards_and_cooldown_survives_restart(self):
        self.assertEqual(self.system.award_message(1, 2, now=100), (False, 0, 15))
        self.assertEqual(self.system.award_message(1, 2, now=120), (False, 0, 0))
        restarted = LevelSystem(GameStore(self.path), rng=FixedRng())
        self.assertEqual(restarted.award_message(1, 2, now=159), (False, 0, 0))
        self.assertEqual(restarted.award_message(1, 2, now=160), (False, 0, 15))

    def test_guild_isolation_and_economy_is_untouched(self):
        self.system.award_message(10, 7, now=1)
        self.system.award_message(11, 7, now=1)
        self.assertEqual(self.system.profile(10, 7)["xp"], 15)
        self.assertEqual(self.system.profile(11, 7)["xp"], 15)
        self.assertEqual(self.store.snapshot()["users"], {})

    def test_threshold_and_voice_counting(self):
        self.assertEqual(xp_for_level(1), 155)
        self.assertEqual(title_for_level(4), "عضو جديد")
        self.assertEqual(title_for_level(5), "مبتدئ")
        self.assertEqual(title_for_level(100), "إمبراطور")
        for index in range(10):
            self.system.award_message(1, 1, now=index * 60)
        self.assertEqual(self.system.profile(1, 1)["xp"], 150)
        self.assertEqual(self.system.award_voice_minutes(1, 1, 1), (True, 1, 10))
        self.assertEqual(self.system.profile(1, 1)["voice_minutes"], 1)
        self.assertEqual(self.system.award_voice_minutes(1, 1, 2), (False, 1, 20))
        self.assertEqual(self.system.profile(1, 1)["voice_minutes"], 3)

    def test_role_reward_configuration_is_guild_scoped_and_persistent(self):
        self.system.set_role_reward(10, 5, 1001)
        self.system.set_role_reward(10, 10, 1002)
        self.system.set_role_reward(11, 5, 2001)

        self.assertEqual(self.system.role_rewards(10), {5: 1001, 10: 1002})
        self.assertEqual(self.system.role_rewards(11), {5: 2001})
        self.assertEqual(
            LevelSystem(GameStore(self.path)).role_rewards(10),
            {5: 1001, 10: 1002},
        )
        self.assertTrue(self.system.remove_role_reward(10, 5))
        self.assertFalse(self.system.remove_role_reward(10, 5))
        self.assertEqual(self.system.role_rewards(11), {5: 2001})

    def test_announcement_settings_are_guild_scoped_persistent_and_resettable(self):
        self.assertEqual(
            self.system.announcement_settings(10),
            {
                "mode": "same",
                "channel_id": None,
                "mention_user": True,
                "custom_message": None,
            },
        )
        self.system.set_announcement_settings(
            10,
            {
                "mode": "channel",
                "channel_id": 1234,
                "custom_message": "مبروك {user} وصلت {level}",
            },
        )
        self.system.set_announcement_settings(11, {"mode": "off"})

        restored = LevelSystem(GameStore(self.path))
        self.assertEqual(
            restored.announcement_settings(10),
            {
                "mode": "channel",
                "channel_id": 1234,
                "mention_user": True,
                "custom_message": "مبروك {user} وصلت {level}",
            },
        )
        self.assertEqual(restored.announcement_settings(11)["mode"], "off")
        self.assertTrue(restored.reset_announcement_settings(10))
        self.assertFalse(restored.reset_announcement_settings(10))
        self.assertEqual(restored.announcement_settings(10)["mode"], "same")
        self.assertEqual(restored.announcement_settings(11)["mode"], "off")

    def test_announcement_settings_clear_channel_when_mode_changes(self):
        self.system.set_announcement_settings(
            10,
            {"mode": "channel", "channel_id": 1234},
        )
        settings = self.system.set_announcement_settings(
            10,
            {"mode": "dm", "channel_id": None},
        )
        self.assertEqual(settings["mode"], "dm")
        self.assertIsNone(settings["channel_id"])

    def test_invalid_announcement_settings_roll_back(self):
        self.system.set_announcement_settings(10, {"mode": "off"})
        for updates in (
            {"mode": "channel", "channel_id": None},
            {"mode": "invalid"},
            {"mode": []},
            {"custom_message": " "},
            {"custom_message": "x" * 501},
        ):
            with self.subTest(updates=updates), self.assertRaises(ValueError):
                self.system.set_announcement_settings(10, updates)
        self.assertEqual(self.system.announcement_settings(10)["mode"], "off")

    def test_guild_stats_aggregate_only_current_guild_profiles(self):
        self.system.award_voice_minutes(10, 1, 2)
        self.system.award_message_transition(10, 1, now=10)
        self.system.award_voice_minutes(10, 2, 1)
        self.system.award_voice_minutes(11, 3, 20)
        self.assertEqual(
            self.system.guild_stats(10),
            {
                "members": 2,
                "total_xp": 45,
                "total_messages": 1,
                "voice_minutes": 3,
                "highest_level": 0,
            },
        )

    def test_level_setup_slash_command_and_developer_stats_register(self):
        bot = commands.Bot(command_prefix="!", intents=discord.Intents.none())
        setup_commands(bot, self.system, developer_id=42)
        self.assertIsNotNone(bot.tree.get_command("levelsetup"))
        self.assertIsNotNone(bot.get_command("level_stats"))

    def test_level_notice_uses_configured_channel_custom_text_and_mention_policy(self):
        self.system.set_announcement_settings(
            10,
            {
                "mode": "channel",
                "channel_id": 1234,
                "mention_user": False,
                "custom_message": "{user} وصلت المستوى {level} في {guild}",
            },
        )
        destination = SimpleNamespace(send=AsyncMock())
        source = SimpleNamespace(send=AsyncMock())
        guild = SimpleNamespace(
            id=10,
            name="Test Guild",
            get_channel=Mock(return_value=destination),
        )
        member = SimpleNamespace(
            id=7,
            display_name="Test Member",
            mention="<@7>",
            avatar=None,
            display_avatar=None,
            send=AsyncMock(),
        )

        asyncio.run(send_level_up_notice(self.system, guild, member, source, 5))

        destination.send.assert_awaited_once()
        source.send.assert_not_awaited()
        kwargs = destination.send.await_args.kwargs
        self.assertIsNone(kwargs["content"])
        self.assertEqual(
            kwargs["embed"].description,
            "Test Member وصلت المستوى 5 في Test Guild",
        )
        self.assertFalse(kwargs["allowed_mentions"].users)
        member.send.assert_not_awaited()

    def test_level_notice_can_send_dm_and_off_mode_suppresses_notice(self):
        dm_member = SimpleNamespace(
            id=7,
            display_name="Test Member",
            mention="<@7>",
            avatar=None,
            display_avatar=None,
            send=AsyncMock(),
        )
        source = SimpleNamespace(send=AsyncMock())
        guild = SimpleNamespace(id=10, name="Test Guild", get_channel=Mock())

        self.system.set_announcement_settings(10, {"mode": "dm"})
        asyncio.run(send_level_up_notice(self.system, guild, dm_member, source, 1))
        dm_member.send.assert_awaited_once()
        source.send.assert_not_awaited()

        self.system.set_announcement_settings(10, {"mode": "off"})
        asyncio.run(send_level_up_notice(self.system, guild, dm_member, source, 2))
        self.assertEqual(dm_member.send.await_count, 1)
        source.send.assert_not_awaited()

    def test_crossed_rewards_cover_message_voice_and_multi_level_gains(self):
        self.system.set_role_reward(1, 1, 101)
        self.system.set_role_reward(1, 2, 102)
        self.system.set_role_reward(1, 4, 104)

        self.system.award_voice_minutes(1, 7, 15)
        self.assertEqual(
            self.system.award_message_transition(1, 7, now=100),
            (0, 1, 15),
        )
        self.assertEqual(
            self.system.role_rewards_crossed(1, 0, 1),
            [(1, 101)],
        )

        self.assertEqual(
            self.system.award_voice_minutes_transition(1, 8, 16),
            (0, 1, 160),
        )
        self.assertEqual(
            self.system.role_rewards_crossed(1, 0, 1),
            [(1, 101)],
        )
        self.assertEqual(
            self.system.role_rewards_crossed(1, 1, 4),
            [(2, 102), (4, 104)],
        )
        self.assertEqual(self.system.role_rewards_crossed(1, 4, 4), [])

    def test_role_reward_checks_missing_role_permission_and_hierarchy(self):
        bot_member = SimpleNamespace(
            guild_permissions=SimpleNamespace(manage_roles=True),
            top_role=FakeRole(900, 10),
        )
        self.assertIn("no longer exists", role_reward_block_reason(None, bot_member))
        self.assertIn(
            "Manage Roles",
            role_reward_block_reason(
                FakeRole(1, 2),
                SimpleNamespace(
                    guild_permissions=SimpleNamespace(manage_roles=False),
                    top_role=FakeRole(900, 10),
                ),
            ),
        )
        self.assertIn(
            "highest role",
            role_reward_block_reason(FakeRole(2, 10), bot_member),
        )
        self.assertIn(
            "integration",
            role_reward_block_reason(
                FakeRole(3, 2, managed=True), bot_member
            ),
        )
        self.assertIsNone(role_reward_block_reason(FakeRole(4, 2), bot_member))

    def test_rank_and_leaderboard(self):
        self.system.award_voice_minutes(1, 1, 3)
        self.system.award_voice_minutes(1, 2, 1)
        self.system.award_voice_minutes(1, 3, 2)
        self.assertEqual([p["user_id"] for p in self.system.leaderboard(1)], [1, 3, 2])
        self.assertEqual(self.system.rank(1, 3), (2, 3))
        self.assertEqual(self.system.rank(2, 3), (None, 0))

    def test_leaderboard_fetches_uncached_members_and_uses_non_ping_mentions(self):
        self.system.award_voice_minutes(1, 7, 1)
        member = SimpleNamespace(mention="<@7>")
        guild = SimpleNamespace(
            id=1,
            name="Test Guild",
            get_member=Mock(return_value=None),
            fetch_member=AsyncMock(return_value=member),
        )
        context = SimpleNamespace(guild=guild, send=AsyncMock())
        bot = commands.Bot(command_prefix="!", intents=discord.Intents.none())
        setup_commands(bot, self.system, developer_id=42)

        asyncio.run(bot.get_command("توب").callback(context))

        guild.fetch_member.assert_awaited_once_with(7)
        send_kwargs = context.send.await_args.kwargs
        self.assertIn("<@7>", send_kwargs["embed"].description)
        self.assertEqual(send_kwargs["allowed_mentions"].to_dict()["parse"], [])


if __name__ == "__main__":
    unittest.main()