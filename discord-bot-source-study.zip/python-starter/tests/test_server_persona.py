"""Tests for per-server webhook names and avatars."""

import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import discord
from discord.ext import commands

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from server_persona import (
    PersonaSettingsError,
    ServerPersonaManager,
    ServerPersonaStore,
)


PNG_BYTES = b"\x89PNG\r\n\x1a\nsmall test image"


class ServerPersonaStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_dir.cleanup)
        self.path = Path(self.temp_dir.name) / "server_personas.json"
        self.store = ServerPersonaStore(self.path)

    def test_settings_are_isolated_and_persisted_per_guild(self):
        self.store.set_display_name(101, "Guild One Assistant")
        self.store.set_avatar_url(101, "https://cdn.example.test/one.png")
        self.store.set_display_name(202, "Guild Two Assistant")

        reopened = ServerPersonaStore(self.path)

        self.assertEqual(
            reopened.get(101),
            {
                "display_name": "Guild One Assistant",
                "avatar_url": "https://cdn.example.test/one.png",
            },
        )
        self.assertEqual(
            reopened.get(202),
            {"display_name": "Guild Two Assistant"},
        )

    def test_webhook_mode_persists_without_clearing_custom_identity(self):
        self.store.set_display_name(101, "Custom server identity")
        self.store.set_webhook_enabled(101, False)

        reopened = ServerPersonaStore(self.path)
        self.assertEqual(
            reopened.get(101),
            {"display_name": "Custom server identity", "use_webhook": False},
        )

        reopened.set_webhook_enabled(101, True)
        self.assertEqual(
            ServerPersonaStore(self.path).get(101),
            {"display_name": "Custom server identity"},
        )

    def test_images_only_mode_persists_without_clearing_custom_identity(self):
        self.store.set_display_name(101, "Custom server identity")
        self.store.set_webhook_mode(101, "images")

        reopened = ServerPersonaStore(self.path)
        self.assertEqual(
            reopened.get(101),
            {
                "display_name": "Custom server identity",
                "webhook_only_images": True,
            },
        )

    def test_uploaded_avatar_bytes_are_stored_and_reopened(self):
        stored_path = self.store.set_avatar_bytes(101, PNG_BYTES)
        reopened = ServerPersonaStore(self.path)

        self.assertEqual(reopened.get(101)["avatar_file"], stored_path)
        self.assertEqual(reopened.read_avatar(101), PNG_BYTES)
        self.assertTrue((reopened.avatar_dir / stored_path).is_file())

    def test_invalid_names_urls_and_image_bytes_are_rejected(self):
        with self.assertRaises(PersonaSettingsError):
            self.store.set_display_name(101, "bad\nname")
        with self.assertRaises(PersonaSettingsError):
            self.store.set_display_name(101, "x" * 81)
        with self.assertRaises(PersonaSettingsError):
            self.store.set_avatar_url(101, "http://cdn.example.test/avatar.png")
        with self.assertRaises(PersonaSettingsError):
            self.store.set_avatar_bytes(101, b"not an image")

    def test_reset_writes_backup_before_clearing_overrides(self):
        stored_path = self.store.set_avatar_bytes(101, PNG_BYTES)
        self.store.set_display_name(101, "Custom name")

        self.assertTrue(self.store.reset_guild(101))
        self.assertEqual(self.store.get(101), {})

        backups = list(self.store.backup_dir.glob("101_*.json"))
        self.assertEqual(len(backups), 1)
        backup = json.loads(backups[0].read_text(encoding="utf-8"))
        self.assertEqual(
            backup["settings"]["display_name"],
            "Custom name",
        )
        self.assertEqual(backup["settings"]["avatar_file"], stored_path)
        self.assertEqual(self.store.read_avatar(101), None)
        self.assertTrue((self.store.avatar_dir / stored_path).is_file())

    def test_corrupt_or_unsafe_settings_fail_closed(self):
        self.path.write_text(
            json.dumps({"101": {"avatar_file": "../outside.png"}}),
            encoding="utf-8",
        )
        with self.assertRaises(ValueError):
            ServerPersonaStore(self.path)


class FakeWebhook:
    def __init__(self, webhook_id, name):
        self.id = webhook_id
        self.name = name
        self.sent = []
        self.avatar = None

    async def edit(self, *, avatar, reason):
        self.avatar = avatar
        return self

    async def send(self, *, content, **kwargs):
        self.sent.append({"content": content, **kwargs})


class FakeChannel:
    def __init__(self, guild, can_manage_webhooks=True):
        self.id = 303
        self.guild = guild
        self.can_manage_webhooks = can_manage_webhooks
        self.existing_webhooks = []
        self.created_webhooks = 0

    def permissions_for(self, member):
        return SimpleNamespace(manage_webhooks=self.can_manage_webhooks)

    async def webhooks(self):
        return list(self.existing_webhooks)

    async def create_webhook(self, *, name, reason):
        self.created_webhooks += 1
        webhook = FakeWebhook(404, name)
        self.existing_webhooks.append(webhook)
        return webhook


class FakeMessage:
    def __init__(self, guild, channel):
        self.guild = guild
        self.channel = channel
        self.author = SimpleNamespace(id=707, mention="<@707>")
        self.replies = []

    async def reply(self, content, **kwargs):
        self.replies.append({"content": content, **kwargs})


class FakeInteractionResponse:
    def __init__(self):
        self.sent = []

    async def send_message(self, *args, **kwargs):
        self.sent.append({"args": args, **kwargs})


class ServerPersonaManagerTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_dir.cleanup)
        self.store = ServerPersonaStore(
            Path(self.temp_dir.name) / "server_personas.json"
        )
        self.bot_user = SimpleNamespace(
            id=909,
            name="HelperBot",
            display_avatar=SimpleNamespace(
                url="https://cdn.example.test/bot.png"
            ),
        )
        self.bot = SimpleNamespace(user=self.bot_user)
        self.guild = SimpleNamespace(
            id=101,
            name="Guild One",
            icon=SimpleNamespace(url="https://cdn.example.test/guild.png"),
            me=object(),
        )
        self.channel = FakeChannel(self.guild)
        self.message = FakeMessage(self.guild, self.channel)
        self.manager = ServerPersonaManager(self.bot, self.store)

    async def test_default_reply_uses_server_name_and_icon_and_reuses_webhook(self):
        await self.manager.reply(self.message, "first reply")
        await self.manager.reply(self.message, "second reply")

        self.assertEqual(self.channel.created_webhooks, 1)
        webhook = self.channel.existing_webhooks[0]
        self.assertEqual(len(webhook.sent), 2)
        self.assertEqual(webhook.sent[0]["content"], "<@707> first reply")
        self.assertEqual(webhook.sent[0]["username"], "Guild One")
        self.assertEqual(
            webhook.sent[0]["avatar_url"],
            "https://cdn.example.test/guild.png",
        )
        allowed_mentions = webhook.sent[0]["allowed_mentions"].to_dict()
        self.assertEqual(allowed_mentions["users"], [707])
        self.assertEqual(allowed_mentions["parse"], [])
        self.assertEqual(self.message.replies, [])

    async def test_uploaded_avatar_and_custom_name_are_applied(self):
        self.store.set_avatar_bytes(101, PNG_BYTES)
        self.store.set_display_name(101, "Guild One AI")

        await self.manager.reply(self.message, "custom reply")

        webhook = self.channel.existing_webhooks[0]
        self.assertEqual(webhook.avatar, PNG_BYTES)
        self.assertEqual(webhook.sent[0]["username"], "Guild One AI")
        self.assertTrue(webhook.sent[0]["content"].startswith("<@707> "))
        self.assertNotIn("avatar_url", webhook.sent[0])

    async def test_missing_manage_webhooks_permission_uses_regular_reply(self):
        self.channel.can_manage_webhooks = False

        await self.manager.reply(self.message, "fallback reply")

        self.assertEqual(self.channel.created_webhooks, 0)
        self.assertEqual(self.message.replies[0]["content"], "fallback reply")
        self.assertTrue(self.message.replies[0]["mention_author"])
        allowed_mentions = self.message.replies[0]["allowed_mentions"].to_dict()
        self.assertEqual(allowed_mentions["users"], [707])
        self.assertEqual(allowed_mentions["parse"], [])

    async def test_disabled_server_identity_uses_regular_reply_and_mentions_asker(self):
        self.store.set_webhook_enabled(self.guild.id, False)

        await self.manager.reply(self.message, "normal identity reply")

        self.assertEqual(self.channel.created_webhooks, 0)
        self.assertEqual(self.message.replies[0]["content"], "normal identity reply")
        self.assertTrue(self.message.replies[0]["mention_author"])
        allowed_mentions = self.message.replies[0]["allowed_mentions"].to_dict()
        self.assertEqual(allowed_mentions["users"], [707])
        self.assertEqual(allowed_mentions["parse"], [])

    async def test_images_only_mode_uses_webhook_only_for_image_replies(self):
        self.store.set_webhook_mode(self.guild.id, "images")

        await self.manager.reply(self.message, "ordinary text response")
        self.assertEqual(self.channel.created_webhooks, 0)
        self.assertEqual(
            self.message.replies[0]["content"],
            "ordinary text response",
        )
        self.assertTrue(self.message.replies[0]["mention_author"])

        await self.manager.reply(
            self.message,
            "image analysis response",
            force_webhook=True,
        )

        self.assertEqual(self.channel.created_webhooks, 1)
        webhook_message = self.channel.existing_webhooks[0].sent[0]
        self.assertEqual(
            webhook_message["content"],
            "<@707> image analysis response",
        )
        allowed_mentions = webhook_message["allowed_mentions"].to_dict()
        self.assertEqual(allowed_mentions["users"], [707])
        self.assertEqual(allowed_mentions["parse"], [])

    async def test_webhook_reply_keeps_the_mention_within_discord_length_limit(self):
        await self.manager.reply(self.message, "x" * 2000)

        sent_content = self.channel.existing_webhooks[0].sent[0]["content"]
        self.assertLessEqual(len(sent_content), 2000)
        self.assertTrue(sent_content.startswith("<@707> "))

    async def test_set_command_registers_and_saves_name_without_channel_webhook_permission(self):
        client = commands.Bot(
            command_prefix="!",
            intents=discord.Intents.default(),
        )
        try:
            manager = ServerPersonaManager(client, self.store)
            manager.setup_commands()

            command = client.tree.get_command("set")
            self.assertIsNotNone(command)
            self.assertEqual(command.name, "set")
            setting_alias = client.tree.get_command("setting")
            self.assertIsNotNone(setting_alias)

            interaction = SimpleNamespace(
                guild=self.guild,
                user=SimpleNamespace(
                    id=707,
                    guild_permissions=SimpleNamespace(administrator=True),
                ),
                channel=FakeChannel(self.guild, can_manage_webhooks=False),
                response=FakeInteractionResponse(),
            )
            await command.callback(
                interaction,
                discord.app_commands.Choice(name="تغيير الاسم", value="name"),
                value="New server persona",
                image=None,
            )

            self.assertEqual(
                self.store.get(self.guild.id)["display_name"],
                "New server persona",
            )
            self.assertTrue(interaction.response.sent[0]["ephemeral"])
        finally:
            await client.close()

    async def test_setting_alias_can_switch_to_bot_identity(self):
        client = commands.Bot(
            command_prefix="!",
            intents=discord.Intents.default(),
        )
        try:
            manager = ServerPersonaManager(client, self.store)
            manager.setup_commands()
            command = client.tree.get_command("setting")
            self.assertIsNotNone(command)

            interaction = SimpleNamespace(
                guild=self.guild,
                user=SimpleNamespace(
                    id=707,
                    guild_permissions=SimpleNamespace(administrator=True),
                ),
                response=FakeInteractionResponse(),
            )
            await command.callback(
                interaction,
                discord.app_commands.Choice(
                    name="استخدام هوية حساب البوت",
                    value="auto_off",
                ),
                value=None,
                image=None,
            )

            self.assertFalse(self.store.get(self.guild.id)["use_webhook"])
            self.assertTrue(interaction.response.sent[0]["ephemeral"])
        finally:
            await client.close()

    async def test_setting_alias_can_select_images_only_mode(self):
        client = commands.Bot(
            command_prefix="!",
            intents=discord.Intents.default(),
        )
        try:
            manager = ServerPersonaManager(client, self.store)
            manager.setup_commands()
            command = client.tree.get_command("setting")
            interaction = SimpleNamespace(
                guild=self.guild,
                user=SimpleNamespace(
                    id=707,
                    guild_permissions=SimpleNamespace(administrator=True),
                ),
                response=FakeInteractionResponse(),
            )

            await command.callback(
                interaction,
                discord.app_commands.Choice(
                    name="Webhook للصور فقط",
                    value="image_only",
                ),
                value=None,
                image=None,
            )

            settings = self.store.get(self.guild.id)
            self.assertTrue(settings["webhook_only_images"])
            self.assertTrue(settings.get("use_webhook", True))
            self.assertTrue(interaction.response.sent[0]["ephemeral"])
        finally:
            await client.close()


if __name__ == "__main__":
    unittest.main()