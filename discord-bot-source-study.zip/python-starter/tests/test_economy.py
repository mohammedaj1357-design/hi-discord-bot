"""Run with: python3 -m unittest discover -s python-starter/tests"""

import json
import sys
import tempfile
import unittest
from pathlib import Path

import discord
from discord.ext import commands

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from economy_commands import BUILDINGS, GameManager, setup_economy_commands
from game_store import GameStore, STARTING_MONEY


class GameStoreTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name) / "nested" / "game.json"
        self.store = GameStore(self.path)

    def test_initial_state_and_persistence(self):
        with self.store.transaction() as data:
            user = self.store.user(data, 123)
            self.assertEqual(user["money"], STARTING_MONEY)
            self.assertEqual(user["lands"], [])
            data["cooldowns"]["daily:123"] = 1234.5
            data["lottery"]["pot"] = 200
            data["lottery"]["tickets"]["123"] = 2
        reopened = GameStore(self.path).snapshot()
        self.assertEqual(reopened["users"]["123"]["money"], 5000)
        self.assertEqual(reopened["lottery"], {"tickets": {"123": 2}, "pot": 200})
        self.assertEqual(reopened["cooldowns"]["daily:123"], 1234.5)
        self.assertEqual(list(self.path.parent.glob("*.tmp")), [])

    def test_rollback_does_not_persist_partial_changes(self):
        with self.store.transaction() as data:
            self.store.user(data, 1)
        before = self.path.read_bytes()
        with self.assertRaisesRegex(RuntimeError, "abort"):
            with self.store.transaction() as data:
                self.store.user(data, 1)["money"] = 999
                data["lottery"]["pot"] = 10
                raise RuntimeError("abort")
        self.assertEqual(self.path.read_bytes(), before)
        self.assertEqual(self.store.snapshot(), GameStore(self.path).snapshot())

    def test_corruption_is_explicit_and_never_overwritten(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text("{broken", encoding="utf-8")
        with self.assertRaises(json.JSONDecodeError):
            GameStore(self.path)
        self.assertEqual(self.path.read_text(encoding="utf-8"), "{broken")


class EconomyTests(GameStoreTests):
    def setUp(self):
        super().setUp()
        self.game = GameManager(self.store)

    def test_buy_build_offline_accrual_and_collection(self):
        self.assertEqual(self.game.buy_land(1, now=1000)[0], True)
        self.assertEqual(self.game.build(1, 1, "kosh", now=1000)[0], True)
        land = self.game.get_user(1)["lands"][0]
        self.assertEqual(self.game.get_land_income(land), 50)
        self.assertEqual(self.game.get_pending_income(land, now=8200), (100, 7200))
        # Reopening simulates a restart; no timer is required for accrual.
        restarted = GameManager(GameStore(self.path))
        total, details = restarted.collect_all(1, now=8200)
        self.assertEqual(total, 100)
        self.assertIn("100", details[0])
        self.assertEqual(restarted.get_user(1)["money"], 3600)
        self.assertEqual(restarted.get_user(1)["total_earned"], 100)
        self.assertEqual(restarted.collect_all(1, now=8200)[0], 0)
        self.assertEqual(restarted.get_pending_income(restarted.get_user(1)["lands"][0], now=11800)[0], 50)

    def test_developer_granted_bonus_income_accrues_offline_without_double_payment(self):
        with self.store.transaction() as data:
            user = self.store.user(data, 1)
            user["bonus_income"] = 25
            user["bonus_last_collect"] = 1000
        restarted = GameManager(GameStore(self.path))
        self.assertEqual(restarted.get_total_income_per_hour(1), 25)
        self.assertEqual(restarted.collect_all(1, now=2800)[0], 12)
        self.assertEqual(restarted.collect_all(1, now=4600)[0], 13)
        self.assertEqual(restarted.collect_all(1, now=4600)[0], 0)
        self.assertEqual(restarted.get_user(1)["money"], STARTING_MONEY + 25)

    def test_validation_prices_upgrade_and_max_level(self):
        self.assertEqual(set(BUILDINGS), {"kosh", "shop", "restaurant", "building", "tower", "skyscraper"})
        self.assertEqual([b["price"] for b in BUILDINGS.values()], [500, 2000, 5000, 15000, 50000, 200000])
        self.assertEqual([b["income_per_hour"] for b in BUILDINGS.values()], [50, 200, 600, 2000, 8000, 40000])
        self.assertFalse(self.game.build(1, 1, "kosh")[0])
        self.assertTrue(self.game.buy_land(1, now=0)[0])
        self.assertFalse(self.game.build(1, 1, "invalid")[0])
        self.assertFalse(self.game.build(1, 0, "kosh")[0])
        self.assertFalse(self.game.upgrade(1, 1)[0])
        self.assertTrue(self.game.build(1, 1, "kosh", now=0)[0])
        self.assertFalse(self.game.build(1, 1, "kosh")[0])
        self.assertFalse(self.game.build(1, 99, "kosh")[0])
        # Upgrades cost 500 * (level * 0.8): 400, 800, 1200, 1600.
        with self.store.transaction() as data:
            self.store.user(data, 1)["money"] += 3000
        for level, cost in enumerate((400, 800, 1200, 1600), start=2):
            before = self.game.get_user(1)["money"]
            self.assertTrue(self.game.upgrade(1, 1, now=0)[0])
            self.assertEqual(self.game.get_user(1)["money"], before - cost)
            self.assertEqual(self.game.get_user(1)["lands"][0]["level"], level)
            self.assertEqual(self.game.get_total_income_per_hour(1), 50 * (level + 1) // 2)
        self.assertFalse(self.game.upgrade(1, 1, now=0)[0])
        with self.store.transaction() as data:
            self.store.user(data, 1)["money"] = 500
        self.assertFalse(self.game.buy_land(1, now=0)[0])
        self.assertEqual(self.game.get_user(1)["money"], 500)

    def test_upgrade_collects_at_old_rate_before_charging(self):
        self.game.buy_land(1, now=100)
        self.game.build(1, 1, "kosh", now=100)
        self.assertTrue(self.game.upgrade(1, 1, now=3700)[0])
        self.assertEqual(self.game.get_user(1)["money"], 3150)
        self.assertEqual(self.game.get_user(1)["total_earned"], 50)
        self.assertEqual(self.game.get_pending_income(self.game.get_user(1)["lands"][0], now=7300)[0], 75)

    def test_leaderboard_ranks_money_and_only_existing_users(self):
        self.game.get_user(1)
        self.game.buy_land(2, now=0)
        self.assertEqual([entry["user_id"] for entry in self.game.get_leaderboard()], ["1", "2"])
        self.assertEqual(self.game.get_leaderboard(1)[0]["money"], 5000)

    def test_commands_register_synchronously_once(self):
        bot = commands.Bot(command_prefix="!", intents=discord.Intents.default())
        first = setup_economy_commands(bot, self.store)
        self.assertIs(first, setup_economy_commands(bot, self.store))
        self.assertEqual(
            {"بنك", "شراء", "بناء", "جمع", "تطوير", "اغنى", "الالعاب"},
            {name for name in ("بنك", "شراء", "بناء", "جمع", "تطوير", "اغنى", "الالعاب")
             if bot.get_command(name)},
        )
        self.assertIs(bot.get_command("bank"), bot.get_command("بنك"))
        self.assertIs(bot.get_command("help_game"), bot.get_command("الالعاب"))


if __name__ == "__main__":
    unittest.main()