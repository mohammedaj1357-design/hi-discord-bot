"""Tests for developer-only game administration."""

import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import discord
from discord.ext import commands

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from admin_commands import AdminConfirmationView, setup_admin_commands
from admin_engine import AdminEngine, AdminError
from game_store import GameStore


class AdminTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name) / "data" / "game.json"
        self.store = GameStore(self.path)
        self.engine = AdminEngine(self.store)
        self.bot = commands.Bot(command_prefix="!", intents=discord.Intents.default())
        self.developer_id = 42
        self.admin = setup_admin_commands(self.bot, self.store, self.developer_id)

    async def test_every_registered_admin_command_has_developer_check(self):
        names = (
            "resetall", "resetuser", "addmoney", "removemoney", "setmoney", "givemoney",
            "addlands", "addincome", "block", "unblock", "blocked", "logs", "clearlogs",
            "stats", "moneyboard", "backup", "backups", "allplayers", "broadcast", "adminmenu",
        )
        self.assertEqual(set(names), {name for name in names if self.bot.get_command(name)})
        for name in names:
            command = self.bot.get_command(name)
            self.assertTrue(command.extras.get("admin_game"), name)
            self.assertTrue(command.checks, name)
            ctx = SimpleNamespace(author=SimpleNamespace(id=self.developer_id + 1))
            self.assertFalse(await command.checks[0](ctx), name)
            ctx.author.id = self.developer_id
            self.assertTrue(await command.checks[0](ctx), name)
        self.assertIs(self.admin, setup_admin_commands(self.bot, self.store, self.developer_id))

    async def test_confirmation_is_developer_only_and_timeout_cancels(self):
        invoked = []
        view = AdminConfirmationView(self.developer_id, lambda: invoked.append(True))

        class Response:
            async def send_message(self, *args, **kwargs):
                self.ephemeral = kwargs.get("ephemeral")

        outsider = SimpleNamespace(user=SimpleNamespace(id=99), response=Response())
        self.assertFalse(await view.interaction_check(outsider))
        self.assertTrue(outsider.response.ephemeral)
        self.assertEqual(invoked, [])
        await view.on_timeout()
        self.assertEqual(invoked, [])
        self.assertTrue(view.finished)

    async def test_invalid_mutations_do_not_change_game_state(self):
        with self.store.transaction() as data:
            self.store.user(data, 10)
        before = self.store.snapshot()
        with self.assertRaises(AdminError):
            self.engine.add_lands(10, 101)
        with self.assertRaises(AdminError):
            self.engine.adjust_money(10, "-1", "add")
        with self.assertRaises(AdminError):
            self.engine.adjust_money(10, 1_000_000_000_001, "set")
        self.assertEqual(self.store.snapshot(), before)

    async def test_existing_over_cap_balance_can_be_reduced_or_reset(self):
        with self.store.transaction() as data:
            self.store.user(data, 10)["money"] = 1_000_000_000_050
        self.assertEqual(self.engine.adjust_money(10, "1", "remove"), 1_000_000_000_049)
        with self.assertRaises(AdminError):
            self.engine.adjust_money(10, "1", "add")
        self.assertEqual(self.engine.adjust_money(10, "0", "set"), 0)
        self.assertEqual(self.store.snapshot()["users"]["10"]["money"], 0)

    async def test_balance_land_commands_reply_with_numeric_results(self):
        author = SimpleNamespace(id=self.developer_id, mention="<@42>", name="dev")
        ctx = SimpleNamespace(
            author=author, message=SimpleNamespace(mentions=[]), reply=AsyncMock()
        )
        await self.bot.get_command("addmoney").callback(ctx, "me", "250")
        self.assertEqual(self.store.snapshot()["users"]["42"]["money"], 5250)
        self.assertIn("5,250", ctx.reply.call_args.args[0])
        await self.bot.get_command("addlands").callback(ctx, "me", "2")
        self.assertEqual(len(self.store.snapshot()["users"]["42"]["lands"]), 2)
        self.assertIn("2", ctx.reply.call_args.args[0])

    async def test_bonus_income_change_settles_old_rate_and_reports_failure(self):
        author = SimpleNamespace(id=self.developer_id, mention="<@42>", name="dev")
        ctx = SimpleNamespace(
            author=author, message=SimpleNamespace(mentions=[]), reply=AsyncMock()
        )
        with self.store.transaction() as data:
            user = self.store.user(data, 42)
            user["bonus_income"] = 60
            user["bonus_last_collect"] = 1000
        with patch("admin_engine.time.time", return_value=4600):
            await self.bot.get_command("addincome").callback(ctx, "me", "90")
        self.assertEqual(self.store.snapshot()["users"]["42"]["money"], 5060)
        self.assertEqual(self.store.snapshot()["users"]["42"]["bonus_income"], 90)
        with patch.object(self.admin, "set_bonus_income", side_effect=AdminError("backup failed")):
            ctx.reply.reset_mock()
            await self.bot.get_command("addincome").callback(ctx, "me", "100")
        self.assertEqual(ctx.reply.await_count, 1)
        self.assertIn("backup failed", ctx.reply.call_args.args[0])

    async def test_destructive_change_aborts_if_backup_fails(self):
        with self.store.transaction() as data:
            self.store.user(data, 10)
            data["lottery"] = {"tickets": {"10": 25}, "pot": 25}
            data["cooldowns"]["10_salary"] = 123
        before = self.store.snapshot()
        with patch.object(self.engine, "create_backup", side_effect=AdminError("backup failed")):
            with self.assertRaises(AdminError):
                self.engine.reset_all()
        self.assertEqual(self.store.snapshot(), before)

    async def test_blocking_is_persisted_and_audited(self):
        self.engine.block_user(10)
        reopened = GameStore(self.path).snapshot()
        self.assertEqual(reopened["blocked_users"], ["10"])
        self.assertEqual(reopened["admin_logs"][-1]["action"], "block_user")
        self.engine.unblock_user(10)
        self.assertEqual(GameStore(self.path).snapshot()["blocked_users"], [])

    async def test_resetuser_recomputes_lottery_and_clears_related_state(self):
        with self.store.transaction() as data:
            self.store.user(data, 10)
            self.store.user(data, 20)
            data["lottery"] = {"tickets": {"10": 30, "20": 40}, "pot": 70}
            data["cooldowns"] = {"10_salary": 1, "20_salary": 2, "daily:10": 3}
            data["blocked_users"] = ["10", "20"]
        self.engine.reset_user(10)
        state = self.store.snapshot()
        self.assertNotIn("10", state["users"])
        self.assertEqual(state["lottery"], {"tickets": {"20": 40}, "pot": 40})
        self.assertEqual(state["cooldowns"], {"20_salary": 2})
        self.assertEqual(state["blocked_users"], ["20"])

    async def test_backup_contains_full_snapshot_but_is_private_and_local(self):
        with self.store.transaction() as data:
            self.store.user(data, 10)["money"] = 1234
            data["root_setting"] = {"preserved": True}
        path = self.engine.create_backup()
        self.assertEqual(json.loads(path.read_text(encoding="utf-8")), self.store.snapshot())
        self.assertEqual(path.parent, self.path.parent / "backup")
        self.assertEqual(path.stat().st_mode & 0o777, 0o600)

    async def test_broadcast_uses_one_writable_channel_per_guild_without_mentions(self):
        class Channel:
            def __init__(self, name, writable=True):
                self.name = name
                self.writable = writable
                self.sent = []

            def permissions_for(self, member):
                return SimpleNamespace(send_messages=self.writable, embed_links=self.writable)

            async def send(self, **kwargs):
                self.sent.append(kwargs)

        system = Channel("system")
        fallback = Channel("fallback")
        denied = Channel("denied", writable=False)
        guild_a = SimpleNamespace(me=object(), system_channel=system, text_channels=[system, fallback])
        guild_b = SimpleNamespace(me=object(), system_channel=None, text_channels=[denied, fallback])
        self.bot._connection._guilds = {1: guild_a, 2: guild_b}
        ctx = SimpleNamespace(send=self._capture_send)
        command = self.bot.get_command("broadcast")
        await command.callback(ctx, message="@everyone hello")
        view = self.sent_view
        result = await view.operation()
        self.assertIn("sent to 2 guilds", result)
        self.assertEqual(len(system.sent), 1)
        self.assertEqual(len(fallback.sent), 1)
        for payload in system.sent + fallback.sent:
            self.assertFalse(payload["allowed_mentions"].everyone)
            self.assertFalse(payload["allowed_mentions"].users)
        self.assertEqual(self.store.snapshot()["admin_logs"][-1]["action"], "broadcast")

    async def _capture_send(self, **kwargs):
        self.sent_view = kwargs["view"]
        self.sent_embed = kwargs["embed"]
        return SimpleNamespace()


if __name__ == "__main__":
    unittest.main()