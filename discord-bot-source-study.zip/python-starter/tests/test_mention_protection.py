"""Tests for persistent protection against mentions of configured users."""

import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock

import discord

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mention_protection import MentionProtection, WARNING_SECONDS


DEVELOPER_ID = 42
PROTECTED_ID = 99


class MentionProtectionTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        data_dir = Path(self.temp_dir.name)
        self.protected_path = data_dir / "protected_users.json"
        self.warnings_path = data_dir / "mention_warnings.json"
        self.now = datetime(2026, 9, 24, 12, tzinfo=timezone.utc)
        self.protection = self.make_protection()
        self.protection.add_protected(PROTECTED_ID)
        self.developer = SimpleNamespace(send=AsyncMock())
        self.client = SimpleNamespace(
            get_user=Mock(return_value=self.developer),
            fetch_user=AsyncMock(return_value=self.developer),
        )

    def tearDown(self):
        self.temp_dir.cleanup()

    def make_protection(self):
        return MentionProtection(
            DEVELOPER_ID,
            protected_users_path=self.protected_path,
            warnings_path=self.warnings_path,
            clock=lambda: self.now,
        )

    def make_message(
        self,
        *,
        author_id=7,
        mentioned_ids=(PROTECTED_ID,),
        administrator=False,
        guild=True,
        bot=False,
        content="private original message",
    ):
        channel = SimpleNamespace(
            id=20,
            name="general",
            send=AsyncMock(),
        )
        author = SimpleNamespace(
            id=author_id,
            bot=bot,
            mention=f"<@{author_id}>",
            display_name="Member",
            guild_permissions=SimpleNamespace(administrator=administrator),
            timeout=AsyncMock(),
        )
        return SimpleNamespace(
            id=100,
            content=content,
            guild=SimpleNamespace(id=10, name="Test Guild") if guild else None,
            channel=channel,
            author=author,
            mentions=[SimpleNamespace(id=user_id) for user_id in mentioned_ids],
            delete=AsyncMock(),
        )

    async def test_member_mention_is_deleted_warned_and_developer_notified_privately(self):
        message = self.make_message()
        handled = await self.protection.handle(message, self.client)

        self.assertTrue(handled)
        message.delete.assert_awaited_once()
        message.author.timeout.assert_not_awaited()
        message.channel.send.assert_awaited_once()
        warning, warning_kwargs = message.channel.send.call_args
        self.assertIn(message.author.mention, warning[0])
        self.assertIn("1/3", warning[0])
        self.assertEqual(warning_kwargs["delete_after"], WARNING_SECONDS)
        self.assertFalse(warning_kwargs["allowed_mentions"].users)

        self.developer.send.assert_awaited_once()
        notification = self.developer.send.call_args.args[0]
        self.assertIn("Member", notification)
        self.assertIn("#general", notification)
        self.assertIn(str(PROTECTED_ID), notification)
        self.assertIn("1/3", notification)
        self.assertNotIn(message.content, notification)
        self.client.fetch_user.assert_not_awaited()

    async def test_protected_members_and_server_administrators_are_exempt_as_authors(self):
        cases = (
            self.make_message(author_id=DEVELOPER_ID),
            self.make_message(author_id=PROTECTED_ID),
            self.make_message(administrator=True),
        )
        for message in cases:
            self.assertFalse(await self.protection.handle(message, self.client))
            message.delete.assert_not_awaited()
            message.channel.send.assert_not_awaited()
        self.developer.send.assert_not_awaited()

    async def test_nonprotected_mentions_bots_and_direct_messages_are_exempt(self):
        cases = (
            self.make_message(mentioned_ids=(1234,)),
            self.make_message(bot=True),
            self.make_message(guild=False),
        )
        for message in cases:
            self.assertFalse(await self.protection.handle(message, self.client))
            message.delete.assert_not_awaited()

    async def test_unprotected_message_breaks_only_that_members_consecutive_streak(self):
        await self.protection.handle(self.make_message(), self.client)
        await self.protection.handle(self.make_message(), self.client)
        self.assertEqual(self.protection.get_warnings(7, 10), 2)

        another_member_message = self.make_message(
            author_id=8,
            mentioned_ids=(1234,),
        )
        self.assertFalse(
            await self.protection.handle(another_member_message, self.client)
        )
        self.assertEqual(self.protection.get_warnings(7, 10), 2)

        ordinary_message = self.make_message(
            author_id=7,
            mentioned_ids=(1234,),
        )
        self.assertFalse(await self.protection.handle(ordinary_message, self.client))
        self.assertEqual(self.protection.get_warnings(7, 10), 0)
        self.assertEqual(self.make_protection().get_warnings(7, 10), 0)

        next_mention = self.make_message(author_id=7)
        await self.protection.handle(next_mention, self.client)
        next_mention.author.timeout.assert_not_awaited()
        self.assertIn("1/3", next_mention.channel.send.call_args.args[0])

    async def test_warnings_persist_for_24_hours_timeout_after_three_and_reset(self):
        first = self.make_message()
        second = self.make_message()
        await self.protection.handle(first, self.client)
        await self.protection.handle(second, self.client)

        restored = self.make_protection()
        self.assertEqual(restored.get_warnings(7, 10), 2)
        third = self.make_message()
        with self.assertLogs("mention_protection", level="INFO") as captured:
            await restored.handle(third, self.client)
        third.author.timeout.assert_awaited_once_with(
            timedelta(minutes=10),
            reason="Repeatedly mentioning a protected member",
        )
        self.assertIn(
            "Applied a 10.0-minute timeout",
            "\n".join(captured.output),
        )
        self.assertIn("إسكاتك 10 دقائق", third.channel.send.call_args.args[0])
        self.assertEqual(restored.get_warnings(7, 10), 0)

        fourth = self.make_message()
        await restored.handle(fourth, self.client)
        fourth.author.timeout.assert_not_awaited()
        self.assertIn("1/3", fourth.channel.send.call_args.args[0])

    async def test_warnings_expire_after_24_hours_and_are_scoped_to_each_guild(self):
        self.protection.add_warning(7, 10, "protected mention")
        self.assertEqual(self.protection.get_warnings(7, 10), 1)
        self.assertEqual(self.protection.get_warnings(7, 11), 0)

        self.now += timedelta(hours=24, seconds=1)
        self.assertEqual(self.protection.get_warnings(7, 10), 0)

    async def test_timeout_permission_failure_keeps_warnings_for_retry(self):
        messages = []
        for _ in range(2):
            message = self.make_message()
            messages.append(message)
            await self.protection.handle(message, self.client)

        third = self.make_message()
        third.author.top_role = SimpleNamespace(name="Member", position=8)
        third.guild.get_member = Mock(
            return_value=SimpleNamespace(
                guild_permissions=SimpleNamespace(
                    moderate_members=False,
                    administrator=False,
                ),
                top_role=SimpleNamespace(name="Bot", position=4),
            )
        )
        self.client.user = SimpleNamespace(id=500)
        third.author.timeout.side_effect = discord.Forbidden(
            SimpleNamespace(status=403, reason="Forbidden", headers={}),
            "missing Moderate Members",
        )
        messages.append(third)
        with self.assertLogs("mention_protection", level="WARNING") as captured:
            await self.protection.handle(third, self.client)

        log_output = "\n".join(captured.output)
        self.assertIn("HTTP status=403", log_output)
        self.assertIn("bot Moderate Members=False", log_output)
        self.assertIn("bot top role=Bot (position=4)", log_output)
        self.assertIn("target top role=Member (position=8)", log_output)
        self.assertIn("bot lacks Moderate Members", log_output)
        self.assertIn("Moderate Members", messages[2].channel.send.call_args.args[0])
        notification = self.developer.send.call_args.args[0]
        self.assertIn("تفاصيل الخطأ", notification)
        self.assertIn("position=4", notification)
        self.assertEqual(self.protection.get_warnings(7, 10), 3)
        fourth = self.make_message()
        await self.protection.handle(fourth, self.client)
        fourth.author.timeout.assert_awaited_once()

    async def test_delete_permission_failure_does_not_count_or_notify(self):
        message = self.make_message()
        message.delete.side_effect = discord.Forbidden(
            SimpleNamespace(status=403, reason="Forbidden", headers={}),
            "missing Manage Messages",
        )

        self.assertTrue(await self.protection.handle(message, self.client))
        message.channel.send.assert_not_awaited()
        message.author.timeout.assert_not_awaited()
        self.developer.send.assert_not_awaited()
        self.assertEqual(self.protection.get_warnings(7, 10), 0)

    async def test_protected_user_list_persists_and_developer_cannot_be_removed(self):
        self.assertFalse(self.protection.remove_protected(DEVELOPER_ID))
        restored = self.make_protection()
        self.assertIn(DEVELOPER_ID, restored.protected_users)
        self.assertIn(PROTECTED_ID, restored.protected_users)
        self.assertTrue(restored.remove_protected(PROTECTED_ID))
        self.assertNotIn(PROTECTED_ID, self.make_protection().protected_users)

    async def test_clear_warnings_returns_count_and_persists(self):
        self.protection.add_warning(7, 10, "first")
        self.protection.add_warning(7, 10, "second")

        self.assertEqual(self.protection.clear_warnings(7, 10), 2)
        self.assertEqual(self.make_protection().get_warnings(7, 10), 0)

    async def test_fetches_developer_when_not_cached(self):
        self.client.get_user.return_value = None
        message = self.make_message()
        await self.protection.handle(message, self.client)
        self.client.fetch_user.assert_awaited_once_with(DEVELOPER_ID)
        self.developer.send.assert_awaited_once()


if __name__ == "__main__":
    unittest.main()