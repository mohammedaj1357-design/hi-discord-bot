import asyncio
import io
import socket
import sys
from pathlib import Path
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parents[1]))

from PIL import Image
from web_image_features import (
    extract_html_context, parse_image_operation, transform_image,
    unique_urls, validate_public_url, read_link_context, _PublicResolver,
)


def png_bytes(size=(20, 10)):
    image = Image.new("RGB", size, "red")
    out = io.BytesIO()
    image.save(out, "PNG")
    return out.getvalue()


def test_url_parser_is_unique_and_limited():
    assert unique_urls("x https://example.com/a https://example.com/a http://example.org", 2) == [
        "https://example.com/a", "http://example.org"
    ]


def test_private_and_userinfo_urls_are_rejected():
    assert not validate_public_url("http://127.0.0.1/")[0]
    assert not validate_public_url("http://10.0.0.1/")[0]
    assert not validate_public_url("http://user:pass@example.com/")[0]
    assert validate_public_url("https://example.com/")[0]


def test_html_extraction_omits_scripts_and_marks_untrusted():
    result = extract_html_context("<title>Hello</title><script>bad()</script><p>Readable text</p>")
    assert "Hello" in result and "Readable text" in result and "bad()" not in result
    assert "غير موثوق" in result


def test_image_operations_and_png_output():
    source = png_bytes()
    assert Image.open(io.BytesIO(transform_image(source, "resize", ["8"]))).size == (8, 4)
    assert Image.open(io.BytesIO(transform_image(source, "grayscale"))).mode == "RGBA"
    assert Image.open(io.BytesIO(transform_image(source, "border", ["2"]))).size == (24, 14)


def test_image_limits_and_parser():
    assert parse_image_operation("resize", "20 10") == ("resize", ["20", "10"])
    try:
        transform_image(b"x" * (8 * 1024 * 1024 + 1), "gray")
    except ValueError as exc:
        assert "8" in str(exc)
    else:
        raise AssertionError("oversized image should fail")


def test_crop_rejects_coordinates_outside_image():
    try:
        transform_image(png_bytes(), "crop", ["50", "50", "60", "60"])
    except ValueError as exc:
        assert "خارج" in str(exc)
    else:
        raise AssertionError("crop outside the image should fail")


class WebImageFeatureTests(unittest.TestCase):
    test_url_parser_is_unique_and_limited = staticmethod(
        test_url_parser_is_unique_and_limited
    )
    test_private_and_userinfo_urls_are_rejected = staticmethod(
        test_private_and_userinfo_urls_are_rejected
    )
    test_html_extraction_omits_scripts_and_marks_untrusted = staticmethod(
        test_html_extraction_omits_scripts_and_marks_untrusted
    )
    test_image_operations_and_png_output = staticmethod(
        test_image_operations_and_png_output
    )
    test_image_limits_and_parser = staticmethod(test_image_limits_and_parser)
    test_crop_rejects_coordinates_outside_image = staticmethod(
        test_crop_rejects_coordinates_outside_image
    )

    def test_no_link_context_is_empty(self):
        self.assertEqual(asyncio.run(read_link_context("hello there")), "")

    def test_public_resolver_rejects_private_dns_answers(self):
        resolver = _PublicResolver()
        private_answer = [
            (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("127.0.0.1", 443))
        ]
        with patch("web_image_features.socket.getaddrinfo", return_value=private_answer):
            with self.assertRaisesRegex(OSError, "non-public"):
                asyncio.run(resolver.resolve("public-looking.example", 443))


if __name__ == "__main__":
    unittest.main()