"""Run the API and Discord bot together in a single-instance Reserved VM."""
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent.parent


def supervise(commands):
    stopping = False
    processes = {}
    retries = {}

    def stop(signum, frame):
        nonlocal stopping
        stopping = True

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    try:
        while not stopping:
            for name, (command, environment) in commands.items():
                process = processes.get(name)
                if process is not None and process.poll() is not None:
                    print(f"{name} exited ({process.returncode}); retrying in 5 seconds", flush=True)
                    processes.pop(name)
                    retries[name] = time.monotonic() + 5
                if name not in processes and time.monotonic() >= retries.get(name, 0):
                    processes[name] = subprocess.Popen(
                        command, cwd=ROOT, env=environment, start_new_session=True
                    )
                    print(f"Started {name}", flush=True)
            time.sleep(0.5)
    finally:
        for process in processes.values():
            if process.poll() is None:
                os.killpg(process.pid, signal.SIGTERM)
        for process in processes.values():
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()


if __name__ == "__main__":
    for key in ("DISCORD_TOKEN", "GROQ_API_KEY"):
        if not os.environ.get(key):
            raise RuntimeError(f"Missing production secret: {key}")
    environment = dict(os.environ)
    environment["PYTHONPATH"] = str(ROOT / "python-starter" / "vendor")
    supervise({
        "API": (
            ["node", "--enable-source-maps", "artifacts/api-server/dist/index.mjs"],
            {**environment, "PORT": "8080", "NODE_ENV": "production"},
        ),
        "Discord bot": (
            [sys.executable, "-u", "python-starter/bot.py"],
            {**environment, "PORT": "8008", "GAME_REQUIRE_EXISTING_STATE": "1"},
        ),
    })