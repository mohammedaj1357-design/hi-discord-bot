"""Offline casino tests; no Discord login or real-money services."""

import asyncio
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import discord
from discord.ext import commands

from casino_commands import ChallengeView, setup_casino_commands
from casino_engine import (
    CasinoError, balance, buy_ticket, draw_lottery, lottery_status, play,
    reward, roulette_choice, settle_challenge, transfer,
)
from game_store import GameStore, STARTING_MONEY


class CasinoRulesTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "game.json"
        self.store = GameStore(self.path)

    def test_invalid_and_insufficient_stakes_do_not_debit(self):
        for stake in (None, "", "0", "-10", "1.2", "NaN", str(10 ** 13)):
            with self.subTest(stake=stake), self.assertRaises(CasinoError):
                play(self.store, 1, "mine", stake, number="2")
        with self.assertRaises(CasinoError):
            play(self.store, 1, "mine", STARTING_MONEY + 1, number="2")
        self.assertEqual(balance(self.store, 1), STARTING_MONEY)

    def test_settlement_and_shared_balance_persist(self):
        with patch("casino_engine.random.randint", return_value=2):
            delta, _, current = play(self.store, 1, "mine", "100", number="2")
        self.assertEqual((delta, current), (500, STARTING_MONEY + 500))
        with patch("casino_engine.random.randint", return_value=1):
            delta, _, current = play(self.store, 1, "mine", 100, number=2)
        self.assertEqual((delta, current), (-100, STARTING_MONEY + 400))
        self.assertEqual(GameStore(self.path).snapshot()["users"]["1"]["money"], current)
        transfer(self.store, 1, 2, 400)
        self.assertEqual(balance(self.store, 1), STARTING_MONEY)
        self.assertEqual(balance(self.store, 2), STARTING_MONEY + 400)

    def test_dice_optional_number_rolls_a_random_player_number(self):
        with patch("casino_engine.random.randint", side_effect=[3, 3]):
            delta, detail, _ = play(self.store, 1, "mine", 100)
        self.assertEqual(delta, 500)
        self.assertIn("رقمك: 3", detail)

    def test_persisted_atomic_cooldowns(self):
        with patch("casino_engine.random.randint", return_value=500):
            self.assertEqual(reward(self.store, 1, "salary", now=1_000)[0], 500)
        with self.assertRaises(CasinoError):
            reward(GameStore(self.path), 1, "salary", now=1_001)
        with patch("casino_engine.random.randint", return_value=500):
            self.assertEqual(reward(self.store, 1, "salary", now=87_400)[0], 500)
        with patch("casino_engine.random.random", return_value=.7):
            play(self.store, 1, "invest", 50, now=1000)
        with self.assertRaises(CasinoError):
            play(GameStore(self.path), 1, "invest", 50, now=1001)

    def test_roulette_parsing_and_spin(self):
        self.assertEqual(roulette_choice("رقم", "0"), ("number", 0))
        self.assertEqual(roulette_choice("36"), ("number", 36))
        for choice, number in (("رقم", None), ("رقم", "37"), ("رقم", "-1"),
                               ("xx", None), ("أحمر", "7")):
            with self.subTest(choice=choice), self.assertRaises(CasinoError):
                roulette_choice(choice, number)
        with patch("casino_engine.random.randint", return_value=7):
            self.assertEqual(play(self.store, 1, "roulette", 100,
                                  choice="رقم", number="7")[0], 3500)
        with patch("casino_engine.random.randint", return_value=0):
            self.assertEqual(play(self.store, 1, "roulette", 100,
                                  choice="أحمر")[0], -100)

    def test_lottery_and_challenge(self):
        buy_ticket(self.store, 1, 100)
        buy_ticket(self.store, 2, 300)
        self.assertEqual(lottery_status(GameStore(self.path)), (400, 400))
        with patch("casino_engine.random.choices", return_value=["2"]):
            self.assertEqual(draw_lottery(self.store), (2, 400))
        self.assertEqual(lottery_status(self.store), (0, 0))
        self.assertEqual(balance(self.store, 2), STARTING_MONEY + 100)
        with self.assertRaises(CasinoError):
            draw_lottery(self.store)
        with patch("casino_engine.random.choice", return_value=1):
            self.assertEqual(settle_challenge(self.store, 1, 2, 100), 1)
        self.assertEqual(balance(self.store, 1), STARTING_MONEY)
        self.assertEqual(balance(self.store, 2), STARTING_MONEY)

    def test_blocking_either_player_after_challenge_creation_prevents_settlement(self):
        balance(self.store, 1)
        balance(self.store, 2)
        for blocked_id in ("1", "2"):
            with self.store.transaction() as data:
                data["blocked_users"] = [blocked_id]
            before = self.store.snapshot()
            with self.assertRaisesRegex(CasinoError, "محظور"):
                settle_challenge(self.store, 1, 2, 100)
            self.assertEqual(self.store.snapshot(), before)
        with self.assertRaises(CasinoError):
            settle_challenge(self.store, 1, 2, STARTING_MONEY + 1)
        self.assertEqual(balance(self.store, 1), STARTING_MONEY)
        self.assertEqual(balance(self.store, 2), STARTING_MONEY)

    def test_atomic_concurrent_spending(self):
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            results = list(executor.map(lambda _: self._try_transfer(), range(2)))
        self.assertEqual(sorted(results), [False, True])
        self.assertEqual(balance(self.store, 1), STARTING_MONEY - 3000)
        self.assertEqual(balance(self.store, 2), STARTING_MONEY + 3000)

    def _try_transfer(self):
        try:
            transfer(self.store, 1, 2, 3000)
            return True
        except CasinoError:
            return False


class CommandTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.store = GameStore(Path(self.temp.name) / "game.json")
        self.bot = commands.Bot(command_prefix="!", intents=discord.Intents.default())
        setup_casino_commands(self.bot, self.store, 999)
        setup_casino_commands(self.bot, self.store, 999)
        self.responses = []
        self.author = SimpleNamespace(id=1, mention="<@1>")
        self.target = SimpleNamespace(id=2, mention="<@2>", bot=False)
        self.guild = SimpleNamespace(id=7, get_member=lambda uid: self.target if uid == 2 else None)
        async def reply(*args, **kwargs):
            self.responses.append((args, kwargs))
            return SimpleNamespace(edit=self._edit)
        self.ctx = SimpleNamespace(author=self.author, guild=self.guild, reply=reply, send=reply)

    async def _edit(self, *args, **kwargs):
        self.responses.append((args, kwargs))

    async def test_registration_and_roulette_number_command(self):
        self.assertEqual(len([c for c in self.bot.commands if c.extras.get("game")]), 20)
        with patch("casino_engine.random.randint", return_value=7):
            await self.bot.get_command("روليت").callback(self.ctx, "100", "رقم", "7")
        self.assertEqual(balance(self.store, 1), STARTING_MONEY + 3500)
        await self.bot.get_command("روليت").callback(self.ctx, "100", "رقم")
        self.assertEqual(balance(self.store, 1), STARTING_MONEY + 3500)

    async def test_dice_amount_only_and_invalid_choice(self):
        with patch("casino_engine.random.randint", side_effect=[2, 2]):
            await self.bot.get_command("ماين").callback(self.ctx, "100")
        self.assertEqual(balance(self.store, 1), STARTING_MONEY + 500)
        await self.bot.get_command("ماين").callback(self.ctx, "100", "7")
        self.assertEqual(balance(self.store, 1), STARTING_MONEY + 500)

    async def test_uncached_member_id_and_message_mention_resolution(self):
        async def fetch_member(uid):
            self.assertEqual(uid, 2)
            return self.target
        self.guild.get_member = lambda uid: None
        self.guild.fetch_member = fetch_member
        self.ctx.message = SimpleNamespace(mentions=[])
        await self.bot.get_command("تحويل").callback(self.ctx, "2", "100")
        self.assertEqual(balance(self.store, 1), STARTING_MONEY - 100)
        self.assertEqual(balance(self.store, 2), STARTING_MONEY + 100)

        class FakeMember:
            def __init__(self, guild):
                self.id, self.mention, self.bot, self.guild = 2, "<@2>", False, guild

        mention = FakeMember(self.guild)
        self.ctx.message.mentions = [mention]
        async def no_fetch(uid):
            self.fail("A valid message mention should not need a REST fetch")
        self.guild.fetch_member = no_fetch
        with patch("casino_commands.discord.Member", FakeMember):
            await self.bot.get_command("تحويل").callback(self.ctx, "<@2>", "50")
        self.assertEqual(balance(self.store, 1), STARTING_MONEY - 150)
        await self.bot.get_command("تحويل").callback(self.ctx, "<@1>", "50")
        self.assertEqual(balance(self.store, 1), STARTING_MONEY - 150)

    async def test_lottery_draw_authorization(self):
        await self.bot.get_command("يانصيب").callback(self.ctx, "100")
        await self.bot.get_command("يانصيب_سحب").callback(self.ctx)
        self.assertEqual(lottery_status(self.store), (100, 100))
        self.ctx.author = SimpleNamespace(id=999, mention="<@999>")
        await self.bot.get_command("يانصيب").callback(self.ctx, "سحب")
        self.assertEqual(lottery_status(self.store), (0, 0))

    async def test_challenge_consent_and_duplicate_clicks(self):
        await self.bot.get_command("تحدي").callback(self.ctx, "<@2>", "100")
        self.assertEqual(balance(self.store, 1), STARTING_MONEY)
        view = self.responses[-1][1]["view"]
        stranger_responses = []
        async def send_message(*args, **kwargs):
            stranger_responses.append((args, kwargs))
        async def edit_message(*args, **kwargs):
            stranger_responses.append((args, kwargs))
        response = SimpleNamespace(send_message=send_message, edit_message=edit_message)
        other = SimpleNamespace(user=self.author, response=response)
        self.assertFalse(await view.interaction_check(other))
        self.assertEqual(balance(self.store, 1), STARTING_MONEY)
        target = SimpleNamespace(user=self.target, response=response)
        with patch("casino_engine.random.choice", return_value=1):
            await view.accept.callback(target)
        self.assertEqual(balance(self.store, 1), STARTING_MONEY + 100)
        self.assertEqual(balance(self.store, 2), STARTING_MONEY - 100)
        await view.accept.callback(target)
        self.assertEqual(balance(self.store, 1), STARTING_MONEY + 100)
        another = ChallengeView(self.store, self.author, self.target, 100)
        await another.decline.callback(target)
        self.assertEqual(balance(self.store, 2), STARTING_MONEY - 100)

    async def test_challenge_acceptance_concurrent_balance_recheck_and_timeout(self):
        async def edit_message(*args, **kwargs):
            self.responses.append((args, kwargs))
        target = SimpleNamespace(user=self.target,
                                 response=SimpleNamespace(edit_message=edit_message))
        first = ChallengeView(self.store, self.author, self.target, 3000)
        second = ChallengeView(self.store, self.author, self.target, 3000)
        with patch("casino_engine.random.choice", return_value=1):
            await asyncio.gather(
                first.accept.callback(target), second.accept.callback(target))
        self.assertEqual(balance(self.store, 1), STARTING_MONEY + 3000)
        self.assertEqual(balance(self.store, 2), STARTING_MONEY - 3000)
        self.assertTrue(any("لم يبدأ التحدي" in kwargs.get("content", "")
                            for _, kwargs in self.responses))
        expired = ChallengeView(self.store, self.author, self.target, 100)
        expired.message = SimpleNamespace(edit=self._edit)
        await expired.on_timeout()
        self.assertEqual(balance(self.store, 2), STARTING_MONEY - 3000)


if __name__ == "__main__":
    unittest.main()