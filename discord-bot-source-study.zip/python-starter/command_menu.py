"""Discord command browser with private category responses."""

import logging

import discord

logger = logging.getLogger(__name__)


def category_embed(category):
    titles = {
        "general": "الأوامر العامة",
        "admin": "أوامر الإدارة",
        "dev": "أوامر المطور",
        "ai": "الذكاء الاصطناعي",
        "economy": "الأراضي والاقتصاد",
        "casino": "الألعاب والمكافآت",
    }
    entries = {
        "general": [
            ("!about", "معلومات عن البوت."),
            ("!ping", "قياس زمن استجابة Discord."),
            ("!uptime", "مدة تشغيل نسخة البوت الحالية."),
            ("!memory", "عدد الرسائل المؤقتة في سياق محادثتك دون عرض محتواها."),
            ("!server / !serverinfo", "عرض معلومات السيرفر الحالي."),
            ("!whereami", "معرفة اسم السيرفر والقناة الحالية."),
            ("!servers", "عرض سيرفرات البوت؛ للمطور فقط."),
            ("!مستواي / !level", "عرض مستوى XP وتقدّمك أو مستوى عضو."),
            ("!توب / !top_levels", "أفضل 10 أعضاء حسب XP في هذا السيرفر."),
            ("!xp_help", "شرح كسب XP من الرسائل والصوت."),
            ("!level_roles", "عرض مكافآت الرتب المضبوطة لكل مستوى في هذا السيرفر."),
            ("!image / !تعديل", "تعديل صورة مرفقة أو صورة في رسالة تشير إليها."),
            ("!play <اسم أو رابط YouTube>", "تشغيل أغنية أو إضافتها لقائمة الانتظار مع أزرار التحكم."),
            ("!queue / !قائمة", "عرض قائمة انتظار الموسيقى."),
            ("!nowplaying / !np", "عرض الأغنية التي تعمل حاليًا."),
            ("!music_help", "عرض أوامر الموسيقى وأزرار التحكم."),
            ("!command", "عرض قائمة الأوامر التفاعلية."),
            ("!help [اسم_الأمر]", "عرض المساعدة النصية أو تفاصيل أمر."),
            ("!currentchannel", "عرض قناة ردود البوت المحددة داخل السيرفر."),
            ("!تعلم / !learn", "التحقق من حالة التعلّم الاختياري."),
            ("!تعلم_تشغيل / !learn_on", "الموافقة على تحليل رسائلك واستخراج معلومات واهتمامات؛ لا يُحفظ نص الرسائل."),
            ("!تعلم_ايقاف / !learn_off", "إيقاف تحليل الرسائل الجديدة؛ تبقى البيانات السابقة حتى تحذفها."),
            ("!معلوماتي / !myinfo", "إرسال ملف بياناتك الخاص إليك عبر الرسائل الخاصة."),
            ("!نسيان <كلمة> / !forget", "حذف معلومات أو اهتمامات أو مواضيع مطابقة من ملفك."),
            ("!مسح_معلوماتي / !clear_my_info", "حذف ملفك كله وإيقاف التعلّم."),
        ],
        "admin": [
            ("!level_role_set <مستوى> @رتبة", "ضبط رتبة مكافأة عند بلوغ مستوى؛ لإداريي السيرفر."),
            ("!level_role_remove <مستوى>", "حذف مكافأة رتبة لمستوى؛ لإداريي السيرفر."),
            ("/levelsetup", "تحديد روم إشعارات الارتقاء أو إرسالها في الخاص أو إيقافها؛ لإداريي السيرفر."),
            ("!setchannel #القناة", "تحديد قناة ردود البوت داخل السيرفر."),
            ("!setchannel", "تحديد القناة الحالية."),
            ("!clearchannel", "إلغاء التحديد؛ يرد البوت عند منشنه في أي قناة مسموحة."),
            ("/set — تغيير الصورة", "رفع PNG أو JPG أو GIF أو إضافة رابط HTTPS لصورة الردود."),
            ("/set — تغيير الاسم", "تحديد اسم مخصص لردود البوت في هذا السيرفر."),
            ("/set — عرض الإعدادات", "معاينة الاسم والصورة المستخدمة حاليًا."),
            ("/setting — هوية السيرفر/حساب البوت", "التبديل بين هوية السيرفر وحساب البوت مع حفظ التخصيصات."),
            ("/setting — Webhook للصور فقط", "تحليل الصور بهوية السيرفر وإرسال الردود النصية بهوية حساب البوت."),
            ("/set — إعادة الافتراضي", "العودة إلى اسم وأيقونة السيرفر بعد تأكيد ونسخة احتياطية."),
            ("/antilink enable / disable / set_timeout / show", "منع الروابط مع حذف الرسائل ومهلة قابلة للضبط؛ معطّل افتراضيًا."),
            ("/antilink allow_channel / remove_channel / exempt_role / remove_role", "السماح بالروابط في قنوات محددة أو إعفاء رتب؛ لإداريي السيرفر."),
        ],
        "dev": [
            ("!dev", "عرض معلومات المطور."),
            ("!level_stats", "إحصائيات XP والرسائل والصوت للسيرفر الحالي؛ للمطور فقط."),
            ("!dm @user رسالتك", "إرسال رسالة خاصة؛ يمكنك استخدام USER_ID بدلاً من المنشن. يخضع لإعدادات الخصوصية."),
            ("!يانصيب_سحب", "سحب فائز باليانصيب وتسليم الجائزة الافتراضية؛ للمطور فقط."),
            ("!adminmenu", "دليل كل أوامر المطور بالتفصيل."),
            ("!addmoney / !removemoney / !setmoney @user مبلغ", "تعديل رصيد لاعب افتراضي؛ يمكن كتابة `me` بدلاً من المنشن."),
            ("!givemoney مبلغ", "منح رصيد افتراضي لجميع اللاعبين المحفوظين بعد التأكيد."),
            ("!addlands @user عدد / !addincome @user مبلغ", "إضافة أراضٍ أو تحديد دخل إضافي بالساعة."),
            ("!block / !unblock @user / !blocked", "إدارة حظر اللاعبين من أوامر اللعبة."),
            ("!stats / !moneyboard / !allplayers", "إحصائيات اللعبة وقوائم اللاعبين."),
            ("!resetall / !resetuser @user", "حذف تقدم اللعبة أو لاعب محدد بعد التأكيد ونسخة احتياطية."),
            ("!backup / !backups", "إنشاء نسخ احتياطية محلية وعرضها."),
            ("!logs [عدد] / !clearlogs", "عرض سجل إجراءات المطور أو مسحه مع تأكيد."),
            ("!broadcast الرسالة", "إعلان إلى السيرفرات بعد التأكيد؛ دون منشنات."),
            ("!status / !resetcool", "حالة البوت أو تصفير فترات الانتظار بعد التأكيد والنسخ الاحتياطي."),
            ("!say الرسالة / !welcometest", "إرسال رسالة بلا منشنات أو معاينة ترحيب تجريبية."),
            ("!احصائيات_التعلم / !learning_stats", "إحصائيات تعلّم مجمّعة فقط؛ للمطور."),
            ("/filter add / remove / list", "إدارة القائمة العامة لمرشح اللغة؛ للمطور فقط."),
            ("/filter server-add / server-remove / server-list / server-overrides / server-compare / server-reset / server-history", "إدارة تعديلات هذا السيرفر؛ يعرض server-overrides القواعد الفعالة والمحفوظة التي تطابق القائمة العامة دون تغيير الإعدادات. للمطور فقط."),
            ("!restart / !shutdown", "إعادة تشغيل البوت أو إيقافه بالكامل بعد التأكيد."),
        ],
        "ai": [
            ("منشن البوت", "اكتب `@البوت سؤالك هنا` أو أرفق صورة مع المنشن في قناة مسموحة. إذا حدد الإداري قناة، استخدمها."),
            ("المحادثة الخاصة", "أرسل سؤالك مباشرة إلى البوت في الخاص دون منشن."),
            ("قراءة الروابط", "منشن البوت مع رابط صفحة عامة؛ يقرأ محتواها النصي ليساعدك في فهمها."),
            ("تحليل الصور", "أرفق حتى 4 صور PNG أو JPG أو WebP في الرسالة (8 MB إجمالاً). تُرسل الصور إلى Gemini للتحليل ولا تُحفظ محلياً."),
            ("ذاكرة المحادثة", "يحتفظ البوت بآخر 10 رسائل لكل مستخدم، وتشمل أسئلتك وردوده. الذاكرة مؤقتة وتُفقد عند إعادة تشغيل البوت؛ لا يوجد مسح يومي مجدول حالياً."),
            ("أمثلة", "`@البوت اشرح لي Python`\n`@البوت اكتب كود حساب مساحة دائرة`\n`@البوت ترجم هذا النص إلى العربية`"),
        ],
        "economy": [
            ("!الالعاب", "دليل الاقتصاد والمباني. تبدأ برصيد 5,000 عملة افتراضية."),
            ("!بنك [الصفحة]", "رصيدك وأراضيك والدخل. مثال: !بنك 2. يمكن أيضاً استخدام !رصيد أو !bank."),
            ("!شراء", "شراء أرض مقابل 1,000 عملة افتراضية."),
            ("!بناء رقم_الأرض نوع_المبنى", "مثال: !بناء 1 kosh. اكتب !بناء لعرض الأنواع والأسعار."),
            ("!جمع", "جمع دخل المباني المتراكم، بما فيه فترة توقف البوت."),
            ("!تطوير رقم_الأرض", "تطوير مبنى حتى المستوى الخامس لزيادة دخله."),
            ("!اغنى", "ترتيب أغنى اللاعبين."),
        ],
        "casino": [
            ("!كازينو", "دليل الألعاب والقواعد. اكتب اسم أي لعبة وحده لعرض استخدامها."),
            ("!ماين / !كنز / !ابراج", "ألعاب النرد والكنز والأبراج برهان افتراضي."),
            ("!صاروخ / !استثمار / !تداول", "ألعاب المضاعفات والاستثمار والتداول الافتراضي."),
            ("!سلوتس / !عجلة", "السلوتس وعجلة الحظ."),
            ("!روليت / !بلاكجاك", "روليت الألوان والأرقام ولعبة الورق."),
            ("!سباق / !رماية", "سباق الخيل والرماية."),
            ("!يانصيب", "شراء تذاكر افتراضية؛ السحب اليدوي للمطور."),
            ("!تحدي", "تحدٍّ بين لاعبين؛ لا يُخصم الرهان إلا بعد موافقة الطرف الآخر."),
            ("!راتب / !بخشيش", "مكافآت مجانية مع فترة انتظار بين مرات الاستلام."),
            ("!فلوسي / !تحويل @user مبلغ", "عرض الرصيد أو تحويل عملات افتراضية إلى عضو في السيرفر."),
        ],
    }
    colors = {"general": 0x4A90E2, "admin": 0xFFA500, "dev": 0xFFD700, "ai": 0x9B59B6,
              "economy": 0x27AE60, "casino": 0xE67E22}
    embed = discord.Embed(title=titles[category], color=colors[category])
    for name, description in entries[category]:
        embed.add_field(name=f"`{name}`", value=description, inline=False)
    if category == "admin":
        embed.description = (
            "تنفيذ هذه الأوامر يحتاج صلاحية Administrator داخل السيرفر، حتى للمطور. "
            "تظهر هوية الردود المخصصة في القنوات التي يملك فيها البوت صلاحية Manage Webhooks."
        )
    elif category == "dev":
        embed.description = "هذه الأوامر متاحة للمطور فقط."
    elif category == "ai":
        embed.description = "طريقة استخدام البوت للمحادثة والأسئلة والمساعدة في البرمجة."
    elif category in ("economy", "casino"):
        embed.description = "رصيد افتراضي مشترك للألعاب فقط؛ لا شراء بأموال حقيقية ولا سحب أو تحويل إلى نقود."
    else:
        embed.description = "للدردشة: منشن البوت مع سؤالك في القناة المسموحة، أو راسله على الخاص."
    embed.set_footer(text="اكتب الأوامر مباشرة بدون منشن البوت في البداية.")
    return embed


class CommandCategorySelect(discord.ui.Select):
    def __init__(self, developer_id):
        self.developer_id = developer_id
        super().__init__(
            placeholder="اختر فئة الأوامر...",
            options=[
                discord.SelectOption(label="الأوامر العامة", value="general", description="متاحة للجميع"),
                discord.SelectOption(label="أوامر الإدارة", value="admin", description="تحتاج صلاحية Administrator"),
                discord.SelectOption(label="أوامر المطور", value="dev", description="خاصة بالمطور فقط"),
                discord.SelectOption(label="الذكاء الاصطناعي", value="ai", description="طريقة المحادثة والذاكرة وأمثلة الاستخدام"),
                discord.SelectOption(label="الأراضي والاقتصاد", value="economy", description="شراء وبناء وتطوير وجمع الأرباح"),
                discord.SelectOption(label="الألعاب والمكافآت", value="casino", description="الألعاب الافتراضية والراتب والتحديات"),
            ],
        )

    async def callback(self, interaction):
        category = self.values[0]
        if category == "dev" and interaction.user.id != self.developer_id:
            await interaction.response.send_message("هذه الأوامر خاصة بمطور البوت فقط.", ephemeral=True)
            return
        # Private responses prevent developer details from being exposed in a public menu.
        await interaction.response.send_message(embed=category_embed(category), ephemeral=True)


class CommandCategoryView(discord.ui.View):
    def __init__(self, developer_id):
        super().__init__(timeout=300)
        self.message = None
        self.add_item(CommandCategorySelect(developer_id))

    async def on_timeout(self):
        for item in self.children:
            item.disabled = True
            item.placeholder = "انتهت المهلة؛ اكتب !command لفتح قائمة جديدة"
        if self.message:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                logger.warning("Could not disable expired command menu.")


async def send_command_menu(ctx, developer_id):
    embed = discord.Embed(
        title="قائمة أوامر البوت",
        description=(
            "اختر فئة من القائمة أدناه لعرض الأوامر وطريقة استخدامها.\n\n"
            "**الأوامر العامة** — للجميع\n"
            "**أوامر الإدارة** — لإداريي السيرفر\n"
            "**أوامر المطور** — للمطور فقط\n"
            "**الذكاء الاصطناعي** — المحادثة والذاكرة وأمثلة الاستخدام\n\n"
            "**الأراضي والاقتصاد** — المباني والأرباح والترتيب\n"
            "**الألعاب والمكافآت** — ألعاب برصيد افتراضي فقط\n\n"
            "تفاصيل اختيارك تظهر لك وحدك. تنتهي صلاحية القائمة بعد 5 دقائق؛ "
            "اكتب `!command` لفتحها مجدداً."
        ),
        color=0x4A90E2,
    )
    if ctx.bot.user:
        embed.set_thumbnail(url=ctx.bot.user.display_avatar.url)
    view = CommandCategoryView(developer_id)
    view.message = await ctx.reply(
        embed=embed, view=view, mention_author=False,
        allowed_mentions=discord.AllowedMentions.none(),
    )