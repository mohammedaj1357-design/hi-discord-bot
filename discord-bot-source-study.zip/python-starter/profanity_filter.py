"""Delete server messages containing configured insults or profanity."""

from __future__ import annotations

import json
import logging
import os
import re
import tempfile
import unicodedata
import uuid
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

import discord
from discord import app_commands


logger = logging.getLogger(__name__)
WARNING_SECONDS = 5

# Keep this list to direct insults and profanity. Neutral animal names, identity
# terms, and context-dependent words such as "جاي" are intentionally excluded.
BAD_WORDS = (
    "غبي",
    "غبية",
    "أغبياء",
    "أحمق",
    "حمقاء",
    "جاهل",
    "جاهلة",
    "فاشل",
    "فاشلة",
    "تافه",
    "تافهة",
    "قذر",
    "قذرة",
    "وسخ",
    "وسخة",
    "حقير",
    "حقيرة",
    "ذليل",
    "ذليلة",
    "منحط",
    "منحطة",
    "زبالة",
    "زباله",
    "خرا",
    "خراء",
    "زق",
    "عبيط",
    "بليد",
    "معتوه",
    "متخلف",
    "متخلفة",
    "idiot",
    "stupid",
    "dumb",
    "fool",
    "moron",
    "loser",
    "لعنة عليك",
    "يلعن",
    "الله يلعن",
    "قبحك",
    "اخرس",
    "تفو",
    "تفو عليك",
)

MAX_CONFIGURED_TERMS = 250
MAX_TERM_LENGTH = 80
MAX_TERM_WORDS = 5
_ARABIC_DIACRITICS = {
    chr(codepoint)
    for codepoint in (*range(0x064B, 0x0660), 0x0670, 0x0640)
}

_ARABIC_MARKS = re.compile(r"[\u064B-\u065F\u0670\u0640]")
_PUNCTUATION = re.compile(r"[^\w\s]", flags=re.UNICODE)
_ARABIC_TRANSLATION = str.maketrans(
    {
        "أ": "ا",
        "إ": "ا",
        "آ": "ا",
        "ٱ": "ا",
        "ؤ": "و",
        "ئ": "ي",
        "ى": "ي",
    }
)


def _normalize(text: str) -> str:
    text = unicodedata.normalize("NFKC", text).casefold()
    text = _ARABIC_MARKS.sub("", text).translate(_ARABIC_TRANSLATION)
    text = _PUNCTUATION.sub(" ", text)
    return " ".join(text.split())


class ProfanityTermError(ValueError):
    """Raised when a filtered term is invalid or cannot be changed."""


class ProfanityTermStore:
    """Persist developer-managed additions and removals from the built-in list."""

    def __init__(
        self,
        path: Path | str | None = None,
        *,
        base_terms: Iterable[str] = BAD_WORDS,
    ):
        self.path = (
            Path(path)
            if path
            else Path(__file__).parent / "data" / "blocked_terms.json"
        )
        self.base_terms = tuple(base_terms)
        self._added: list[str] = []
        self._removed: list[str] = []
        self._history: list[dict[str, object]] = []
        self._load()

    @staticmethod
    def _clean_term(term: str) -> str:
        if not isinstance(term, str):
            raise ProfanityTermError("اكتب كلمة أو عبارة نصية.")
        term = term.strip()
        if not term or len(term) > MAX_TERM_LENGTH:
            raise ProfanityTermError(
                f"يجب أن يكون طول الكلمة أو العبارة بين حرفين و{MAX_TERM_LENGTH} حرفاً."
            )
        if any(
            not (
                character.isalpha()
                or character == " "
                or character in _ARABIC_DIACRITICS
            )
            for character in term
        ):
            raise ProfanityTermError("استخدم الحروف والمسافات فقط، دون رموز أو أرقام.")
        normalized = _normalize(term)
        if len(normalized.replace(" ", "")) < 2:
            raise ProfanityTermError("يجب أن تتكون الكلمة أو العبارة من حرفين على الأقل.")
        if len(normalized.split()) > MAX_TERM_WORDS:
            raise ProfanityTermError(
                f"لا يمكن أن تتجاوز العبارة {MAX_TERM_WORDS} كلمات."
            )
        return normalized

    @staticmethod
    def _key(term: str) -> str:
        return _normalize(term)

    def list_terms(self) -> list[str]:
        removed = {self._key(term) for term in self._removed}
        result = [term for term in self.base_terms if self._key(term) not in removed]
        result.extend(self._added)
        return result

    @staticmethod
    def _validate_developer_id(developer_id: int) -> None:
        if (
            isinstance(developer_id, bool)
            or not isinstance(developer_id, int)
            or developer_id <= 0
        ):
            raise ProfanityTermError("تعذر التحقق من هوية المطور.")

    def list_history(self) -> list[dict[str, object]]:
        """Return a copy of the persisted changes to the configured word list."""
        return [entry.copy() for entry in self._history]

    def add(self, term: str, developer_id: int) -> str:
        self._validate_developer_id(developer_id)
        cleaned = self._clean_term(term)
        key = self._key(cleaned)
        if any(self._key(existing) == key for existing in self.list_terms()):
            raise ProfanityTermError("هذه الكلمة أو العبارة موجودة بالفعل.")

        before_added = self._added.copy()
        before_removed = self._removed.copy()
        before_history = self.list_history()
        base_term = next(
            (item for item in self.base_terms if self._key(item) == key),
            None,
        )
        if base_term is not None:
            self._removed = [item for item in self._removed if self._key(item) != key]
        else:
            if len(self.list_terms()) >= MAX_CONFIGURED_TERMS:
                raise ProfanityTermError("وصلت قائمة الكلمات إلى الحد الأقصى.")
            self._added.append(cleaned)
        self._history.append(
            {
                "developer_id": developer_id,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "action": "add",
                "term": cleaned,
            }
        )

        try:
            self._save()
        except OSError:
            self._added = before_added
            self._removed = before_removed
            self._history = before_history
            raise
        return cleaned

    def remove(self, term: str, developer_id: int) -> str:
        self._validate_developer_id(developer_id)
        cleaned = self._clean_term(term)
        key = self._key(cleaned)
        existing = next(
            (item for item in self.list_terms() if self._key(item) == key),
            None,
        )
        if existing is None:
            raise ProfanityTermError("هذه الكلمة أو العبارة غير موجودة في القائمة.")

        before_added = self._added.copy()
        before_removed = self._removed.copy()
        before_history = self.list_history()
        base_term = next(
            (item for item in self.base_terms if self._key(item) == key),
            None,
        )
        if base_term is not None:
            self._removed.append(base_term)
        else:
            self._added = [item for item in self._added if self._key(item) != key]
        self._history.append(
            {
                "developer_id": developer_id,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "action": "remove",
                "term": existing,
            }
        )

        try:
            self._save()
        except OSError:
            self._added = before_added
            self._removed = before_removed
            self._history = before_history
            raise
        return existing

    def _load(self) -> None:
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return
        if (
            not isinstance(payload, dict)
            or set(payload) not in (
                {"added", "removed"},
                {"added", "removed", "history"},
            )
            or not isinstance(payload["added"], list)
            or not isinstance(payload["removed"], list)
            or (
                "history" in payload
                and not isinstance(payload["history"], list)
            )
        ):
            raise ValueError(f"Invalid filtered-term data in {self.path}.")

        added = [self._clean_term(term) for term in payload["added"]]
        removed = [self._clean_term(term) for term in payload["removed"]]
        base_keys = {self._key(term) for term in self.base_terms}
        added_keys = [self._key(term) for term in added]
        removed_keys = [self._key(term) for term in removed]
        if (
            len(set(added_keys)) != len(added_keys)
            or len(set(removed_keys)) != len(removed_keys)
            or any(key in base_keys for key in added_keys)
            or any(key not in base_keys for key in removed_keys)
            or len(added) > MAX_CONFIGURED_TERMS
        ):
            raise ValueError(f"Invalid or duplicate filtered terms in {self.path}.")
        history = payload.get("history", [])
        for entry in history:
            if (
                not isinstance(entry, dict)
                or set(entry) != {"developer_id", "timestamp", "action", "term"}
                or isinstance(entry["developer_id"], bool)
                or not isinstance(entry["developer_id"], int)
                or entry["developer_id"] <= 0
                or not isinstance(entry["action"], str)
                or entry["action"] not in {"add", "remove"}
            ):
                raise ValueError(f"Invalid filtered-term history in {self.path}.")
            try:
                timestamp = datetime.fromisoformat(entry["timestamp"])
                self._clean_term(entry["term"])
            except (TypeError, ValueError, ProfanityTermError) as error:
                raise ValueError(
                    f"Invalid filtered-term history in {self.path}."
                ) from error
            if timestamp.tzinfo is None:
                raise ValueError(f"Invalid filtered-term history in {self.path}.")
        self._added = added
        self._removed = removed
        self._history = [entry.copy() for entry in history]

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "added": self._added,
            "removed": self._removed,
            "history": self._history,
        }
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(
                "w",
                encoding="utf-8",
                dir=self.path.parent,
                prefix=f".{self.path.name}.",
                suffix=".tmp",
                delete=False,
            ) as output:
                temp_path = Path(output.name)
                json.dump(payload, output, ensure_ascii=False, indent=2)
                output.flush()
                os.fsync(output.fileno())
            os.replace(temp_path, self.path)
        finally:
            if temp_path is not None:
                temp_path.unlink(missing_ok=True)


class GuildProfanityTermStore:
    """Persist developer-managed filtered-term overrides separately per guild."""

    def __init__(self, path: Path | str):
        self.path = Path(path)
        self.backup_dir = self.path.parent / f"{self.path.stem}_backups"
        self._guilds: dict[str, dict[str, list]] = {}
        self._load()

    @staticmethod
    def _validate_guild_id(guild_id: int) -> None:
        if (
            isinstance(guild_id, bool)
            or not isinstance(guild_id, int)
            or guild_id <= 0
        ):
            raise ProfanityTermError("تعذر التحقق من هوية السيرفر.")

    @staticmethod
    def _empty_state() -> dict[str, list]:
        return {"added": [], "removed": [], "history": []}

    def list_terms(self, guild_id: int, base_terms: Iterable[str]) -> list[str]:
        """Apply one guild's overrides to the existing global term list."""
        self._validate_guild_id(guild_id)
        state = self._guilds.get(str(guild_id), self._empty_state())
        removed = {ProfanityTermStore._key(term) for term in state["removed"]}
        result: list[str] = []
        seen: set[str] = set()
        for term in (*tuple(base_terms), *state["added"]):
            key = ProfanityTermStore._key(term)
            if key not in removed and key not in seen:
                result.append(term)
                seen.add(key)
        return result

    def list_overrides(
        self, guild_id: int, base_terms: Iterable[str]
    ) -> dict[str, list[str]]:
        """List the additions and exclusions that differ from the current global list."""
        self._validate_guild_id(guild_id)
        base_terms = tuple(base_terms)
        base_keys = {ProfanityTermStore._key(term) for term in base_terms}
        state = self._guilds.get(str(guild_id), self._empty_state())
        return {
            "added": [
                term
                for term in state["added"]
                if ProfanityTermStore._key(term) not in base_keys
            ],
            "removed": [
                term
                for term in state["removed"]
                if ProfanityTermStore._key(term) in base_keys
            ],
        }

    def list_override_status(
        self, guild_id: int, base_terms: Iterable[str]
    ) -> dict[str, list[str]]:
        """Classify saved overrides by whether they affect the current global list."""
        self._validate_guild_id(guild_id)
        base_keys = {
            ProfanityTermStore._key(term) for term in tuple(base_terms)
        }
        saved = self.list_saved_overrides(guild_id)
        return {
            "added_effective": [
                term
                for term in saved["added"]
                if ProfanityTermStore._key(term) not in base_keys
            ],
            "added_retained": [
                term
                for term in saved["added"]
                if ProfanityTermStore._key(term) in base_keys
            ],
            "removed_effective": [
                term
                for term in saved["removed"]
                if ProfanityTermStore._key(term) in base_keys
            ],
            "removed_retained": [
                term
                for term in saved["removed"]
                if ProfanityTermStore._key(term) not in base_keys
            ],
        }

    def list_saved_overrides(self, guild_id: int) -> dict[str, list[str]]:
        """Return every persisted addition and exclusion for one guild."""
        self._validate_guild_id(guild_id)
        state = self._guilds.get(str(guild_id), self._empty_state())
        return {
            "added": state["added"].copy(),
            "removed": state["removed"].copy(),
        }

    def list_history(self, guild_id: int) -> list[dict[str, object]]:
        """Return a copy of the change history for one guild."""
        self._validate_guild_id(guild_id)
        state = self._guilds.get(str(guild_id), self._empty_state())
        return deepcopy(state["history"])

    def reset_guild(
        self,
        guild_id: int,
        developer_id: int,
        *,
        expected_overrides: dict[str, list[str]] | None = None,
        backup_path: Path | str | None = None,
    ) -> dict[str, object] | None:
        """Back up and clear one guild's overrides, retaining an audit record."""
        ProfanityTermStore._validate_developer_id(developer_id)
        self._validate_guild_id(guild_id)
        guild_key = str(guild_id)
        state = self._guilds.get(guild_key, self._empty_state())
        current_overrides = {
            "added": state["added"].copy(),
            "removed": state["removed"].copy(),
        }
        if (
            expected_overrides is not None
            and current_overrides != expected_overrides
        ):
            raise ProfanityTermError(
                "تغيرت تعديلات هذا السيرفر منذ المعاينة؛ لم يتغير شيء. "
                "أعد تشغيل الأمر لمعاينة الوضع الحالي."
            )
        if not current_overrides["added"] and not current_overrides["removed"]:
            return None

        previous_state = deepcopy(state)
        timestamp = datetime.now(timezone.utc).isoformat()
        if backup_path is None:
            saved_backup_path = self._write_backup(
                guild_id, previous_state, timestamp
            )
        else:
            saved_backup_path = self._verify_prepared_backup(
                Path(backup_path), guild_id, previous_state
            )
        reset_entry = {
            "developer_id": developer_id,
            "timestamp": timestamp,
            "action": "reset",
            "added": previous_state["added"].copy(),
            "removed": previous_state["removed"].copy(),
            "backup": saved_backup_path.name,
        }
        self._guilds[guild_key] = {
            "added": [],
            "removed": [],
            "history": [*previous_state["history"], reset_entry],
        }
        try:
            self._save()
        except OSError:
            self._guilds[guild_key] = previous_state
            raise
        return {
            "added": previous_state["added"].copy(),
            "removed": previous_state["removed"].copy(),
            "backup": saved_backup_path.name,
        }

    def prepare_reset_backup(
        self,
        guild_id: int,
        *,
        expected_overrides: dict[str, list[str]] | None = None,
    ) -> Path | None:
        """Save a reset snapshot without changing the server's current settings."""
        self._validate_guild_id(guild_id)
        state = self._guilds.get(str(guild_id), self._empty_state())
        current_overrides = {
            "added": state["added"].copy(),
            "removed": state["removed"].copy(),
        }
        if (
            expected_overrides is not None
            and current_overrides != expected_overrides
        ):
            raise ProfanityTermError(
                "تغيرت تعديلات هذا السيرفر منذ المعاينة؛ لم يتغير شيء. "
                "أعد تشغيل الأمر لمعاينة الوضع الحالي."
            )
        if not current_overrides["added"] and not current_overrides["removed"]:
            return None
        return self._write_backup(
            guild_id,
            deepcopy(state),
            datetime.now(timezone.utc).isoformat(),
        )

    def _verify_prepared_backup(
        self,
        backup_path: Path,
        guild_id: int,
        state: dict[str, list],
    ) -> Path:
        """Require a prepared backup to be private, local, and for this exact state."""
        if (
            self.backup_dir.is_symlink()
            or backup_path.parent != self.backup_dir
            or backup_path.is_symlink()
            or not backup_path.is_file()
        ):
            raise OSError("prepared server filtered-term backup is unavailable")
        payload = json.loads(backup_path.read_text(encoding="utf-8"))
        if (
            not isinstance(payload, dict)
            or set(payload) != {"guild_id", "created_at", "state"}
            or payload["guild_id"] != str(guild_id)
            or payload["state"] != state
        ):
            raise ValueError("prepared server filtered-term backup does not match")
        try:
            created_at = datetime.fromisoformat(payload["created_at"])
        except (TypeError, ValueError) as error:
            raise ValueError("prepared server filtered-term backup is invalid") from error
        if created_at.tzinfo is None:
            raise ValueError("prepared server filtered-term backup is invalid")
        return backup_path

    def _write_backup(
        self,
        guild_id: int,
        state: dict[str, list],
        timestamp: str,
    ) -> Path:
        if self.backup_dir.is_symlink():
            raise OSError(
                "server filtered-term backup directory must not be a symbolic link"
            )
        self.backup_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        if self.backup_dir.is_symlink():
            raise OSError(
                "server filtered-term backup directory must not be a symbolic link"
            )
        self.backup_dir.chmod(0o700)

        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        backup_path = (
            self.backup_dir / f"{guild_id}_{stamp}_{uuid.uuid4().hex}.json"
        )
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(
                "w",
                encoding="utf-8",
                dir=self.backup_dir,
                prefix=".guild-filter-backup-",
                suffix=".tmp",
                delete=False,
            ) as output:
                temp_path = Path(output.name)
                os.chmod(temp_path, 0o600)
                json.dump(
                    {
                        "guild_id": str(guild_id),
                        "created_at": timestamp,
                        "state": state,
                    },
                    output,
                    ensure_ascii=False,
                    indent=2,
                )
                output.flush()
                os.fsync(output.fileno())
            os.replace(temp_path, backup_path)
        finally:
            if temp_path is not None:
                temp_path.unlink(missing_ok=True)
        return backup_path

    def add(
        self,
        guild_id: int,
        term: str,
        developer_id: int,
        base_terms: Iterable[str],
    ) -> str:
        ProfanityTermStore._validate_developer_id(developer_id)
        self._validate_guild_id(guild_id)
        cleaned = ProfanityTermStore._clean_term(term)
        key = ProfanityTermStore._key(cleaned)
        base_terms = tuple(base_terms)
        current_terms = self.list_terms(guild_id, base_terms)
        if any(ProfanityTermStore._key(item) == key for item in current_terms):
            raise ProfanityTermError("هذه الكلمة أو العبارة موجودة بالفعل.")

        state = self._guilds.get(str(guild_id), self._empty_state())
        before_state = {
            "added": state["added"].copy(),
            "removed": state["removed"].copy(),
            "history": [entry.copy() for entry in state["history"]],
        }
        base_term = next(
            (
                item
                for item in base_terms
                if ProfanityTermStore._key(item) == key
            ),
            None,
        )
        if base_term is not None:
            state["added"] = [
                item
                for item in state["added"]
                if ProfanityTermStore._key(item) != key
            ]
            state["removed"] = [
                item
                for item in state["removed"]
                if ProfanityTermStore._key(item) != key
            ]
        else:
            state["removed"] = [
                item
                for item in state["removed"]
                if ProfanityTermStore._key(item) != key
            ]
            if len(current_terms) >= MAX_CONFIGURED_TERMS:
                raise ProfanityTermError("وصلت قائمة الكلمات إلى الحد الأقصى.")
            state["added"].append(cleaned)
        state["history"].append(
            {
                "developer_id": developer_id,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "action": "add",
                "term": cleaned,
            }
        )
        self._guilds[str(guild_id)] = state
        try:
            self._save()
        except OSError:
            self._guilds[str(guild_id)] = before_state
            raise
        return cleaned

    def remove(
        self,
        guild_id: int,
        term: str,
        developer_id: int,
        base_terms: Iterable[str],
    ) -> str:
        ProfanityTermStore._validate_developer_id(developer_id)
        self._validate_guild_id(guild_id)
        cleaned = ProfanityTermStore._clean_term(term)
        key = ProfanityTermStore._key(cleaned)
        base_terms = tuple(base_terms)
        existing = next(
            (
                item
                for item in self.list_terms(guild_id, base_terms)
                if ProfanityTermStore._key(item) == key
            ),
            None,
        )
        if existing is None:
            raise ProfanityTermError("هذه الكلمة أو العبارة غير موجودة في القائمة.")

        state = self._guilds.get(str(guild_id), self._empty_state())
        before_state = {
            "added": state["added"].copy(),
            "removed": state["removed"].copy(),
            "history": [entry.copy() for entry in state["history"]],
        }
        base_term = next(
            (
                item
                for item in base_terms
                if ProfanityTermStore._key(item) == key
            ),
            None,
        )
        if base_term is not None:
            state["added"] = [
                item
                for item in state["added"]
                if ProfanityTermStore._key(item) != key
            ]
            state["removed"].append(base_term)
        else:
            state["added"] = [
                item
                for item in state["added"]
                if ProfanityTermStore._key(item) != key
            ]
        state["history"].append(
            {
                "developer_id": developer_id,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "action": "remove",
                "term": existing,
            }
        )
        self._guilds[str(guild_id)] = state
        try:
            self._save()
        except OSError:
            self._guilds[str(guild_id)] = before_state
            raise
        return existing

    def _load(self) -> None:
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return
        if (
            not isinstance(payload, dict)
            or set(payload) != {"guilds"}
            or not isinstance(payload["guilds"], dict)
        ):
            raise ValueError(f"Invalid server filtered-term data in {self.path}.")

        guilds: dict[str, dict[str, list]] = {}
        for guild_key, state in payload["guilds"].items():
            if (
                not isinstance(guild_key, str)
                or not guild_key.isdecimal()
                or str(int(guild_key)) != guild_key
                or int(guild_key) <= 0
                or not isinstance(state, dict)
                or set(state) != {"added", "removed", "history"}
                or not isinstance(state["added"], list)
                or not isinstance(state["removed"], list)
                or not isinstance(state["history"], list)
            ):
                raise ValueError(
                    f"Invalid server filtered-term data in {self.path}."
                )
            added = [
                ProfanityTermStore._clean_term(term) for term in state["added"]
            ]
            removed = [
                ProfanityTermStore._clean_term(term) for term in state["removed"]
            ]
            added_keys = [ProfanityTermStore._key(term) for term in added]
            removed_keys = [ProfanityTermStore._key(term) for term in removed]
            if (
                len(set(added_keys)) != len(added_keys)
                or len(set(removed_keys)) != len(removed_keys)
                or set(added_keys) & set(removed_keys)
                or len(added) > MAX_CONFIGURED_TERMS
            ):
                raise ValueError(
                    f"Invalid or duplicate server filtered terms in {self.path}."
                )

            history = state["history"]
            for entry in history:
                action = entry.get("action") if isinstance(entry, dict) else None
                expected_entry_keys = (
                    {"developer_id", "timestamp", "action", "term"}
                    if isinstance(action, str) and action in {"add", "remove"}
                    else {
                        "developer_id",
                        "timestamp",
                        "action",
                        "added",
                        "removed",
                        "backup",
                    }
                    if action == "reset"
                    else set()
                )
                if (
                    not isinstance(entry, dict)
                    or set(entry) != expected_entry_keys
                    or isinstance(entry["developer_id"], bool)
                    or not isinstance(entry["developer_id"], int)
                    or entry["developer_id"] <= 0
                    or not isinstance(entry["action"], str)
                    or entry["action"] not in {"add", "remove", "reset"}
                ):
                    raise ValueError(
                        f"Invalid server filtered-term history in {self.path}."
                    )
                try:
                    timestamp = datetime.fromisoformat(entry["timestamp"])
                    if entry["action"] == "reset":
                        if (
                            not isinstance(entry["added"], list)
                            or not isinstance(entry["removed"], list)
                            or not isinstance(entry["backup"], str)
                            or not entry["backup"]
                            or Path(entry["backup"]).name != entry["backup"]
                        ):
                            raise ValueError("Invalid reset history entry.")
                        for term in (*entry["added"], *entry["removed"]):
                            ProfanityTermStore._clean_term(term)
                    else:
                        ProfanityTermStore._clean_term(entry["term"])
                except (TypeError, ValueError, ProfanityTermError) as error:
                    raise ValueError(
                        f"Invalid server filtered-term history in {self.path}."
                    ) from error
                if timestamp.tzinfo is None:
                    raise ValueError(
                        f"Invalid server filtered-term history in {self.path}."
                    )
            guilds[guild_key] = {
                "added": added,
                "removed": removed,
                "history": deepcopy(history),
            }
        self._guilds = guilds

    def _save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(
                "w",
                encoding="utf-8",
                dir=self.path.parent,
                prefix=f".{self.path.name}.",
                suffix=".tmp",
                delete=False,
            ) as output:
                temp_path = Path(output.name)
                json.dump(
                    {"guilds": self._guilds},
                    output,
                    ensure_ascii=False,
                    indent=2,
                )
                output.flush()
                os.fsync(output.fileno())
            os.replace(temp_path, self.path)
        finally:
            if temp_path is not None:
                temp_path.unlink(missing_ok=True)


def contains_bad_word(
    text: str | None,
    terms: Iterable[str] = BAD_WORDS,
) -> str | None:
    """Return the matched configured term, using whole words and phrases."""
    if not text:
        return None

    words = _normalize(text).split()
    if not words:
        return None

    for configured_term in terms:
        term_words = _normalize(configured_term).split()
        width = len(term_words)
        for index in range(len(words) - width + 1):
            candidate = words[index : index + width]
            if candidate == term_words:
                return configured_term

            # Match Arabic definite-article forms (for example, "الغبي")
            # without matching the configured term inside unrelated words.
            if width == 1 and candidate[0].startswith("ال"):
                if candidate[0][2:] == term_words[0]:
                    return configured_term
    return None


class GuildFilterResetView(discord.ui.View):
    """One-shot developer confirmation for resetting one guild's overrides."""

    def __init__(
        self,
        store: GuildProfanityTermStore,
        guild_id: int,
        developer_id: int,
        expected_overrides: dict[str, list[str]] | None = None,
        *,
        timeout: float = 60,
    ):
        super().__init__(timeout=timeout)
        self.store = store
        self.guild_id = guild_id
        self.developer_id = developer_id
        self.expected_overrides = (
            deepcopy(expected_overrides) if expected_overrides is not None else None
        )
        self.finished = False
        self.message = None

    async def _authorize(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.developer_id:
            await interaction.response.send_message(
                "هذا التأكيد متاح لمطور البوت الذي بدأ الأمر فقط.",
                ephemeral=True,
            )
            return False
        if getattr(interaction, "guild_id", None) != self.guild_id:
            await interaction.response.send_message(
                "يجب تأكيد إعادة الضبط من السيرفر نفسه.",
                ephemeral=True,
            )
            return False
        return True

    def _finish(self) -> None:
        self.finished = True
        for child in self.children:
            child.disabled = True
        self.stop()

    @discord.ui.button(label="تأكيد إعادة الضبط", style=discord.ButtonStyle.danger)
    async def confirm(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        if self.finished:
            await interaction.response.send_message(
                "انتهت صلاحية هذا التأكيد.",
                ephemeral=True,
            )
            return
        if not await self._authorize(interaction):
            return
        self._finish()
        await interaction.response.defer()
        try:
            backup_path = self.store.prepare_reset_backup(
                self.guild_id,
                expected_overrides=self.expected_overrides,
            )
        except ProfanityTermError as error:
            content = str(error)
        except (OSError, ValueError):
            logger.exception(
                "Could not back up/reset profanity overrides for guild %s.",
                self.guild_id,
            )
            content = "تعذر حفظ النسخة الاحتياطية أو الإعدادات؛ لم يتغير المرشح."
        else:
            if backup_path is None:
                content = "لم تعد هناك إضافات أو استثناءات محفوظة؛ لم يتغير شيء."
            else:
                backup_file = None
                try:
                    backup_file = discord.File(
                        str(backup_path), filename=backup_path.name
                    )
                    await interaction.user.send(
                        content=(
                            "نسخة استعادة خاصة لتعديلات مرشح اللغة "
                            f"للسيرفر ID {self.guild_id}. احتفظ بهذه الرسالة "
                            "أو نزّل الملف لاستعادته بعد استبدال الخادم."
                        ),
                        file=backup_file,
                        allowed_mentions=discord.AllowedMentions.none(),
                    )
                except (discord.HTTPException, OSError):
                    logger.exception(
                        "Could not deliver private profanity-filter recovery "
                        "copy for guild %s.",
                        self.guild_id,
                    )
                    content = (
                        "تعذر إرسال نسخة الاستعادة إلى رسائلك الخاصة؛ "
                        "لم يتغير المرشح."
                    )
                else:
                    try:
                        result = self.store.reset_guild(
                            self.guild_id,
                            self.developer_id,
                            expected_overrides=self.expected_overrides,
                            backup_path=backup_path,
                        )
                    except ProfanityTermError as error:
                        content = (
                            f"{error} أُرسلت نسخة الاستعادة إلى رسائلك الخاصة."
                        )
                    except (OSError, ValueError):
                        logger.exception(
                            "Recovery copy delivered but filter reset could not "
                            "be saved for guild %s.",
                            self.guild_id,
                        )
                        content = (
                            "أُرسلت نسخة الاستعادة إلى رسائلك الخاصة، لكن تعذر "
                            "حفظ الإعدادات؛ لم يتغير المرشح."
                        )
                    else:
                        if result is None:
                            content = (
                                "لم تعد هناك إضافات أو استثناءات محفوظة؛ "
                                "لم يتغير شيء."
                            )
                        else:
                            content = (
                                "أُعيد مرشح هذا السيرفر إلى القائمة العامة. "
                                "أُرسلت نسخة الاستعادة الخاصة إلى رسائلك، "
                                f"({len(result['added'])} إضافة، "
                                f"{len(result['removed'])} استثناء)."
                            )
                finally:
                    if backup_file is not None:
                        backup_file.close()
        await interaction.edit_original_response(
            content=content,
            view=None,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @discord.ui.button(label="إلغاء", style=discord.ButtonStyle.secondary)
    async def cancel(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ) -> None:
        if self.finished:
            await interaction.response.send_message(
                "انتهت صلاحية هذا التأكيد.",
                ephemeral=True,
            )
            return
        if not await self._authorize(interaction):
            return
        self._finish()
        await interaction.response.edit_message(
            content="أُلغيت إعادة الضبط؛ لم تتغير الإعدادات.",
            view=None,
        )

    async def on_timeout(self) -> None:
        if self.finished:
            return
        self._finish()
        if self.message is not None:
            try:
                await self.message.edit(
                    content="انتهت مهلة التأكيد؛ لم تتغير الإعدادات.",
                    view=self,
                )
            except discord.HTTPException:
                logger.warning("Could not disable expired filter reset confirmation.")


def setup_profanity_commands(
    bot,
    store: ProfanityTermStore,
    developer_id: int,
    guild_store: GuildProfanityTermStore | None = None,
):
    """Register private, developer-only commands for managing filtered terms."""
    existing = getattr(bot, "_profanity_filter_command_group", None)
    if existing is not None:
        return existing

    group = app_commands.Group(
        name="filter",
        description="إدارة الكلمات والعبارات التي يحذفها مرشح اللغة",
    )

    async def reject_non_developer(interaction: discord.Interaction) -> bool:
        if interaction.user.id == developer_id:
            return False
        await interaction.response.send_message(
            "هذا الأمر خاص بمطور البوت فقط.",
            ephemeral=True,
        )
        return True

    async def send_private_chunks(
        interaction,
        text: str,
        empty_message: str = "لا توجد كلمات أو عبارات في القائمة.",
        view: discord.ui.View | None = None,
    ) -> None:
        chunks = []
        current = ""
        for line in text.splitlines():
            if current and len(current) + len(line) + 1 > 1750:
                chunks.append(current)
                current = ""
            current = f"{current}\n{line}" if current else line
        if current:
            chunks.append(current)
        if not chunks:
            chunks = [empty_message]
        await interaction.response.send_message(
            chunks[0],
            ephemeral=True,
            view=view,
            allowed_mentions=discord.AllowedMentions.none(),
        )
        for chunk in chunks[1:]:
            await interaction.followup.send(
                chunk,
                ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none(),
            )

    @group.command(name="add", description="إضافة كلمة أو عبارة إلى المرشح")
    @app_commands.describe(term="كلمة أو عبارة من خمس كلمات كحد أقصى")
    @app_commands.guild_only()
    async def add_term(interaction: discord.Interaction, term: str) -> None:
        if await reject_non_developer(interaction):
            return
        try:
            added = store.add(term, interaction.user.id)
        except ProfanityTermError as error:
            response = str(error)
        except OSError:
            logger.exception("Could not save the filtered-term list.")
            response = "تعذر حفظ القائمة؛ لم يتغير إعداد المرشح."
        else:
            response = f"أُضيفت «{discord.utils.escape_markdown(added)}» إلى قائمة المرشح."
        await interaction.response.send_message(
            response,
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @group.command(name="remove", description="إزالة كلمة أو عبارة من المرشح")
    @app_commands.describe(term="الكلمة أو العبارة المطلوب إزالتها")
    @app_commands.guild_only()
    async def remove_term(interaction: discord.Interaction, term: str) -> None:
        if await reject_non_developer(interaction):
            return
        try:
            removed = store.remove(term, interaction.user.id)
        except ProfanityTermError as error:
            response = str(error)
        except OSError:
            logger.exception("Could not save the filtered-term list.")
            response = "تعذر حفظ القائمة؛ لم يتغير إعداد المرشح."
        else:
            response = f"أُزيلت «{discord.utils.escape_markdown(removed)}» من قائمة المرشح."
        await interaction.response.send_message(
            response,
            ephemeral=True,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @group.command(name="list", description="عرض الكلمات والعبارات في المرشح")
    @app_commands.guild_only()
    async def list_terms(interaction: discord.Interaction) -> None:
        if await reject_non_developer(interaction):
            return
        terms = store.list_terms()
        lines = [f"• {discord.utils.escape_markdown(term)}" for term in terms]
        await send_private_chunks(
            interaction,
            f"قائمة الكلمات والعبارات المحظورة ({len(terms)}):\n"
            + ("\n".join(lines) if lines else "لا توجد كلمات أو عبارات في القائمة."),
        )

    @group.command(name="history", description="عرض سجل تغييرات قائمة المرشح")
    @app_commands.guild_only()
    async def list_changes(interaction: discord.Interaction) -> None:
        if await reject_non_developer(interaction):
            return
        history = store.list_history()
        action_labels = {"add": "إضافة", "remove": "إزالة"}
        lines = [
            f"• {entry['timestamp']} — {action_labels[entry['action']]} "
            f"«{discord.utils.escape_markdown(str(entry['term']))}» "
            f"(المطور: {entry['developer_id']})"
            for entry in history
        ]
        await send_private_chunks(
            interaction,
            f"سجل تغييرات قائمة المرشح ({len(history)}):\n" + "\n".join(lines),
            empty_message="لا توجد تغييرات مسجلة على القائمة.",
        )

    if guild_store is not None:
        async def get_server_id(interaction) -> int | None:
            if await reject_non_developer(interaction):
                return None
            guild_id = getattr(interaction, "guild_id", None)
            if (
                isinstance(guild_id, bool)
                or not isinstance(guild_id, int)
                or guild_id <= 0
            ):
                await interaction.response.send_message(
                    "هذا الأمر متاح داخل السيرفر فقط.",
                    ephemeral=True,
                )
                return None
            return guild_id

        @group.command(name="server-add", description="إضافة كلمة لهذا السيرفر فقط")
        @app_commands.describe(term="كلمة أو عبارة من خمس كلمات كحد أقصى")
        @app_commands.guild_only()
        async def add_server_term(interaction: discord.Interaction, term: str) -> None:
            guild_id = await get_server_id(interaction)
            if guild_id is None:
                return
            try:
                added = guild_store.add(
                    guild_id,
                    term,
                    interaction.user.id,
                    store.list_terms(),
                )
            except ProfanityTermError as error:
                response = str(error)
            except OSError:
                logger.exception(
                    "Could not save filtered terms for guild %s.", guild_id
                )
                response = "تعذر حفظ القائمة؛ لم يتغير إعداد المرشح."
            else:
                response = (
                    f"أُضيفت «{discord.utils.escape_markdown(added)}» "
                    "إلى قائمة هذا السيرفر فقط."
                )
            await interaction.response.send_message(
                response,
                ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none(),
            )

        @group.command(
            name="server-remove", description="إزالة كلمة من قائمة هذا السيرفر فقط"
        )
        @app_commands.describe(term="الكلمة أو العبارة المطلوب إزالتها")
        @app_commands.guild_only()
        async def remove_server_term(
            interaction: discord.Interaction, term: str
        ) -> None:
            guild_id = await get_server_id(interaction)
            if guild_id is None:
                return
            try:
                removed = guild_store.remove(
                    guild_id,
                    term,
                    interaction.user.id,
                    store.list_terms(),
                )
            except ProfanityTermError as error:
                response = str(error)
            except OSError:
                logger.exception(
                    "Could not save filtered terms for guild %s.", guild_id
                )
                response = "تعذر حفظ القائمة؛ لم يتغير إعداد المرشح."
            else:
                response = (
                    f"أُزيلت «{discord.utils.escape_markdown(removed)}» "
                    "من قائمة هذا السيرفر فقط."
                )
            await interaction.response.send_message(
                response,
                ephemeral=True,
                allowed_mentions=discord.AllowedMentions.none(),
            )

        @group.command(name="server-list", description="عرض قائمة المرشح لهذا السيرفر")
        @app_commands.guild_only()
        async def list_server_terms(interaction: discord.Interaction) -> None:
            guild_id = await get_server_id(interaction)
            if guild_id is None:
                return
            terms = guild_store.list_terms(guild_id, store.list_terms())
            lines = [f"• {discord.utils.escape_markdown(term)}" for term in terms]
            await send_private_chunks(
                interaction,
                f"قائمة هذا السيرفر ({len(terms)}):\n" + "\n".join(lines),
            )

        @group.command(
            name="server-overrides",
            description="عرض الإضافات والاستثناءات الخاصة بهذا السيرفر",
        )
        @app_commands.guild_only()
        async def list_server_overrides(interaction: discord.Interaction) -> None:
            guild_id = await get_server_id(interaction)
            if guild_id is None:
                return
            statuses = guild_store.list_override_status(
                guild_id, store.list_terms()
            )

            def format_terms(terms: list[str], empty_message: str) -> str:
                return "\n".join(
                    f"• {discord.utils.escape_markdown(term)}" for term in terms
                ) or empty_message

            await send_private_chunks(
                interaction,
                "حالة تعديلات مرشح هذا السيرفر — عرض خاص، دون تغيير أي إعداد.\n"
                f"إضافات محلية فعالة الآن ({len(statuses['added_effective'])}):\n"
                + format_terms(
                    statuses["added_effective"], "لا توجد إضافات فعالة."
                )
                + f"\nإضافات محفوظة موجودة أيضاً في القائمة العامة "
                f"({len(statuses['added_retained'])}) — لا تغيّر القائمة الفعالة:\n"
                + format_terms(
                    statuses["added_retained"], "لا توجد إضافات متداخلة."
                )
                + f"\nاستثناءات فعالة من القائمة العامة "
                f"({len(statuses['removed_effective'])}):\n"
                + format_terms(
                    statuses["removed_effective"], "لا توجد استثناءات فعالة."
                )
                + f"\nاستثناءات محفوظة بلا تطابق حالي في القائمة العامة "
                f"({len(statuses['removed_retained'])}) — لا تغيّر القائمة الفعالة:\n"
                + format_terms(
                    statuses["removed_retained"], "لا توجد استثناءات محتفظ بها."
                ),
            )

        async def available_server_choices(
            interaction: discord.Interaction, current: str
        ) -> list[app_commands.Choice[int]]:
            if interaction.user.id != developer_id:
                return []
            query = current.strip().casefold()
            guilds = sorted(
                bot.guilds,
                key=lambda guild: (guild.name.casefold(), guild.id),
            )
            choices = []
            for guild in guilds:
                if query and (
                    query not in guild.name.casefold()
                    and query not in str(guild.id)
                ):
                    continue
                choices.append(
                    app_commands.Choice(
                        name=f"{guild.name} ({guild.id})"[:100],
                        value=guild.id,
                    )
                )
            return choices[:25]

        @group.command(
            name="server-compare",
            description="مقارنة تعديلات المرشح بين سيرفرين",
        )
        @app_commands.describe(
            server_a_id="السيرفر الأول",
            server_b_id="السيرفر الثاني",
        )
        @app_commands.autocomplete(
            server_a_id=available_server_choices,
            server_b_id=available_server_choices,
        )
        async def compare_server_overrides(
            interaction: discord.Interaction,
            server_a_id: int,
            server_b_id: int,
        ) -> None:
            if await reject_non_developer(interaction):
                return

            server_ids = (server_a_id, server_b_id)
            if any(
                isinstance(guild_id, bool)
                or not isinstance(guild_id, int)
                or guild_id <= 0
                for guild_id in server_ids
            ):
                await interaction.response.send_message(
                    "تعذر التحقق من هوية السيرفر.",
                    ephemeral=True,
                )
                return
            if server_a_id == server_b_id:
                await interaction.response.send_message(
                    "اختر سيرفرين مختلفين للمقارنة.",
                    ephemeral=True,
                )
                return

            selected_guilds = [
                (guild_id, bot.get_guild(guild_id)) for guild_id in server_ids
            ]
            unavailable = [
                str(guild_id)
                for guild_id, guild in selected_guilds
                if guild is None
            ]
            if unavailable:
                await interaction.response.send_message(
                    "تعذر العثور على السيرفر المحدد ضمن السيرفرات المتاحة للبوت "
                    f"(ID: {', '.join(unavailable)}).",
                    ephemeral=True,
                )
                return

            base_terms = store.list_terms()
            sections = [
                "مقارنة تعديلات مرشح اللغة — عرض خاص، دون تغيير أي إعداد.",
            ]
            for guild_id, guild in selected_guilds:
                overrides = guild_store.list_overrides(guild_id, base_terms)
                additions = overrides["added"]
                exclusions = overrides["removed"]
                effective_count = len(guild_store.list_terms(guild_id, base_terms))
                addition_lines = [
                    f"• {discord.utils.escape_markdown(term)}"
                    for term in additions
                ]
                exclusion_lines = [
                    f"• {discord.utils.escape_markdown(term)}"
                    for term in exclusions
                ]
                sections.extend(
                    [
                        "",
                        f"**{discord.utils.escape_markdown(guild.name)} "
                        f"(ID: {guild_id})**",
                        f"إجمالي الكلمات والعبارات الفعالة: {effective_count}",
                        f"إضافات محلية ({len(additions)}):",
                        "\n".join(addition_lines) or "لا توجد إضافات محلية.",
                        f"استثناءات من القائمة العامة ({len(exclusions)}):",
                        "\n".join(exclusion_lines) or "لا توجد استثناءات.",
                    ]
                )
            await send_private_chunks(interaction, "\n".join(sections))

        @group.command(
            name="server-reset",
            description="إعادة مرشح هذا السيرفر إلى القائمة العامة بعد التأكيد",
        )
        @app_commands.guild_only()
        async def reset_server_terms(interaction: discord.Interaction) -> None:
            guild_id = await get_server_id(interaction)
            if guild_id is None:
                return
            overrides = guild_store.list_saved_overrides(guild_id)
            additions = overrides["added"]
            exclusions = overrides["removed"]
            if not additions and not exclusions:
                await interaction.response.send_message(
                    "لا توجد إضافات أو استثناءات محفوظة لهذا السيرفر؛ لم يتغير شيء.",
                    ephemeral=True,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
                return

            def format_terms(terms: list[str]) -> str:
                return "\n".join(
                    f"• {discord.utils.escape_markdown(term)}" for term in terms
                ) or "لا توجد."

            preview = (
                f"**معاينة إعادة ضبط مرشح هذا السيرفر فقط**\n"
                f"ستُحذف الإضافات المحلية ({len(additions)}):\n"
                f"{format_terms(additions)}\n"
                f"وستُلغى الاستثناءات من القائمة العامة ({len(exclusions)}):\n"
                f"{format_terms(exclusions)}\n"
                "لن تتغير القائمة العامة أو إعدادات السيرفرات الأخرى. "
                "سيُحفظ الوضع الحالي في نسخة احتياطية قبل الحفظ."
            )
            view = GuildFilterResetView(
                guild_store,
                guild_id,
                interaction.user.id,
                expected_overrides=overrides,
            )
            await send_private_chunks(interaction, preview, view=view)
            view.message = await interaction.original_response()

        @group.command(
            name="server-history", description="عرض سجل تغييرات قائمة هذا السيرفر"
        )
        @app_commands.guild_only()
        async def list_server_changes(interaction: discord.Interaction) -> None:
            guild_id = await get_server_id(interaction)
            if guild_id is None:
                return
            history = guild_store.list_history(guild_id)
            action_labels = {"add": "إضافة", "remove": "إزالة"}
            lines = [
                (
                    f"• {entry['timestamp']} — إعادة ضبط "
                    f"(إضافات: {len(entry['added'])}، استثناءات: "
                    f"{len(entry['removed'])}، النسخة الاحتياطية: "
                    f"{discord.utils.escape_markdown(str(entry['backup']))}) "
                    f"(المطور: {entry['developer_id']})"
                    if entry["action"] == "reset"
                    else (
                        f"• {entry['timestamp']} — {action_labels[entry['action']]} "
                        f"«{discord.utils.escape_markdown(str(entry['term']))}» "
                        f"(المطور: {entry['developer_id']})"
                    )
                )
                for entry in history
            ]
            await send_private_chunks(
                interaction,
                f"سجل تغييرات هذا السيرفر ({len(history)}):\n" + "\n".join(lines),
                empty_message="لا توجد تغييرات مسجلة لهذا السيرفر.",
            )

    bot.tree.add_command(group)
    bot._profanity_filter_command_group = group
    return group


async def handle_profanity(
    message: discord.Message,
    developer_id: int,
    terms: Iterable[str] = BAD_WORDS,
) -> bool:
    """Delete and warn for a prohibited term; return whether moderation handled it."""
    if message.guild is None or message.author.bot:
        return False

    permissions = getattr(message.author, "guild_permissions", None)
    if (
        message.author.id == developer_id
        or getattr(permissions, "administrator", False)
    ):
        return False

    if contains_bad_word(message.content, terms) is None:
        return False

    try:
        await message.delete()
    except discord.NotFound:
        # The message is already gone; still warn the member about the rule.
        pass
    except discord.Forbidden:
        logger.warning(
            "Could not delete a prohibited-language message in guild %s, channel %s; "
            "the bot needs Manage Messages.",
            message.guild.id,
            message.channel.id,
        )
        return True
    except discord.HTTPException:
        logger.exception(
            "Discord rejected deletion of a prohibited-language message in guild %s, channel %s.",
            message.guild.id,
            message.channel.id,
        )
        return True

    try:
        await message.channel.send(
            f"🚫 {message.author.mention} يرجى استخدام لغة محترمة. "
            "حُذفت رسالتك؛ سيختفي هذا التنبيه بعد 5 ثوانٍ.",
            delete_after=WARNING_SECONDS,
            allowed_mentions=discord.AllowedMentions.none(),
        )
    except discord.Forbidden:
        logger.warning(
            "Could not send a prohibited-language warning in guild %s, channel %s.",
            message.guild.id,
            message.channel.id,
        )
    except discord.HTTPException:
        logger.exception(
            "Discord rejected a prohibited-language warning in guild %s, channel %s.",
            message.guild.id,
            message.channel.id,
        )

    logger.info(
        "Removed a prohibited-language message from member %s in guild %s, channel %s.",
        message.author.id,
        message.guild.id,
        message.channel.id,
    )
    return True