"""Persistent, guild-scoped Discord XP and levels.

The level data deliberately lives under one top-level ``levels`` key in the
existing game store.  It is therefore committed atomically with other game
state, while never sharing the economy's ``users`` records.
"""

from __future__ import annotations

import asyncio
import logging
import random
import time
from collections.abc import Mapping
from copy import deepcopy
from typing import Any

import discord
from discord import app_commands
from discord.ext import commands


logger = logging.getLogger(__name__)

XP_PER_MESSAGE = (15, 25)
XP_PER_VOICE_MINUTE = 10
MESSAGE_COOLDOWN = 60.0
LEVEL_UP_MESSAGE_LIMIT = 500
LEVEL_ANNOUNCEMENT_MODES = frozenset({"same", "channel", "dm", "off"})
DEFAULT_LEVEL_ANNOUNCEMENT_SETTINGS = {
    "mode": "same",
    "channel_id": None,
    "mention_user": True,
    "custom_message": None,
}
LEVEL_TITLES = (
    (100, "إمبراطور"),
    (75, "نجم"),
    (50, "أسطورة"),
    (30, "خبير"),
    (20, "محترف"),
    (10, "نشيط"),
    (5, "مبتدئ"),
)


def title_for_level(level: int) -> str:
    """Return the highest milestone title reached by a member."""
    for threshold, title in LEVEL_TITLES:
        if level >= threshold:
            return title
    return "عضو جديد"


def xp_for_level(level: int) -> int:
    """Return the total XP required to reach ``level``."""
    if level < 0:
        raise ValueError("level must be non-negative")
    return 5 * level * level + 50 * level + 100


def _level_for_xp(xp: int) -> int:
    level = 0
    while xp >= xp_for_level(level + 1):
        level += 1
    return level


def _timestamp(value: float | int | None) -> float:
    return time.time() if value is None else float(value)


class LevelSystem:
    """Award XP and query profiles using a GameStore-compatible object."""

    def __init__(
        self,
        store: Any,
        rng: Any = random,
    ) -> None:
        self.store = store
        self.rng = rng

    @staticmethod
    def _profile_template(guild_id: int, user_id: int) -> dict[str, Any]:
        return {
            "guild_id": int(guild_id),
            "user_id": int(user_id),
            "xp": 0,
            "level": 0,
            "total_messages": 0,
            "voice_minutes": 0,
            "last_message_at": None,
        }

    def _guild_profiles(self, data: dict[str, Any], guild_id: int) -> dict[str, Any]:
        levels = data.setdefault("levels", {})
        return levels.setdefault(str(guild_id), {})

    @staticmethod
    def _guild_role_rewards(
        data: dict[str, Any], guild_id: int
    ) -> dict[str, Any]:
        rewards = data.setdefault("level_role_rewards", {})
        return rewards.setdefault(str(guild_id), {})

    def _get_or_create(
        self, data: dict[str, Any], guild_id: int, user_id: int
    ) -> dict[str, Any]:
        profiles = self._guild_profiles(data, guild_id)
        key = str(user_id)
        profile = profiles.setdefault(key, self._profile_template(guild_id, user_id))
        # Make old/partially-created records forward compatible.
        for field, default in self._profile_template(guild_id, user_id).items():
            profile.setdefault(field, default)
        return profile

    def profile(self, guild_id: int, user_id: int) -> dict[str, Any]:
        """Return a detached profile; querying does not create or persist it."""
        snapshot = self.store.snapshot()
        profile = (
            snapshot.get("levels", {})
            .get(str(guild_id), {})
            .get(str(user_id))
        )
        return deepcopy(
            profile
            if isinstance(profile, Mapping)
            else self._profile_template(guild_id, user_id)
        )

    def award_message(
        self, guild_id: int, user_id: int, now: float | int | None = None
    ) -> tuple[bool, int, int]:
        """Award one random message amount unless the persisted cooldown applies."""
        old_level, new_level, amount = self.award_message_transition(
            guild_id, user_id, now
        )
        return new_level > old_level, new_level, amount

    def award_message_transition(
        self, guild_id: int, user_id: int, now: float | int | None = None
    ) -> tuple[int, int, int]:
        """Award message XP and return the exact old/new levels and XP amount."""
        current = _timestamp(now)
        with self.store.transaction() as data:
            profile = self._get_or_create(data, guild_id, user_id)
            previous = profile["last_message_at"]
            if previous is not None and current - float(previous) < MESSAGE_COOLDOWN:
                level = int(profile["level"])
                return level, level, 0
            amount = int(self.rng.randint(*XP_PER_MESSAGE))
            old_level = int(profile["level"])
            profile["xp"] = int(profile["xp"]) + amount
            profile["level"] = _level_for_xp(int(profile["xp"]))
            profile["total_messages"] = int(profile["total_messages"]) + 1
            profile["last_message_at"] = current
            return old_level, int(profile["level"]), amount

    def award_voice_minutes(
        self, guild_id: int, user_id: int, minutes: int = 1
    ) -> tuple[bool, int, int]:
        """Award ten XP for each eligible whole voice minute supplied by caller."""
        old_level, new_level, amount = self.award_voice_minutes_transition(
            guild_id, user_id, minutes
        )
        return new_level > old_level, new_level, amount

    def award_voice_minutes_transition(
        self, guild_id: int, user_id: int, minutes: int = 1
    ) -> tuple[int, int, int]:
        """Award voice XP and return the exact old/new levels and XP amount."""
        minutes = int(minutes)
        if minutes <= 0:
            level = self.profile(guild_id, user_id)["level"]
            return int(level), int(level), 0
        amount = XP_PER_VOICE_MINUTE * minutes
        with self.store.transaction() as data:
            profile = self._get_or_create(data, guild_id, user_id)
            old_level = int(profile["level"])
            profile["xp"] = int(profile["xp"]) + amount
            profile["level"] = _level_for_xp(int(profile["xp"]))
            profile["voice_minutes"] = int(profile["voice_minutes"]) + minutes
            return old_level, int(profile["level"]), amount

    def set_role_reward(self, guild_id: int, level: int, role_id: int) -> None:
        """Persist one guild's role reward for a positive level milestone."""
        level = int(level)
        role_id = int(role_id)
        if level <= 0:
            raise ValueError("level must be positive")
        if role_id <= 0:
            raise ValueError("role_id must be positive")
        with self.store.transaction() as data:
            self._guild_role_rewards(data, guild_id)[str(level)] = role_id

    def remove_role_reward(self, guild_id: int, level: int) -> bool:
        """Remove one guild's role reward; return whether it existed."""
        level = int(level)
        with self.store.transaction() as data:
            rewards = data.setdefault("level_role_rewards", {}).get(str(guild_id), {})
            return rewards.pop(str(level), None) is not None

    def role_rewards(self, guild_id: int) -> dict[int, int]:
        """Return a detached mapping of milestone levels to Discord role IDs."""
        rewards = self.store.snapshot().get("level_role_rewards", {}).get(
            str(guild_id), {}
        )
        return {
            int(level): int(role_id)
            for level, role_id in rewards.items()
        }

    def announcement_settings(self, guild_id: int) -> dict[str, Any]:
        """Return detached per-server announcement settings with safe defaults."""
        snapshot = self.store.snapshot()
        raw = (
            snapshot.get("level_announcement_settings", {})
            .get(str(guild_id), {})
        )
        settings = deepcopy(DEFAULT_LEVEL_ANNOUNCEMENT_SETTINGS)
        if isinstance(raw, Mapping):
            settings.update(
                {
                    key: deepcopy(raw[key])
                    for key in DEFAULT_LEVEL_ANNOUNCEMENT_SETTINGS
                    if key in raw
                }
            )
        return settings

    def set_announcement_settings(
        self, guild_id: int, updates: Mapping[str, Any]
    ) -> dict[str, Any]:
        """Persist validated per-server announcement settings atomically."""
        unknown = set(updates) - set(DEFAULT_LEVEL_ANNOUNCEMENT_SETTINGS)
        if unknown:
            raise ValueError(f"unknown announcement settings: {sorted(unknown)}")

        guild_key = str(int(guild_id))
        with self.store.transaction() as data:
            settings_by_guild = data.setdefault("level_announcement_settings", {})
            stored = settings_by_guild.get(guild_key, {})
            settings = deepcopy(DEFAULT_LEVEL_ANNOUNCEMENT_SETTINGS)
            if isinstance(stored, Mapping):
                settings.update(stored)
            settings.update(deepcopy(dict(updates)))

            if (
                not isinstance(settings["mode"], str)
                or settings["mode"] not in LEVEL_ANNOUNCEMENT_MODES
            ):
                raise ValueError("invalid announcement mode")
            if settings["mode"] == "channel":
                channel_id = settings["channel_id"]
                if (
                    isinstance(channel_id, bool)
                    or not isinstance(channel_id, int)
                    or channel_id <= 0
                ):
                    raise ValueError("channel mode requires a positive channel ID")
            elif settings["channel_id"] is not None:
                raise ValueError("only channel mode may have a channel ID")
            if not isinstance(settings["mention_user"], bool):
                raise ValueError("mention_user must be boolean")
            custom_message = settings["custom_message"]
            if custom_message is not None and (
                not isinstance(custom_message, str)
                or not custom_message.strip()
                or len(custom_message) > LEVEL_UP_MESSAGE_LIMIT
            ):
                raise ValueError(
                    f"custom_message must be non-empty and at most "
                    f"{LEVEL_UP_MESSAGE_LIMIT} characters"
                )

            settings_by_guild[guild_key] = settings
            return deepcopy(settings)

    def reset_announcement_settings(self, guild_id: int) -> bool:
        """Remove one server's announcement overrides and return whether present."""
        with self.store.transaction() as data:
            settings_by_guild = data.setdefault("level_announcement_settings", {})
            return settings_by_guild.pop(str(int(guild_id)), None) is not None

    def role_rewards_crossed(
        self, guild_id: int, old_level: int, new_level: int
    ) -> list[tuple[int, int]]:
        """Return configured (level, role ID) rewards crossed by this XP gain."""
        if new_level <= old_level:
            return []
        return [
            (level, role_id)
            for level, role_id in sorted(self.role_rewards(guild_id).items())
            if old_level < level <= new_level
        ]

    def leaderboard(self, guild_id: int, limit: int = 10) -> list[dict[str, Any]]:
        """Return the highest-XP profiles in a guild."""
        if limit <= 0:
            return []
        snapshot = self.store.snapshot()
        profiles = snapshot.get("levels", {}).get(str(guild_id), {})
        values = [deepcopy(p) for p in profiles.values() if isinstance(p, Mapping)]
        values.sort(key=lambda p: (-int(p.get("xp", 0)), int(p.get("user_id", 0))))
        return values[:limit]

    def rank(self, guild_id: int, user_id: int) -> tuple[int | None, int]:
        """Return ``(one_based_rank, guild_population)``."""
        entries = self.leaderboard(guild_id, limit=10**9)
        total = len(entries)
        for position, entry in enumerate(entries, 1):
            if int(entry.get("user_id", 0)) == int(user_id):
                return position, total
        return None, total

    def guild_stats(self, guild_id: int) -> dict[str, int]:
        """Return aggregate, non-identifying level statistics for one server."""
        profiles = (
            self.store.snapshot()
            .get("levels", {})
            .get(str(guild_id), {})
        )
        valid_profiles = [
            profile for profile in profiles.values() if isinstance(profile, Mapping)
        ]
        return {
            "members": sum(int(profile.get("xp", 0)) > 0 for profile in valid_profiles),
            "total_xp": sum(int(profile.get("xp", 0)) for profile in valid_profiles),
            "total_messages": sum(
                int(profile.get("total_messages", 0)) for profile in valid_profiles
            ),
            "voice_minutes": sum(
                int(profile.get("voice_minutes", 0)) for profile in valid_profiles
            ),
            "highest_level": max(
                (int(profile.get("level", 0)) for profile in valid_profiles),
                default=0,
            ),
        }


def _safe_name(member: discord.Member) -> str:
    return discord.utils.escape_markdown(
        getattr(member, "display_name", getattr(member, "name", str(member)))
    )[:100]


async def _leaderboard_member_label(guild: discord.Guild, user_id: int) -> str:
    member = guild.get_member(user_id)
    if member is None:
        try:
            member = await guild.fetch_member(user_id)
        except discord.NotFound:
            return f"👤 عضو غادر (`{user_id}`)"
        except discord.HTTPException:
            logger.exception(
                "Could not fetch leaderboard member %s in guild %s.",
                user_id,
                guild.id,
            )
            return f"<@{user_id}>"
    return member.mention


async def send_level_up_notice(
    system: LevelSystem,
    guild: discord.Guild,
    member: discord.Member,
    channel,
    level: int,
) -> None:
    """Send a level-up notice using the guild's saved destination and template."""
    settings = system.announcement_settings(guild.id)
    mode = settings["mode"]
    if mode == "off":
        return

    mention_user = settings["mention_user"]
    safe_name = _safe_name(member)
    user_label = member.mention if mention_user else safe_name
    custom_message = settings["custom_message"]
    if custom_message:
        description = custom_message
        replacements = {
            "{user}": user_label,
            "{level}": str(level),
            "{title}": title_for_level(level),
            "{guild}": discord.utils.escape_markdown(guild.name)[:100],
        }
        for placeholder, value in replacements.items():
            description = description.replace(placeholder, value)
    else:
        description = (
            f"وصل **{safe_name}** إلى المستوى **{level}**.\n"
            f"الرتبة: **{title_for_level(level)}**"
        )

    embed = discord.Embed(
        title="🎉 مستوى جديد!",
        description=description,
        color=0xFFD700,
    )
    avatar = getattr(member, "display_avatar", None) or getattr(member, "avatar", None)
    avatar_url = getattr(avatar, "url", None)
    if avatar_url:
        embed.set_thumbnail(url=avatar_url)

    allowed_mentions = discord.AllowedMentions(
        users=[member] if mention_user else False,
        roles=False,
        everyone=False,
        replied_user=False,
    )
    send_options = {
        "content": member.mention if mention_user else None,
        "embed": embed,
        "allowed_mentions": allowed_mentions,
    }

    if mode == "dm":
        try:
            await member.send(**send_options)
            return
        except discord.HTTPException:
            logger.info(
                "Could not DM level-up notice in guild %s; falling back to channel.",
                guild.id,
            )

    target_channel = channel
    if mode == "channel":
        configured = guild.get_channel(settings["channel_id"])
        if configured is not None:
            target_channel = configured
        else:
            logger.warning(
                "Configured level-up channel is unavailable in guild %s; "
                "falling back to the triggering channel.",
                guild.id,
            )

    if target_channel is None:
        logger.info("No channel is available for a level-up notice in guild %s.", guild.id)
        return
    try:
        await target_channel.send(**send_options)
    except discord.HTTPException:
        logger.warning(
            "Could not send level-up notice in guild %s.",
            guild.id,
            exc_info=True,
        )


def role_reward_block_reason(role: Any, bot_member: Any) -> str | None:
    """Explain why the bot cannot assign a configured role, if it cannot."""
    if role is None:
        return "the configured role no longer exists"
    if bot_member is None:
        return "the bot's server member is unavailable"
    if not getattr(getattr(bot_member, "guild_permissions", None), "manage_roles", False):
        return "the bot is missing Manage Roles permission"
    if getattr(role, "managed", False):
        return "the role is managed by an integration and cannot be assigned"
    is_default = getattr(role, "is_default", None)
    if callable(is_default) and is_default():
        return "the server's @everyone role cannot be assigned as a reward"
    top_role = getattr(bot_member, "top_role", None)
    if top_role is None or role >= top_role:
        return "the role is not below the bot's highest role"
    return None


class _LevelSettingsResetView(discord.ui.View):
    """Require the invoking administrator to confirm this guild-only reset."""

    def __init__(self, system: LevelSystem, guild_id: int, user_id: int) -> None:
        super().__init__(timeout=60)
        self.system = system
        self.guild_id = guild_id
        self.user_id = user_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.user_id:
            await interaction.response.send_message(
                "هذا التأكيد متاح لمن بدأ إعادة الضبط فقط.",
                ephemeral=True,
            )
            return False
        return True

    @discord.ui.button(
        label="تأكيد إعادة الضبط",
        style=discord.ButtonStyle.danger,
    )
    async def confirm_reset(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        try:
            self.system.reset_announcement_settings(self.guild_id)
        except Exception:
            logger.exception(
                "Could not reset level announcement settings for guild %s.",
                self.guild_id,
            )
            await interaction.response.edit_message(
                content="تعذر حفظ إعادة الضبط؛ بقيت الإعدادات كما هي.",
                view=None,
            )
        else:
            await interaction.response.edit_message(
                content="أُعيدت إعدادات إشعارات المستويات لهذا السيرفر إلى الافتراضي.",
                view=None,
            )
        self.stop()

    @discord.ui.button(label="إلغاء", style=discord.ButtonStyle.secondary)
    async def cancel_reset(
        self, interaction: discord.Interaction, button: discord.ui.Button
    ) -> None:
        await interaction.response.edit_message(
            content="أُلغيت إعادة الضبط؛ لم تتغير الإعدادات.",
            view=None,
        )
        self.stop()


def setup_commands(
    bot: commands.Bot,
    system: LevelSystem,
    developer_id: int | None = None,
) -> commands.Bot:
    """Register level display, administration, and announcement commands once."""
    if getattr(bot, "_levels_commands_registered", False):
        return bot

    @bot.command(name="مستواي", aliases=["level", "rank", "لفلي"])
    @commands.guild_only()
    async def my_level(ctx: commands.Context, member: discord.Member | None = None):
        member = member or ctx.author
        data = system.profile(ctx.guild.id, member.id)
        rank, total = system.rank(ctx.guild.id, member.id)
        current = int(data["level"])
        previous = xp_for_level(current) if current else 0
        needed = max(1, xp_for_level(current + 1) - previous)
        progress = max(0, int(data["xp"]) - previous)
        percentage = min(100.0, progress * 100 / needed)
        filled = min(20, int(20 * percentage / 100))
        embed = discord.Embed(title=f"📊 مستوى {_safe_name(member)}", color=0x9B59B6)
        embed.add_field(name="🎯 المستوى", value=f"`{current}`", inline=True)
        embed.add_field(name="🏆 الترتيب", value=f"`#{rank or '-'} / {total}`", inline=True)
        embed.add_field(name="✨ XP", value=f"`{int(data['xp']):,}`", inline=True)
        embed.add_field(name="🏅 الرتبة", value=title_for_level(current), inline=True)
        embed.add_field(
            name="📈 التقدم",
            value=f"`{'█' * filled}{'░' * (20 - filled)}`\n"
            f"`{progress:,}` / `{needed:,}` ({percentage:.1f}%)",
            inline=False,
        )
        embed.add_field(name="💬 الرسائل", value=f"`{int(data['total_messages']):,}`")
        embed.add_field(name="🎤 دقائق الصوت", value=f"`{int(data['voice_minutes']):,}`")
        await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())

    @bot.command(name="توب", aliases=["top_levels"])
    @commands.guild_only()
    async def level_leaderboard(ctx: commands.Context):
        entries = system.leaderboard(ctx.guild.id)
        embed = discord.Embed(
            title="🏆 أفضل 10 أعضاء",
            description=f"في سيرفر **{discord.utils.escape_markdown(ctx.guild.name)}**",
            color=0xFFD700,
        )
        if not entries:
            embed.description += "\nلا توجد بيانات بعد."
        else:
            labels = await asyncio.gather(
                *(
                    _leaderboard_member_label(
                        ctx.guild,
                        int(entry["user_id"]),
                    )
                    for entry in entries
                )
            )
            lines = []
            for index, (entry, member_label) in enumerate(
                zip(entries, labels),
                1,
            ):
                lines.append(
                    f"**{index}.** {member_label} — مستوى `{entry['level']}` • "
                    f"`{int(entry['xp']):,}` XP"
                )
            embed.description += "\n" + "\n".join(lines)
        await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())

    @bot.command(name="xp_help", aliases=["مستويات_help"])
    @commands.guild_only()
    async def levels_help(ctx: commands.Context):
        await ctx.send(
            "🎮 اكسب `15-25` XP من رسالة كل 60 ثانية، و`10` XP لكل دقيقة صوت.\n"
            "استخدم `!مستواي` لعرض تقدمك أو `!توب` لعرض أفضل 10 أعضاء. "
            "يمكن للإداريين ضبط مكافآت الرتب باستخدام "
            "`!level_role_set <level> @role` وعرضها باستخدام `!level_roles`، "
            "وضبط إشعارات الارتقاء باستخدام `/levelsetup`.",
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @bot.command(name="level_role_set")
    @commands.guild_only()
    @commands.has_guild_permissions(administrator=True)
    async def set_level_role(
        ctx: commands.Context, level: int, role: discord.Role
    ) -> None:
        if level <= 0:
            await ctx.reply("يجب أن يكون المستوى رقمًا موجبًا.")
            return
        system.set_role_reward(ctx.guild.id, level, role.id)
        safe_role_name = discord.utils.escape_markdown(role.name)
        await ctx.reply(
            f"تم ضبط مكافأة المستوى `{level}` على رتبة **{safe_role_name}**.",
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @bot.command(name="level_role_remove")
    @commands.guild_only()
    @commands.has_guild_permissions(administrator=True)
    async def remove_level_role(ctx: commands.Context, level: int) -> None:
        if level <= 0:
            await ctx.reply("يجب أن يكون المستوى رقمًا موجبًا.")
            return
        if system.remove_role_reward(ctx.guild.id, level):
            await ctx.reply(f"تم حذف مكافأة المستوى `{level}`.")
        else:
            await ctx.reply(f"لا توجد مكافأة مضبوطة للمستوى `{level}`.")

    @bot.command(name="level_roles")
    @commands.guild_only()
    async def list_level_roles(ctx: commands.Context) -> None:
        rewards = system.role_rewards(ctx.guild.id)
        if not rewards:
            await ctx.reply("لم تُضبط مكافآت رتب للمستويات في هذا السيرفر.")
            return
        lines = []
        for level, role_id in sorted(rewards.items()):
            role = ctx.guild.get_role(role_id)
            role_label = (
                f"**{discord.utils.escape_markdown(role.name)}**"
                if role is not None
                else f"رتبة مفقودة (ID `{role_id}`)"
            )
            lines.append(f"المستوى `{level}` ← {role_label}")
        await ctx.reply(
            "\n".join(lines),
            allowed_mentions=discord.AllowedMentions.none(),
        )

    @bot.tree.command(
        name="levelsetup",
        description="إعداد إشعارات المستويات لهذا السيرفر",
    )
    @app_commands.guild_only()
    @app_commands.describe(
        action="اختر إعداد إشعارات الارتقاء",
        channel="روم نصي للإشعارات",
        message="نص اختياري؛ يدعم {user} و{level} و{title} و{guild}",
    )
    @app_commands.choices(
        action=[
            app_commands.Choice(name="تحديد روم مخصص", value="set_channel"),
            app_commands.Choice(name="نفس روم كسب المستوى", value="same_channel"),
            app_commands.Choice(name="إرسال في الخاص", value="dm"),
            app_commands.Choice(name="إيقاف الإشعارات", value="off"),
            app_commands.Choice(name="عرض الإعدادات", value="show"),
            app_commands.Choice(name="إعادة الافتراضي", value="reset"),
            app_commands.Choice(name="تحديد رسالة مخصصة", value="set_message"),
            app_commands.Choice(name="مسح الرسالة المخصصة", value="clear_message"),
            app_commands.Choice(name="منشن العضو: تشغيل", value="mention_on"),
            app_commands.Choice(name="منشن العضو: إيقاف", value="mention_off"),
        ]
    )
    async def level_setup(
        interaction: discord.Interaction,
        action: app_commands.Choice[str],
        channel: discord.TextChannel | None = None,
        message: str | None = None,
    ) -> None:
        guild = interaction.guild
        if guild is None:
            await interaction.response.send_message(
                "هذا الأمر متاح داخل السيرفر فقط.",
                ephemeral=True,
            )
            return
        permissions = getattr(interaction.user, "guild_permissions", None)
        if permissions is None or not permissions.administrator:
            await interaction.response.send_message(
                "إعداد إشعارات المستويات متاح لإداريي السيرفر فقط.",
                ephemeral=True,
            )
            return

        if action.value == "show":
            settings = system.announcement_settings(guild.id)
            mode_labels = {
                "same": "نفس روم كسب المستوى",
                "channel": "روم مخصص",
                "dm": "الخاص",
                "off": "متوقف",
            }
            embed = discord.Embed(
                title="إعدادات إشعارات المستويات",
                description=f"في سيرفر **{discord.utils.escape_markdown(guild.name)}**",
                color=0x4A90E2,
            )
            embed.add_field(
                name="وجهة الإشعار",
                value=mode_labels[settings["mode"]],
                inline=True,
            )
            if settings["mode"] == "channel":
                configured = guild.get_channel(settings["channel_id"])
                embed.add_field(
                    name="الروم",
                    value=configured.mention if configured else "الروم المحفوظ غير متاح",
                    inline=True,
                )
            embed.add_field(
                name="منشن العضو",
                value="مفعّل" if settings["mention_user"] else "متوقف",
                inline=True,
            )
            custom_message = settings["custom_message"]
            embed.add_field(
                name="الرسالة المخصصة",
                value=custom_message or "الرسالة الافتراضية",
                inline=False,
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if action.value == "reset":
            view = _LevelSettingsResetView(
                system,
                guild.id,
                interaction.user.id,
            )
            await interaction.response.send_message(
                "سيُعاد ضبط إعدادات إشعارات المستويات لهذا السيرفر فقط. "
                "هل تريد المتابعة؟",
                view=view,
                ephemeral=True,
            )
            return

        updates: dict[str, Any]
        if action.value == "set_channel":
            if channel is None:
                await interaction.response.send_message(
                    "حدد رومًا نصيًا باستخدام خيار `channel`.",
                    ephemeral=True,
                )
                return
            if channel.guild.id != guild.id:
                await interaction.response.send_message(
                    "اختر رومًا من هذا السيرفر.",
                    ephemeral=True,
                )
                return
            updates = {"mode": "channel", "channel_id": channel.id}
        elif action.value == "same_channel":
            updates = {"mode": "same", "channel_id": None}
        elif action.value == "dm":
            updates = {"mode": "dm", "channel_id": None}
        elif action.value == "off":
            updates = {"mode": "off", "channel_id": None}
        elif action.value == "set_message":
            if message is None or not message.strip():
                await interaction.response.send_message(
                    "اكتب الرسالة في خيار `message`.",
                    ephemeral=True,
                )
                return
            if len(message) > LEVEL_UP_MESSAGE_LIMIT:
                await interaction.response.send_message(
                    f"يجب ألا تتجاوز الرسالة {LEVEL_UP_MESSAGE_LIMIT} حرفًا.",
                    ephemeral=True,
                )
                return
            updates = {"custom_message": message.strip()}
        elif action.value == "clear_message":
            updates = {"custom_message": None}
        elif action.value == "mention_on":
            updates = {"mention_user": True}
        elif action.value == "mention_off":
            updates = {"mention_user": False}
        else:
            await interaction.response.send_message(
                "الإعداد المطلوب غير معروف.",
                ephemeral=True,
            )
            return

        try:
            system.set_announcement_settings(guild.id, updates)
        except Exception:
            logger.exception(
                "Could not save level announcement settings for guild %s.",
                guild.id,
            )
            await interaction.response.send_message(
                "تعذر حفظ الإعدادات؛ لم تتغير.",
                ephemeral=True,
            )
            return

        messages = {
            "set_channel": f"ستظهر إشعارات الارتقاء في {channel.mention}.",
            "same_channel": "ستظهر الإشعارات في روم كسب المستوى.",
            "dm": "ستُرسل الإشعارات للعضو في الخاص، مع الرجوع للروم عند تعذر الإرسال.",
            "off": "أُوقفت إشعارات الارتقاء؛ مكافآت الرتب تستمر كالمعتاد.",
            "set_message": "حُفظت رسالة الارتقاء المخصصة.",
            "clear_message": "عادت رسالة الارتقاء إلى النص الافتراضي.",
            "mention_on": "فُعّل منشن العضو في إشعار الارتقاء.",
            "mention_off": "أُوقف منشن العضو في إشعار الارتقاء.",
        }
        await interaction.response.send_message(
            messages[action.value],
            allowed_mentions=discord.AllowedMentions.none(),
            ephemeral=True,
        )

    if developer_id is not None:
        @bot.command(name="level_stats")
        @commands.guild_only()
        async def level_stats(ctx: commands.Context) -> None:
            if ctx.author.id != int(developer_id):
                await ctx.reply(
                    "هذا الأمر متاح لمطور البوت فقط.",
                    allowed_mentions=discord.AllowedMentions.none(),
                )
                return
            stats = system.guild_stats(ctx.guild.id)
            embed = discord.Embed(
                title="إحصائيات المستويات",
                description=f"في سيرفر **{discord.utils.escape_markdown(ctx.guild.name)}**",
                color=0x9B59B6,
            )
            embed.add_field(name="أعضاء لديهم XP", value=f"`{stats['members']:,}`")
            embed.add_field(name="إجمالي XP", value=f"`{stats['total_xp']:,}`")
            embed.add_field(
                name="أعلى مستوى",
                value=f"`{stats['highest_level']:,}`",
            )
            embed.add_field(
                name="الرسائل المحتسبة",
                value=f"`{stats['total_messages']:,}`",
            )
            embed.add_field(
                name="دقائق الصوت",
                value=f"`{stats['voice_minutes']:,}`",
            )
            await ctx.reply(
                embed=embed,
                allowed_mentions=discord.AllowedMentions.none(),
            )

    bot._levels_commands_registered = True
    return bot