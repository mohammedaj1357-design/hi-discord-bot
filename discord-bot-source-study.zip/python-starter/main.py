"""A small Python starting point.

Edit this file and run it with:
    python3 python-starter/main.py
"""


def main() -> None:
    """Run the starter program."""
    name = input("What is your name? ").strip()
    if not name:
        name = "developer"

    print(f"Hello, {name}! Your Python workspace is ready.")


if __name__ == "__main__":
    main()